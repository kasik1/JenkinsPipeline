import subprocess
import os

# suite_path = os.path.join("C:\\","Users","H43634","ssot-new-repo","network-ssot","tests","test_cases","reports")
# test = subprocess.run(["dir/b", suite_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True)
suite_path = "/opt/nautobot/nautobot/test_results"
test = subprocess.run(['ls /opt/nautobot/nautobot/test_results'], shell=True, check=True, universal_newlines=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
out = test.stdout
data = out.split(b'\n')
name_html = suite_path + "/reports.html"
f = open(name_html, 'w')

mensaje = f"""
<html>
<title>Report Index</title>
<body>

<h2>Testing reports</h2>
<p>Click on the report you want to view the results for.</p>
<div id="list-cnt"></div>
<script>
myArray="{data}";
const values = myArray.replaceAll("b'", '"').replace(/'/g, '"');
const object = JSON.parse(values)
console.log(typeof object, object)
let link;
object.forEach((item) => {{
console.log(typeof item,item);
link= document.createElement("a");
link.setAttribute("href",item)
link.innerText = item
let br = document.createElement("br");
link.appendChild(br);
document.getElementById("list-cnt").append(link)
}});
</script> 
<style>
H2{{
    color: white;
    font-size:35px;
    text-align: center;
    border: 10px solid #035c67;
    border-radius: 1em;
    background-color: #035c67;
}}
p{{
font-size:20px;
margin-left: 50px;

}}
div{{
margin-left: 50px;
font-size:20px;
}}
</style>
</body>
</html>"""

f.write(mensaje)
f.close()



