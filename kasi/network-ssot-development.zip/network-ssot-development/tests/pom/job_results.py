from selenium.common.exceptions import TimeoutException
from .ssot import SSOTPage
from selenium.webdriver.common.by import By
from tests.pom.selectors.ssot import SSoT


class JOB_Results(SSOTPage):
    """"SSOTLocations is the class with the methods for module locations."""

    def table_titles(self):
        titles = []
        try:
            rows = self.get_elements(SSoT.rows_selector)
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/thead/tr/th"))
                check, td_name, _, _, _, _, _, _ = list(columns)
                return titles
        except (TimeoutException, ValueError):
            return None

    def view_first_job(self):
        locator = (By.XPATH, '//table[@class="table table-hover table-headings"]/tbody/tr[1]/td[2]/a[1]')
        self.click_on_element(locator)

    def verify_card_sumary(self):
        names = ['Status', 'Started at', 'User', 'Duration', 'Return Value']
        for row in names:
            locator = (By.XPATH, f"//td[contains(text(),'{row}')]/following-sibling::td")
            self.get_element(locator)
        return True

    def click_on_job_model(self, job_model):
        locator = (By.XPATH, f"(//td[contains(text(),'{job_model}')])[1]/../td[2]")
        self.click_on_element(locator)

    def check_message(self, message):
        locator = (By.XPATH, f"//td/p[contains(text(),'{message}')]")
        self.check_presence_of_element(locator, timeout=30)

    def check_level(self, message, level):
        locator = (By.XPATH, f"//td/p[contains(text(),'{message}')]/../../td/label[contains(text(),'{level}')]")
        check_item = self.check_presence_of_element(locator, timeout=30)
        return check_item

    def view_file_output(self):
        locator = (By.XPATH, "(//td[contains(text(),'File Output(s)')])/../td/ul/li")
        text = self.get_element(locator).text
        if text != "" or text != " ":
            return True

    def get_jobs(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            jobs = []
            for row in range(1, len(rows) + 1):
                columns = self.get_elements(
                    (By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, _, name, _, _, _, _, _ = [column.text.strip() for column in columns]
                jobs.append(dict(NAME=name))
            return jobs
        except (TimeoutException, ValueError):
            return []

    def search_device(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.job_results_page()
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_jobs()
        return any([True if element[row] in field else False for element in elements])


