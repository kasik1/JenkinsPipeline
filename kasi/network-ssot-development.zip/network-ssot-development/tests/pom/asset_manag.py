from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from ..pom.selectors.ssot import SSoT
from ..pom.selectors.asset_management import SSoTAssetManagement as SSoTAsset
from ..pom.selectors.devices import SSoTDevices as SSoTD


class SSOTAssetManagement(SSOTPage):
    """contains the functions to run the tenants module"""

    def add_inventory_list(self, data):
        """Add a contract."""
        self.inventory_list_page()
        self.click_add_button()
        self.set_data(data)
        self.click_submit_button()

    def set_data(self, data):
        """Sets the data for the contract's inputs."""
        self.get_element(SSoTAsset.name_title)
        self.set_text(SSoTAsset.name_input, data['NAME'])
        self.set_select_data(SSoTAsset.location_select, data['LOCATION'])
        self.set_select_data(SSoTAsset.device_type_select, data['DEVICE_TYPE'])
        self.set_select_data(SSoTAsset.role_select, data['ROLES_SELECT'])
        self.set_text(SSoTAsset.comments_input, data['COMMENTS'])

    def edit_device(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_device_data(data)
        self.click_on_element((By.NAME, "_update"))

    def set_device_data(self, data):
        """Sets the data for the device's inputs."""
        self.set_select_data(SSoTD.status_selector, data['STATUS'])

    def get_devices(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            devices = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, status, tenant, role, _, _, _, _ = [column.text.strip() for column in columns]
                devices.append(dict(NAME=name, STATUS=status, ROLE=role, TENANT=tenant))
            return devices
        except (TimeoutException, ValueError):
            return []

    def search_inventory_lis(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.inventory_list_page()
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_devices()
        return any([True if element[row] in field else False for element in elements])

    def edit_inventory(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_inventory_data(data)
        self.click_on_element((By.NAME, "_update"))

    def set_inventory_data(self, data):
        self.set_select_data(SSoTAsset.location_select, data['LOCATION'])
        self.set_select_data(SSoTAsset.device_type_select, data['DEVICE_TYPE'])
        self.set_select_data(SSoTAsset.role_select, data['ROLES_SELECT'])
        self.set_text(SSoTAsset.comments_input, data['COMMENTS'])

    def check_title_dev(self, name):
        location = (By.XPATH, f"//span[contains(text(), '{name}')]")
        self.get_element(location)
        return True

    def set_stag_data(self, data):
        """Sets the data for the contract's inputs."""
        self.get_element(SSoTAsset.name_title)
        self.set_text(SSoTAsset.name_input, data['NAME'])
        self.set_select_data(SSoTAsset.location_select, data['LOCATION'])
        self.set_select_data(SSoTAsset.device_type_select, data['DEVICE_TYPE'])
        self.set_select_data(SSoTAsset.role_select, data['ROLES_SELECT'])
        self.set_text(SSoTAsset.comments_input, data['COMMENTS'])

    def edit_device_stag(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_device_data(data)
        self.click_on_element((By.NAME, "_update"))

    def get_devices_stag(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            devices = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, status, tenant, role, _, _, _, _ = [column.text.strip() for column in columns]
                devices.append(dict(NAME=name, STATUS=status, ROLE=role, TENANT=tenant))
            return devices
        except (TimeoutException, ValueError):
            return []

    def search_stag_lis(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.stag_list_page()
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_devices_stag()
        return any([True if element[row] in field else False for element in elements])

    def edit_stag_list(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_stag_data(data)
        self.click_on_element((By.NAME, "_update"))

    def set_stag_data(self, data):
        self.set_select_data(SSoTAsset.location_select, data['LOCATION'])
        self.set_select_data(SSoTAsset.device_type_select, data['DEVICE_TYPE'])
        self.set_select_data(SSoTAsset.role_select, data['ROLES_SELECT'])
        self.set_text(SSoTAsset.comments_input, data['COMMENTS'])