from time import sleep
from .ssot import SSOTPage
from .login import Login
from selenium.webdriver.common.by import By
from selenium.webdriver.support.color import Color


class MainPage(SSOTPage, Login):

    def get_logo(self):
        locator = (By.XPATH, f"//strong[contains(text(),'Organization')]")
        self.get_element(locator)

    def get_sections_and_numbers(self):
        array = []
        array2 = []
        panels = (By.XPATH, "//div[@class='panel-heading']/strong")
        panels = self.get_elements(panels)
        panels = [panel.text for panel in panels]
        for panel in panels:
            if not (panel == "Job History" or panel == "Change Log"):
                locator = (By.XPATH, f"//div[@class='panel-heading']/strong[contains(text(), '{panel}')]/../following-sibling::div/div[@class='list-group-item']/h4")
                elements = self.get_elements(locator)
                elements = [element.text for element in elements]
                for element in elements:
                    if element == "Connections":
                        locator = (By.XPATH, f"//h4[contains(text(), 'Connections')]/../p")
                        elements = self.get_elements(locator)
                        elements = [element.get_attribute('innerText') for element in elements]
                        for text in elements:
                            array = array + [text]
                    else:
                        array = array + element.split("\n")
                sections = array
                locator = (By.XPATH,
                           f"//div[@class='panel-heading']/strong[contains(text(), '{panel}')]/../following-sibling::div/div[@class='list-group-item']/span")
                elements = self.get_elements(locator)
                elements = [element.get_attribute('innerText') for element in elements]
                for element in elements:
                    if element == "Connections":
                        locator = (By.XPATH, f"//h4[contains(text(), 'Connections')]/../span")
                        elements = self.get_elements(locator)
                        elements = [element.get_attribute('innerText') for element in elements]
                        for text in elements:
                            array2 = array2 + [text]
                    else:
                        array2 = array2 + element.split("\n")
                number_section = array2
        for section, number in zip(sections, number_section):
            if section == "Cables" or section == "Interfaces" or section == "Console" or section == "Power":
                locator = (By.XPATH, f"//div/p/a[contains(text(), '{section}')]")
                self.get_element(locator)
                self.click_on_element_by_js(locator)
            else:
                locator = (By.XPATH, f"//div/h4/a[contains(text(), '{section}')]")
                self.click_on_element(locator)
            records = (By.XPATH, "//div[@class='text-right text-muted']")
            if self.is_element_present(records):
                if section == "Interface Connections":
                    number_record = number
                else:
                    records = self.get_element(records).text.split('of')
                    records = records[1].strip()
                    number_record = records
            else:
                number_record = "0"
            assert number == number_record
            self.driver.back()

    def check_element_date_change_log(self):
        locator = (By.XPATH, "//strong[contains(text(), 'Change Log')]/../following-sibling::div/div[1]")
        element = self.get_element(locator).text
        element = element.split("\n")
        date = element[1].split("- ")
        date_click = (By.XPATH, f"//strong[contains(text(), 'Change Log')]/../following-sibling::div/div[1]/small/a[contains(text(), '{date[1]}')]")
        self.get_element(date_click)
        self.click_on_element(date_click)
        titles = ["Change", "Difference", "Object Data", "Related Changes"]
        for title in titles:
            assert self.is_title_present(title, type='strong')
        self.driver.back()

    def check_link_log(self):
        locator_link = (By.XPATH, "(//strong[contains(text(), 'Change Log')]/../following-sibling::div/div/a)[1]")
        name = self.get_element(locator_link).text
        self.click_on_element(locator_link)
        change_log = (By.XPATH, "//li[@role='presentation']/a[contains(text(), 'Change Log')]")
        self.get_element(change_log)
        self.click_on_element(change_log)
        link_change = (By.XPATH, f"//tbody/tr[1]/td/a[contains(text(), '{name}')]")
        self.get_element(link_change)
        self.driver.back()

    def open_user_menu(self):
        locator = (By.XPATH, "//span[@data-original-title='test_user']")
        if self.get_element(locator).is_displayed():
            self.click_on_element(locator)
        else:
            self.organization_menu()
            self.click_on_element(locator)

    def nav_user_click(self):
        links = (By.XPATH, "//span[@data-original-title='test_user']/../following-sibling::ul/li/a")
        elements = self.get_elements(links)
        elements = [element.get_attribute("href") for element in elements]
        for element in elements[0:2]:
            text = element
            split_text = text.split(":8080")
            locator = (By.XPATH, f"(//a[@href='{split_text[1]}'])")
            self.get_elements(locator)
            self.click_on_element(locator)
            if split_text[1] == "/admin/":
                title = (By.XPATH, "//h1[contains(text(), 'Site administration')]")
                self.get_element(title)
                self.driver.back()
                self.open_user_manu()
            if split_text[1] == "/user/profile/":
                span = ["User login", "Full name", "Email", "Registered", "Groups", "Admin access"]
                for data in span:
                    data_loc = (By.XPATH, f"//small[contains(text(), '{data}')]")
                    self.get_element(data_loc)
                tabs =["Preferences", "Password", "API Tokens"]
                for tab in tabs:
                    tabs_loc = (By.XPATH, f"//ul[@class='nav nav-pills nav-stacked']/li/a[contains(text(), '{tab}')]")
                    self.click_on_element(tabs_loc)
                    if tab == "Change Password":
                        labels = ["Old password", "New password", "New password confirmation"]
                        for label in labels:
                            data_label = (By.XPATH, f"//label[contains(text(), '{label}')]")
                            self.get_element(data_label)
                    if tab == "API Tokens":
                        locator = (By.XPATH, "//small[contains(text(), 'Create/edit/delete operations')]")
                        element = self.is_element_present(locator)
                        if element:
                            self.get_element(locator)
                    if tab == "Advanced Settings":
                        locator = (By.XPATH, "//strong[contains(text(), 'Advanced Settings')]")
                        element = self.is_element_present(locator)
                        if element:
                            self.get_element(locator)

    def check_color_view(self):
        get_first_color = (By.XPATH, f"(//div[@class='panel-heading'])[1]")
        element = self.get_element(get_first_color)
        rgb = element.value_of_css_property('background-color')
        color = Color.from_string(rgb).hex
        return color

    def change_dark_color(self):
        locator = (By.ID, "btn-theme-modal")
        self.click_on_element(locator)
        dark = (By.ID, "img-dark-theme")
        self.get_element(dark)
        self.click_on_element(dark)

    def change_light_color(self):
        locator = (By.ID, "btn-theme-modal")
        self.click_on_element(locator)
        dark = (By.ID, "img-light-theme")
        self.get_element(dark)
        self.click_on_element(dark)

    def log_out_home(self, setup_server_url):
        locator = (By.XPATH, "//a[@href='/logout/']")
        self.click_on_element(locator)
        sleep(2)
        url = self.driver.current_url
        assert url == setup_server_url + "/login/?next=/"
