from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoT
from tests.pom.selectors.platforms import SSoTPlatform as SSoTPlat


class SSOTPlatform(SSOTPage):
    """"SSOTPlatform is the class with the methods for virtual chassis module."""

    def add_platform(self, data):
        self.platform_page()
        self.click_add_button()
        self.set_platform_data(data)
        self.click_submit_button()

    def set_platform_data(self, data):
        """Sets the data for the platforms inputs."""
        self.get_element(SSoTPlat.name_input)
        self.set_text(SSoTPlat.name_input, data['NAME'], )
        self.set_select_data(SSoTPlat.manufacturer_selector, data['MANUFACTURER'])
        self.set_text(SSoTPlat.napalm_driver_selector, data['NAPALM'])
        self.set_text(SSoTPlat.desc, data['DESC'])

    def edit_platform(self, name, data):
        """Edit a plataform."""
        _, edit, _ = self.get_platform_buttons_by_name(name)
        edit.click()
        self.set_platform_data(data)
        self.click_update_button()

    def delete_platform(self, name):
        """Delete a plataform."""
        _, _, delete = self.get_platform_buttons_by_name(name=name)
        delete.click()
        self.click_confirm_button()

    def view_change_log_platform(self, name):
        """select the platform for check request id the changes"""
        self.platform_page()
        page = self.get_pagination()
        locator = SSoT.next_pagination
        if page > 0:
            for _ in range(page):
                try:
                    log, _, _ = self.get_platform_buttons_by_name(name)
                except Exception as e:
                    self.click_on_element(locator)
                    log, _, _ = self.get_platform_buttons_by_name(name)
                log.click()
                break