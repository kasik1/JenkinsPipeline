from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoT
from tests.pom.selectors.snow import SSoTSnow as SSoTSnow
from tests.pom.selectors.virtual_chassis import SSoTVirtualChassis as SSoTVirtualC
from tests.pom.selectors.devices import SSoTDevices as SSoTD
from selenium.common.exceptions import TimeoutException


class SSOTVirtualChassis(SSOTPage):
    """"SSOTVirtual_Chassis is the class with the methods for virtual chassis module."""

    def add_virtual_chassis(self, data):
        """Add a new virtual chassis."""
        self.virtual_chassis_page()
        self.click_add_button()
        self.set_virtual_data(data)
        self.click_submit_button()

    def set_virtual_data(self, data):
        """Sets the data for the virtual chassis inputs."""
        self.get_element(SSoTVirtualC.title)
        self.set_text(SSoTVirtualC.name_input, data['NAME'])
        self.set_text(SSoTVirtualC.domain_input, data['DOMINE'])
        self.set_select_data(SSoTVirtualC.site_selector, data['SITE'])
        self.get_element(SSoTVirtualC.racks_selector)
        self.set_select_data(SSoTVirtualC.racks_selector, data['RACK'])

    def click_text(self, name):
        """select the Edit in virtual chassis."""
        self.click_link_text(name)

    def are_virtual_stats_present(self):
        modules = ['Virtual Chassis', 'Members', 'Tags']
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'{module}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'{module} module is not present'

    def button_edit(self):
        """select button edit in virtual chassis"""
        self.click_edit_button()

    def add_devices(self):
        """Add members in virtual chassis, add new device for group the virtual chassis """
        locator = SSoTVirtualC.add_members
        self.get_elements(locator)
        self.click_on_element(locator)

    def set_member_add(self, data):
        """set the data in one virtual chassis for add a new device in this virtual"""
        self.get_element(SSoTVirtualC.site_selector)
        self.set_select_data(SSoTVirtualC.site_selector, data['SITE'])
        self.set_select_data(SSoTVirtualC.racks_selector, data['RACK'])
        self.set_select_data(SSoTVirtualC.device_add, data['NAME_DEV'])
        text = self.find_element(SSoTVirtualC.device_add)
        text_device = text.get_property('innerText')
        if not data['NAME_DEV'] in text_device:
            self.set_select_data(SSoTVirtualC.device_add, data['NAME_DEV'])
        self.set_text(SSoTVirtualC.input_position, data['POSITION'])
        self.set_text(SSoTVirtualC.input_priority, data['POSITION'])
        self.click_on_element(SSoTVirtualC.save_button)

    def return_viw_virtual(self):
        """Return at last device added in the page the virtual chassis"""
        locator = SSoTVirtualC.view_virtual
        self.get_element(locator)
        self.click_on_element(locator)

    def select_master(self):
        """select the device with the rol master"""
        locator = SSoTVirtualC.master
        self.get_element(locator)
        self.click_on_element(locator)
        self.click_on_element(SSoTVirtualC.master_option)
        self.click_update_button()

    def view_virtual_chassis(self):
        """view the device withe rol the master in the table virtual chassis  """
        locator = SSoTVirtualC.view_master
        self.get_elements(locator)
        self.click_on_element(locator)

    def get_ip_device(self):
        """get the ips the devices grouped in one virtual chassis"""
        locator = self.get_element(SSoTVirtualC.primary_ip)
        return locator.text

    def get_chassis(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            chassis = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, Name, _, _, _ = [column.text.strip() for column in columns]
                chassis.append(dict(NAME=Name))
            return chassis
        except (TimeoutException, ValueError):
            return []

    def search_chassis(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.virtual_chassis_page()
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_chassis()
        return any([True if element[row] in field else False for element in elements])

    def set_update_data(self, data):
        """set the data in one virtual chassis for add a new device in this virtual"""
        self.get_element(SSoTVirtualC.title)
        self.set_text(SSoTVirtualC.name_input, data['NAME'])
        self.set_text(SSoTVirtualC.domain_input, data['DOMINE'])

    def valid_update_data(self, data):
        locator_title = self.get_format_selector(SSoTVirtualC.title_chassis, data['NAME'])
        value = self.get_element(locator_title)
        return value.text

    def edit_chassis(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_update_data(data)
        self.click_update_button()

    def delete_virtual_chassis(self, name):
        """Delete a device."""
        self.click_link_text(name)
        self.click_delete_button()
        self.click_confirm_button()

    def update_device(self, status, assignment_selector, snow_device_type):
        self.set_select_data(SSoTD.status_selector, status)
        self.set_select_data(SSoTD.assignment_selector, assignment_selector)
        self.set_select_data(SSoTD.snow_device_type, snow_device_type)
        self.click_on_element(SSoT.update_button_selector)

    def click_button_cancel(self):
        self.get_element(SSoTSnow.button_cancel)
        self.click_on_element(SSoTSnow.button_cancel)

    def click_button_send(self):
        self.get_element(SSoTSnow.button_send)
        self.click_on_element(SSoTSnow.button_send)

    def get_req_pending_or_send(self, field: str, row1="DEVICE", row2="STAGE"):
        devices = []
        list_view = self.get_snow()
        for contact in list_view:
            if contact[row2] == field:
                number = contact[row1]
                devices.append(number)
        result = set(devices)
        if len(result) > 0:
            return result

    def validate_change_status(self, initialstatus, changestatus):
        return any([True if contract in changestatus else False for contract in initialstatus])

    def get_status(self):
        locator = (By.XPATH, "//h5[contains(text(),'Management')]/following-sibling::div/table/tbody/tr/th[contains(text(),'Status')]/../td")
        element = self.get_element(locator)
        return element.text

    def delete_ip(self, data):
        self.ip_addresses_page()
        self.go_filters()
        self.input_search_filters(data['PRIMARY_IP4'])
        self.search_button_filters()
        locator = (By.XPATH, f"//a[contains(text(),'{data['PRIMARY_IP4']}')]")
        if self.is_element_present(locator):
            self.click_link_text(data['PRIMARY_IP4'])
            self.click_delete_button()
            self.click_confirm_button()
