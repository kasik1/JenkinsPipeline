from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoT
from tests.pom.selectors.contracts import SSoTContracts as SSoTContr


class SSoTContracts(SSOTPage):
    """contains the functions to run the tenants module"""

    def go_to_tab(self, tab_name):
        locator = (By.XPATH, f"//ul/li[@role='presentation']/button[contains(text(), '{tab_name}')]")
        self.click_on_element(locator)

    def get_contracts(self) -> list:
        """Returns a list of contracts.

        Returns:
            contracts list (list): List of contracts"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            contracts = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, contra = [column.text.strip() for column in columns]
                contracts.append(dict(NAME=name, CONTRA=contra))
            return contracts
        except (TimeoutException, ValueError):
            return []

    def search_contract(self, field: str, row="NAME") -> bool:
        """Returns if found a contract by a specific row.

        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.contracts_page()
        self.input_search_filters(field)
        self.search_button_filters()
        contracts = self.get_contracts()
        return any([True if contract[row] in field else False for contract in contracts])

    def set_contract_data(self, data):
        """Sets the data for the contract's inputs."""
        self.get_element(SSoTContr.input_name)
        self.set_text(SSoTContr.input_name, data['name'])
        self.set_select_data(SSoTContr.input_vendor, data['vendor'])
        self.set_select_data(SSoTContr.input_contract, data['contract'])

    def set_contract_input(self, name):
        self.set_text(SSoTContr.input_name, name)

    @staticmethod
    def set_date_input(input, date):
        for i in date.split('-'):
            input.send_keys(i)
        input.send_keys(Keys.ARROW_RIGHT)
        input.send_keys('2022')

    def set_invalid_dates(self):
        locator = (By.ID, 'id_maintenance_start')
        input = self.get_element(locator)
        start = '30-Aug'
        self.set_date_input(input, start)
        locator = (By.ID, 'id_maintenance_end')
        input = self.get_element(locator)
        end = '01-Aug'
        self.set_date_input(input, end)

    def add_contract(self, data):
        """Add a contract."""
        self.contracts_page()
        self.click_add_button()
        self.set_contract_data(data)
        self.click_submit_button()

    def edit_contract(self, data):
        """Edit a contract."""
        self.click_edit_button()
        self.set_contract_data(data)
        self.click_update_button()

    def delete_contract(self, name):
        """Delete a contract."""
        self.click_link_text(name)
        self.click_delete_button()
        self.click_confirm_button()

    def is_contract_name_present(self, name):
        locator = (By.XPATH, f"//h2[contains(text(), 'Contract: {name}')]")
        return self.get_element(locator)

    def upload_csv_file(self, img):
        locator = (By.ID, 'id_csv_file')
        self.set_text(locator, img)

    def submit_file(self):
        locator = (By.XPATH, "//form//button[@type='submit'][text()='Submit']")
        self.click_on_element(locator)
