from selenium.webdriver.common.by import By


class SSoTCManufacturers:
    """Selectors for the manufacture module"""

    name_selector = (By.NAME, "name")
    description_selector = (By.NAME, "description")
