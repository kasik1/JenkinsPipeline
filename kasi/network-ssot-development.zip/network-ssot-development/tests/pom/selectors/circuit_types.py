from selenium.webdriver.common.by import By


class SSoTCircuitTypes:
    """Selectors for the circuits"""

    name_circuit = (By.ID, "id_name")
    desc_circuit = (By.ID, "id_description")
