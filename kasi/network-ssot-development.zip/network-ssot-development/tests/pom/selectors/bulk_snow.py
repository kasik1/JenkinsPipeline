from selenium.webdriver.common.by import By


class BulkSnow:
    service_now_assig = (By.XPATH, "//select[@id='id_cf_servicenow_assignment_group']/../span/span/span/span[1]")
    device_type = (By.XPATH, "//select[@id='id_cf_servicenow_device_type']/../span/span/span/span[1]")
