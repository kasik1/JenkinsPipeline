from selenium.webdriver.common.by import By


class SSoTContracts:
    """Selectors for the contact module"""

    input_name = (By.NAME, "name")
    input_vendor = (By.ID, "id_provider")
    input_contract = (By.NAME, "contract_type")
