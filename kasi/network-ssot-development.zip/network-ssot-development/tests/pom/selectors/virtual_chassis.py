from selenium.webdriver.common.by import By


class SSoTVirtualChassis:
    """Selectors for the rack module"""
    title = (By.XPATH, "//strong[contains(text(),'Virtual Chassis')]")
    name_input = (By.ID, "id_name")
    domain_input = (By.ID, "id_domain")
    site_selector = (By.XPATH, "//select[@id='id_location']/../span/span/span/span[1]")
    racks_selector = (By.XPATH, "//select[@id='id_rack']/../span/span/span/span[1]")
    add_members = (By.XPATH, "//strong[contains(text(),'Members')]/../following-sibling::div/a")
    device_add = (By.XPATH, "//select[@id='id_device']/../span/span/span/span[1]")
    input_position = (By.ID, "id_vc_position")
    input_priority = (By.ID, "id_vc_priority")
    save_button = (By.NAME, "_save")
    view_virtual = (By.XPATH, "//strong[contains(text(),'Virtual Chassis')]/../following-sibling::div/a")
    master = (By.NAME, "master")
    master_option = (By.XPATH, "//select[@id='id_master']/option[2]")
    view_master = (By.XPATH, "//tbody/tr[2]/td[1]/a[1]")
    primary_ip = (By.XPATH, "//td[contains(text(),'Primary IPv4')]/following-sibling::td")
    title_chassis = (By.XPATH, "//span[contains(text(),'{}')]")
