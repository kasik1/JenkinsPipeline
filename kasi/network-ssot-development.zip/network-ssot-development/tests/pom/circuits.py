from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.circuits import SSoTCircuits as SSoTCir


class SSOTCircuits(SSOTPage):
    """contains the functions to run the tenants module"""

    def add_circuit(self, data):
        """Add a Circuit."""
        self.circuits_page()
        self.click_add_button()
        self.set_circuit_data(data)
        self.click_submit_button()

    def set_circuit_data(self, data):
        """Sets the data for the Circuit inputs."""
        self.get_element(SSoTCir.circuit_id)
        self.set_text(SSoTCir.circuit_id, data['CIRCUIT_ID'])
        self.set_select_data(SSoTCir.provider_selector, data['PROVIDER'])
        self.set_select_data(SSoTCir.type_selector, data['TYPE'])
        self.set_select_data(SSoTCir.status_selector, data['STATUS'])
        self.set_text(SSoTCir.comments_circuit, data['COMMENTS'])

    def are_circuit_stats_present(self):
        modules = ['Tags', 'Comments', 'Circuit']
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'{module}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'Circuit stats for {module} module is not present'

    def edit_circuit(self, circuit, data):
        """Edit a Circuit."""
        self.click_link_text(circuit)
        self.click_edit_button()
        self.set_circuit_data(data)
        self.click_update_button()

    def delete_tenant(self, circuit):
        """Delete a Circuit."""
        self.click_link_text(circuit)
        self.click_delete_button()
        self.click_confirm_button()

    def get_row_values_circuit(self, columns_to_get, row_n=1):
        """
        :param columns_to_get: List with columns to get the value e.g. ['name', 'region', 'status']
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        column_value = {}
        for column in columns_to_get:
            locator = (By.XPATH, f"//tbody/tr[{row_n}]/td[{columns[column]}]")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            column_value.update({column: value})
        return column_value

    def check_specific_search_circuit(self, data, row_n=1):
        """
        :param data: Dictionary with column: value from a row
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        xpaths = [f"//tbody/tr[{row_n}]/td[{columns['id']}]/a[contains(text(), '{data['id']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['provider']}]/a[contains(text(), '{data['provider']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['status']}]/label[contains(text(), '{data['status']}')]"]
        for xpath in xpaths:
            assert self.get_element((By.XPATH, xpath))
