from seleniumpagefactory.Pagefactory import PageFactory
from .ssot import SSOTPage


class DeviceIndicators(SSOTPage, PageFactory):

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.highlight = True
        self.timeout = 30

    # Define locators dictionary where key name will became WebElement using PageFactory
    locators = {
        'devices_select': ('id', 'drivers-select'),
    }

