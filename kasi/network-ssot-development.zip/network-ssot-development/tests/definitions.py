import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

FIREFOXDRIVER_PATH = ROOT_DIR + r'\commons\drivers\geckodriver.exe'

# Paths used for running the test suite in the local environment.
# NOTE: To run locally, one should uncomment the CHROMEDRIVER_PATH line.
# CHROMEDRIVER_PATH = ROOT_DIR + r'\commons\drivers\chromedriver.exe'

# Paths used for running the test suite in Linux environments and containers.
# NOTE: To run locally, one should comment the following lines.
CHROMEDRIVER_PATH = '/usr/bin/chromedriver'
CHROMEDRIVER_PATH = os.path.join(ROOT_DIR, CHROMEDRIVER_PATH)
