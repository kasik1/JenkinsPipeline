from ..commons.zephyr_api import ZephyrAPI
from ..commons.global_vars import TEST_REPORT_DIR
from ..commons.credentials import DEBUG, SEND_TC_RESULTS
from .send_splunk import TestSuiteSplunk
from datetime import datetime
from .script import script
from .css import css
import re
import os
import pytest
import uuid


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    """
        Set up the output folder, and html report file;
        this has to be done right after the command line options
        are parsed, because we need to rewrite the pytest-html path.

            Import in the conftest.py file
            "from plugins.reporting import pytest_configure"

        :param config: pytest Config object
        :return: None
    """
    path = config.rootdir.strpath
    module_name = os.path.split(path)[1]
    dir_path = os.path.join(path, TEST_REPORT_DIR)
    report_name = module_name + '_' + datetime.now().strftime('%Y-%m-%dT%H_%M_%S') + '.html'
    report_path = os.path.join(dir_path, report_name)
    if DEBUG:
        config.option.htmlpath = report_path


def send_results_to_splunk(results, environment):
    splunk = TestSuiteSplunk()
    cycle = str(uuid.uuid4())
    for result in results:
        splunk.send_qa_telemetry(
            test_case_name=result['tc_name'],
            module=result['tc_application'],
            duration=result['tc_duration'],
            result=result['tc_verdict'],  # 1 = pass, 2 = fail
            cycle=cycle,
            branch=environment,
            test_type=result['tc_type'],
            classification=result['tc_classification'],
            workspace=result['tc_workspace'],
        )


def pytest_unconfigure(config):
    """
    Sends the Test Result to Rally and attaches it to the main Test Case
    :param config: pytest Config object
    :return: None
    """
    output = config.option.htmlpath
    branch = config.option.branch
    workspace = config.option.workspace

    test_type = ''
    # Read report
    with open(output) as f:
        lines = f.read()

    lines = re.sub(re.escape(
        '</body></html>'),
        f'{script}{css}</body></html>',
        lines)

    lines = re.sub(re.escape(
        '<h2>Environment</h2>'),
        '<h2 style="display: none;">Environment</h2>'
        f'<div style="color: black;"><strong>Branch name:</strong> '
        f'<a href="https://github.sys.cigna.com/cigna/network-ssot/tree/{branch}">{branch}</a> '
        f'<strong>Pull request number:</strong> '
        f'{test_type}'
        f'</div>',
        lines)

    # Save again the report with the same name
    with open(output, 'w') as f:
        f.write(lines)

    if SEND_TC_RESULTS:
        if len(config.args) >= 2:
            send_results_to_splunk(results=config.args[1]['test_case_results'], environment=branch)
