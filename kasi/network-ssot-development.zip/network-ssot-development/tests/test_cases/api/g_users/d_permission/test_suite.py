import pytest


@pytest.mark.smoke
class TestPermissionSmokeTesting:

    def setup(self):
        self.url_permissions = '/api/users/permissions/'
    
    @pytest.mark.parametrize('test_data', ['test_get_permissions'], indirect=True)
    def test_get_permissions(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)


@pytest.mark.parallel
@pytest.mark.functional
class TestPermission:

    def setup(self):
        self.url_permissions = '/api/users/permissions/'
        self.url_groups = '/api/users/groups/'

    @staticmethod
    def create_entry_for_testing(http, row, end_point, get_id_group, apikey, return_id=True):
        """ This method creates the payload to be sent in the rquest of the following test cases,
                Payload : is the set of data that will be sent to generate the intake ticket
                Module : contains the instruction for the execution of the method to be carried out, example: post (), get () etc.
                Response : contains the response after the post was executed, or get
                Create an if : this looks for the id tag in the respons to check that the pyload was generated correctly"""
        module = http(end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = {
            "name": row['name'],
            "description": row['desc'],
            "enabled": row['enabled'],
            "object_types": [row['object_types']],
            "groups": [get_id_group],
            "actions": [row['actions']],
            "constraints": row['constraints']
        }
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), "New Automation Request entry for testing was not created successfully."
            return response.json()['id']

    @staticmethod
    def delete_method(http, object_id, apikey):
        header = {"Authorization": f'{apikey}'}
        get_end_point = '/api/users/permissions/{}/'.format(object_id)
        module = http(get_end_point)
        module.set_headers(header)
        response = module.delete(object_id)
        assert response.status_code == 204

    @pytest.mark.parametrize('test_data', ['test_get_permissions_id'], indirect=True)
    def test_get_permissions_id(self, http, test_data, response_results, response_asserts, response_assert_fields,
                                apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'description', 'display']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            module = http(self.url_permissions)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                self.create_entry_for_testing(http, row, self.url_permissions, get_id_group, apikey=apikey)
                get_id = get_object_id(module)
                module = http(end_point)
                module.set_headers(header)
                response = module.get(get_id)
                response_results(response, print_json_rows=False)
                response_asserts(response)
                response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_post_create_permissions'], indirect=True)
    def test_post_create_permissions(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields,get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            payload = {
                    "name": row['name'],
                    "description": row['desc'],
                    "enabled": row['enabled'],
                    "object_types": [row['object_types']],
                    "groups": [get_id_group],
                    "actions": [row['actions']],
                    "constraints": row['constraints']
            }
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            id_token = response.json()['id']
            self.delete_method(http, id_token, apikey)

    @pytest.mark.parametrize('test_data', ['test_put_update_permissions'], indirect=True)
    def test_put_update_permissions(self, http, test_data, response_results, get_object_id, apikey, get_object_data, response_asserts):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            get_id_permission = self.create_entry_for_testing(http, row, self.url_permissions, get_id_group, apikey=apikey)
            get_end_point = '/api/users/permissions/{}/'.format(get_id_permission)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(get_id_permission)
            response = response.json()
            get_id_groups = response['groups'][0]['id']
            get_name = response['name']
            payload = [{
                "id": get_id_permission,
                "name": get_name,
                "description": row['desc_update'],
                "enabled": row['enabled'],
                "object_types": [row['object_types']],
                "groups": [get_id_groups],
                "actions": [row['actions']],
                "constraints": row['constraints']
            }]
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            assert response.json()[0]['id'] == get_id_permission, f"ID from response does not match expected ID {get_id_permission}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            self.delete_method(http, get_id_permission, apikey)

    @pytest.mark.parametrize('test_data', ['test_put_update_permissions_id'], indirect=True)
    def test_put_update_permissions_id(self, http, test_data, response_results, response_asserts,
                                           response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            get_id_permission = self.create_entry_for_testing(http, row, self.url_permissions, get_id_group,
                                                              apikey=apikey)
            get_end_point = '/api/users/permissions/{}/'.format(get_id_permission)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(get_id_permission)
            response = response.json()
            get_id_groups = response['groups'][0]['id']
            get_name = response['name']
            payload = {
                "name": get_name,
                "description": row['desc_update'],
                "enabled": row['enabled'],
                "object_types": [row['object_types']],
                "groups": [get_id_groups],
                "actions": [row['actions']],
                "constraints": row['constraints']
            }
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id_permission)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            assert response.json()['id'] == get_id_permission, f"ID from response does not match expected ID {get_id_permission}."
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            self.delete_method(http, get_id_permission, apikey)

    @pytest.mark.parametrize('test_data', ['test_patch_update_permissions'], indirect=True)
    def test_patch_update_permissions(self, http, test_data, response_results, get_object_id, get_object_data, apikey, response_asserts):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            get_id_permission = self.create_entry_for_testing(http, row, self.url_permissions, get_id_group,
                                                              apikey=apikey)
            get_end_point = '/api/users/permissions/{}/'.format(get_id_permission)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(get_id_permission)
            response = response.json()
            get_id_groups = response['groups'][0]['id']
            get_name = response['name']
            payload = [{
                "id": get_id_permission,
                "name": get_name,
                "description": row['desc_update'],
                "enabled": row['enabled'],
                "object_types": [row['object_types']],
                "groups": [get_id_groups],
                "actions": [row['actions']],
                "constraints": row['constraints']
            }]
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            assert response.json()[0]['id'] == get_id_permission, f"ID from response does not match expected ID {get_id_permission}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            self.delete_method(http, get_id_permission, apikey)

    @pytest.mark.parametrize('test_data', ['test_patch_update_permissions_id'], indirect=True)
    def test_patch_update_permissions_id(self, http, test_data, response_results, response_asserts,
                                   response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            get_id_permission = self.create_entry_for_testing(http, row, self.url_permissions, get_id_group,
                                                              apikey=apikey)
            get_end_point = '/api/users/permissions/{}/'.format(get_id_permission)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(get_id_permission)
            response = response.json()
            get_id_groups = response['groups'][0]['id']
            get_name = response['name']
            payload = {
                "name": get_name,
                "description": row['desc_update'],
                "enabled": row['enabled'],
                "object_types": [row['object_types']],
                "groups": [get_id_groups],
                "actions": [row['actions']],
                "constraints": row['constraints']
            }
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch(get_id_permission)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            assert response.json()['id'] == get_id_permission, f"ID from response does not match expected ID {get_id_permission}."
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            self.delete_method(http, get_id_permission, apikey)

    @pytest.mark.parametrize('test_data', ['test_delete_permissions'], indirect=True)
    def test_delete_permissions(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields,apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            module = http(self.url_groups)
            module.set_headers(header)
            get_id_group = get_object_id(module)
            object_id = self.create_entry_for_testing(http, row, self.url_permissions, get_id_group, apikey=apikey)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

            get_end_point = '/api/users/permissions/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(object_id)
            assert response.status_code == 404, "The status code not is equal at 404"
            assert response.json()['detail'] == 'No ObjectPermission matches the given query.', "The Request wasn't deleted."
