import pytest


@pytest.mark.smoke
class TeststatusSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_get_status'], indirect=True)
    def test_get_status(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            response_fields = ['django-version', 'installed-apps', 'plugins', 'nautobot-version', 'python-version']
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_assert_fields(response, response_fields)
            response_asserts(response)
