import pytest


@pytest.mark.data_load
class TestGroups:
    def setup(self):
        self.url_groups = '/api/users/groups/'
        self.url_user = '/api/users/users/'
        self.url_locations = '/api/dcim/locations/'
        self.url_racks = '/api/dcim/racks/'


    @staticmethod
    def get_object_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @staticmethod
    def set_payload(name):
        payload = {
            'name': name
        }
        return payload

    @pytest.mark.parametrize('test_data', ['test_data_load_groups'], indirect=True)
    def test_data_load_groups(self, http, test_data, response_results, apikey, response_asserts,
                               response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            name = f'G_SSOT_APP_ADMIN'
            response = module.get(f"?name={name}")
            response_results(response)

            if response.json()['results']:
                object_id = response.json()['results'][0]['id']
                print(object_id)

            else:
                payload = {
                    "name": name
                }
                end_point = self.url_groups
                module = http(end_point)
                module.set_body(payload)
                module.set_headers(header)
                response = module.post()
                response_results(response, print_json_rows=False)
                response_asserts(response, status_code=201)

    @pytest.mark.parametrize('test_data', ['test_data_load_user_groups'], indirect=True)
    def test_data_load_user_groups(self, http, test_data, response_results, apikey, response_asserts,
                              response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        array = []
        header = {"Authorization": f'{apikey}'}
        name = f'G_SSOT_APP_ADMIN'
        end_point = self.url_groups + '{}'
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?name={name}")
        id_group = response.json()['results'][0]['id']
        name = f'test_user'
        end_point = self.url_user + '{}'
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?username={name}")
        id_user = response.json()['results'][0]['id']
        id_username = response.json()['results'][0]['username']
        len_groups = len(response.json()['results'][0]['groups'])
        print("iduser", id_user)
        if len_groups > 0:
            for i in range(1, len_groups+1):
                print("valor", i-1)
                groups = response.json()['results'][0]['groups'][i-1]['id']
                print(groups)
                array.append(groups)
                print("array")
                print(array)
                print(id_group, "id")
                if id_group in array:
                    print("exist")
                else:
                    print("creando")
                    payload = [{
                        "id": id_user,
                        'username': id_username,
                        "groups": [{"id": id_group}]
                    }]
                    end_point = self.url_user
                    module = http(end_point)
                    module.set_body(payload)
                    module.set_headers(header)
                    response = module.patch()
                    print(response.json())
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=200)
        else:
            print("creando fuera")
            payload = [{
                "id": id_user,
                'username': id_username,
                 "groups": [{"id": id_group}],
            }]
            print(id_group)
            end_point = self.url_user
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.patch()
            print(response.json())
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=200)

    #



