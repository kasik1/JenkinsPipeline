import pytest


@pytest.mark.smoke
class TestCircuitTerminationsResponseSmokeTesting:

    def setup(self):
        self.url_circuit_terminations = '/api/circuits/circuit-terminations/'

    @pytest.mark.parametrize('test_data', ['test_get_circuit_terminations'], indirect=True)
    def test_get_circuit_terminations(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_get_circuit_terminations_id'], indirect=True)
    def test_get_circuit_terminations_id(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'url', 'display']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_circuit_terminations)
            module.set_headers(header)
            response = module.get()
            if response.json()['results']:
                get_id_circuit_type = get_object_id(module)
                module = http(end_point)
                module.set_headers(header)
                response = module.get(get_id_circuit_type)
                response_results(response, print_json_rows=False)
                response_asserts(response)
                response_assert_fields(response, response_fields)


@pytest.mark.parallel
@pytest.mark.functional
class TestCircuitTerminations:

    def setup(self):
        self.url_circuit_terminations = '/api/circuits/circuit-terminations/'
        self.url_circuits = "/api/circuits/circuits/"
        self.url_locations = "/api/dcim/locations/"

    @staticmethod
    def get_object_id(http, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @pytest.mark.parametrize('test_data', ['test_post_create_circuit_terminations'], indirect=True)
    def test_post_create_circuit_terminations(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields, get_object_id, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        get_location = self.get_object_id(http, apikey, self.url_locations + '{}',
                                          "name=QA-TD Location - view")
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            module = http(self.url_circuits)
            module.set_headers(header)
            get_id_circuit = get_object_id(module)
            get_term_z = get_object_data(module, "circuit_termination_z")
            if get_term_z == None:
                term = "Z"
            else:
                id = get_term_z["id"]
                module = http(self.url_circuit_terminations +"{}/")
                module.set_headers(header)
                response = module.delete(id)
                assert response.status_code == 204
                term = "Z"
            payload = {
                    "circuit": get_id_circuit,
                    "term_side": term,
                    "location": get_location,
                    "port_speed": 0,
                    "upstream_speed": 0,
                    "xconnect_id": "string",
                    "pp_info": "string",
                    "description": row['desc'],
                    "cable": {
                        "label": "string"
                    }
                }
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)

    @pytest.mark.parametrize('test_data', ['test_put_update_circuit_terminations'], indirect=True)
    def test_put_update_circuit_terminations(self, http, test_data, response_results, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_circuits)
            module.set_headers(header)
            get_id_circuit = get_object_id(module)
            module = http(self.url_circuit_terminations)
            module.set_headers(header)
            get_id_circuit_term = get_object_id(module)
            get_url = get_object_data(module, "url")
            location = get_object_data(module, "location")
            get_id_location = location['id']
            module = http(end_point)
            payload = [{
                    "id": get_id_circuit_term,
                    "circuit": get_id_circuit,
                    "term_side": "Z",
                    "location": get_id_location,
                    "port_speed": 0,
                    "upstream_speed": 0,
                    "xconnect_id": "string",
                    "pp_info": "string",
                    "description": row['desc'],
                    "cable": {
                        "label": "string"
                    }}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_circuit_term, f"ID from response does not match expected ID {get_id_circuit_term}."
            assert response.json()[0]['url'] == get_url, f"URL from response does not match expected URL{get_url}."

    @pytest.mark.parametrize('test_data', ['test_put_update_circuit_terminations_id'], indirect=True)
    def test_put_update_circuit_terminations_id(self, http, test_data, response_results, response_asserts,
                                           response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_circuit_terminations)
            module.set_headers(header)
            get_id_circuit_term = get_object_id(module)
            get_url = get_object_data(module, "url")
            circuit = get_object_data(module, "circuit")
            get_id_circuit = circuit['id']
            location = get_object_data(module, "location")
            get_id_location = location['id']
            payload = {
                "circuit": get_id_circuit,
                "term_side": "Z",
                "location": get_id_location,
                "port_speed": 0,
                "upstream_speed": 0,
                "xconnect_id": "string",
                "pp_info": "string",
                "description": row['desc'],
                "cable": {
                    "label": "string"
                }}
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id_circuit_term)
            response_results(response, print_json_rows=False)
            assert response.json()['id'] == get_id_circuit_term, f"ID from response does not match expected ID {get_id_circuit_term}."
            assert response.json()['url'] == get_url, f"URL from response does not match expected URL{get_url}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_circuit_terminations'], indirect=True)
    def test_patch_update_circuit_terminations(self, http, test_data, response_results, get_object_id, get_object_data, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_circuit_terminations)
            module.set_headers(header)
            get_id_circuit_term = get_object_id(module)
            get_url = get_object_data(module, "url")
            circuit = get_object_data(module, "circuit")
            get_id_circuit = circuit['id']
            location = get_object_data(module, "location")
            get_id_location = location['id']
            module = http(end_point)
            payload = [{
                "id": get_id_circuit_term,
                "circuit": get_id_circuit,
                "term_side": "Z",
                "location": get_id_location,
                "port_speed": 0,
                "upstream_speed": 0,
                "xconnect_id": "string",
                "pp_info": "string",
                "description": row['desc'],
                "cable": {
                    "label": "string"
                }}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            assert response.json()[0][
                       'id'] == get_id_circuit_term, f"ID from response does not match expected ID {get_id_circuit_term}."
            assert response.json()[0]['url'] == get_url, f"URL from response does not match expected URL {get_url}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_circuit_terminations_id'], indirect=True)
    def test_patch_update_circuit_terminations_id(self, http, test_data, response_results, response_asserts,
                                   response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_circuit_terminations)
            module.set_headers(header)
            get_id_circuit_term = get_object_id(module)
            get_url = get_object_data(module, "url")
            circuit = get_object_data(module, "circuit")
            get_id_circuit = circuit['id']
            location = get_object_data(module, "location")
            get_id_location = location['id']
            payload = {
                "circuit": get_id_circuit,
                "term_side": "Z",
                "location": get_id_location,
                "port_speed": 0,
                "upstream_speed": 0,
                "xconnect_id": "string",
                "pp_info": "string",
                "description": row['desc'],
                "cable": {
                    "label": "string"
                }}
            module = http(end_point)
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch(get_id_circuit_term)
            response_results(response, print_json_rows=False)
            assert response.json()[
                       'id'] == get_id_circuit_term, f"ID from response does not match expected ID {get_id_circuit_term}."
            assert response.json()['url'] == get_url, f"URL from response does not match expected URL {get_url}."

    @pytest.mark.parametrize('test_data', ['test_delete_circuit_terminations'], indirect=True)
    def test_delete_circuit_terminations(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields,apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            module = http(self.url_circuit_terminations)
            module.set_headers(header)
            object_id = get_object_id(module)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            assert response.status_code == 204, "The status code not is equal at 404"
