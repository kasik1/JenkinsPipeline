import os
from tests.fixtures.users import create_login
import pytest


class locations:

    def setup(self):
        self.ADD_OK = "Created location"
        self.UPDATE = "Modified location"
        self.delete_location = "Deleted location"
        self.CREATE_IMG = "Created image attachment"
        self.DELETE_IMG = "Deleted image attachment"
        self.UPDATE_IMG = "Modified image attachment"
        self.UPLOAD_FILE = "Created file attachment"
        self.DELETE_FILE = "Deleted file attachment"
        self.UPDATE_FILE = "Modified file attachment"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestContractsUserBase(locations):

    @pytest.mark.parametrize('test_data', ['test_view_title_locations'], indirect=True)
    def test_view_title_locations(self, user_base, test_data, user_session, login_page):
        """ locations - Test check the title in the menu the tenants """
        title = 'Sites'
        user_base.log_out()
        login_page(user_session)
        user_base.locations_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_locations'], indirect=True)
    def test_add_locations(self, user_base, test_data, user_session, login_page):
        """ locations - Add a item in location. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.locations_page()
            user_base.click_add_button()
            user_base.set_location_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_locations'], indirect=True)
    def test_update_element_locations(self, user_base, test_data,login_page, user_session):
        """ locations - Update a location  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contact = user_base.search_location(row['NAME'])
            assert found_contact, f"No location with name {row['NAME']} found."
            user_base.edit_location(row['NAME'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_locations'], indirect=True)
    def test_action_delete_locations(self, user_base, test_data, user_session, login_page):
        """ locations - Delete a locations type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.locations_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.quicktest
class TestSitesQuickTest(locations):

    @pytest.mark.parametrize('test_data', ['test_view_location_details'], indirect=True)
    def test_view_location_details(self, ssot, test_data):
        """ Site - View location details """
        ssot.locations_page()
        ssot.view_first_location()
        assert ssot.is_location_description_present()
        ssot.are_location_stats_present()

    @pytest.mark.parametrize('test_data', ['test_update_location'], indirect=True)
    def test_update_location(self, ssot, test_data):
        """ Sites - Update a contact with the required fields by name. """
        for row in test_data['data']:
            found_contact = ssot.search_location(row['NAME'])
            assert found_contact, f"No location with name {row['NAME']} found."
            ssot.edit_location(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_add_location'], indirect=True)
    def test_add_location(self, ssot, test_data):
        """ Sites - Add a location. """
        for row in test_data['data']:
            ssot.add_location(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."


@pytest.mark.smoke
class TestSitesFormValidation:

    @pytest.mark.parametrize('test_data', ['test_search_location'], indirect=True)
    def test_search_location(self, ssot, test_data):
        """ Sites - Search a location by name. """
        columns = ['name', 'status']
        ssot.locations_page()
        values = ssot.get_row_values(columns)
        ssot.specific_search(values)
        ssot.check_specific_search(values)


@pytest.mark.functional
class TestSites(locations):
    """Class for the location module in ssot"""


    def route_img(self):
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'location.png')
        return select_file

    def route_file(self):
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'csv_file.csv')
        return select_file

    @pytest.mark.parametrize('test_data', ['test_add_img'], indirect=True)
    def test_add_img(self, ssot, test_data):
        """Site add image"""
        for row in test_data['data']:
            ssot.locations_page()
            ssot.view_first_location()
            ssot.add_image()
            path = os.path.dirname(os.path.abspath(__file__))
            select_file = os.path.join(path, 'location.png')
            ssot.form_img(row['NAME'], select_file)
            ssot.click_submit_button()
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.CREATE_IMG), f"The alert text is not {self.CREATE_IMG} as we expected."

    @pytest.mark.parametrize('test_data', ['test_update_img'], indirect=True)
    def test_update_img(self, ssot, test_data):
        """Site update image"""
        for row in test_data['data']:
            ssot.locations_page()
            ssot.view_first_location()
            ssot.button_update_img()
            select_file = self.route_img()
            ssot.form_img(row['NAME'], select_file)
            ssot.click_update_button()
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.UPDATE_IMG), f"The alert text is not {self.UPDATE_IMG} as we expected."

    @pytest.mark.parametrize('test_data', ['test_delete_img'], indirect=True)
    def test_delete_img(self, ssot, test_data):
        """Site delete image"""
        ssot.locations_page()
        ssot.view_first_location()
        ssot.button_delete_img()
        assert ssot.alert_is_present(), "The add alert is not present."
        assert ssot.check_alert_text(self.DELETE_IMG), f"The alert text is not {self.DELETE_IMG} as we expected."

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        ssot.locations_page()
        ssot.view_first_location()
        ssot.go_to_tab('Change Log')
        assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Site - test_load_data_edit in Site with the required fields by model. """
        ssot.locations_page()
        rows_name = ['Status','Description']
        data = ssot.get_info_table_edit(values=["Name"])
        ssot.click_link_text(data[0])
        elements = ssot.get_values_table_details(rows_name)
        ssot.click_edit_button()
        input_values = ssot.get_input_values_form_edit(['Name'])
        select_values = ssot.get_select_values_form_edit(['Status'])
        assert all(element in elements + data for element in input_values + select_values), "in the edit view the required " \
                                                                                     "fields were not loaded,and the " \
                                                                                     "assert fails because it cannot " \
                                                                                     "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_delete_location'], indirect=True)
    def test_delete_location(self, ssot, test_data):
        """ Sites - Delete a location by name. """
        for row in test_data['data']:
            found_contact = ssot.search_location(row['NAME'])
            assert found_contact, f"No location with name {row['NAME']} found."
            ssot.delete_location(row['NAME'])
            assert ssot.check_alert_text(self.delete_location), f"The alert text is not {self.delete_location} as we expected."


@pytest.mark.exports
class TestSiteExports:
        @pytest.mark.parametrize('test_data', ['test_export_locations'], indirect=True)
        def test_export_locations(self, ssot, test_data, rename_download):
            """ location - export csv the current view. """
            ssot.locations_page()
            ssot.click_export_button()
            ssot.export_current_view()

        @pytest.mark.parametrize('test_data', ['test_check_export_locations'], indirect=True)
        def test_check_export_locations(self, ssot, test_data, rename_download):
            """ location - chek the csv in local machine"""
            ssot.locations_page()
            data = ssot.get_data_for_check_export(2)
            file_name = 'locations_export.csv'
            rename_download(name=file_name)
            file_path = os.path.join(os.getcwd(), file_name)
            assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
            csv = ssot.read_csv(file_name)
            assert ssot.check_csv_and_data(data, csv)
            os.remove(file_path)