class Color:
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    DARK_CYAN = '\033[36m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


class Browser:
    FIREFOX = 'FIREFOX'
    CHROME = 'CHROME'


class LocateBy:
    ID = 'ID'
    NAME = 'NAME'
    CSS = 'CSS'
    XPATH = 'XPATH'


def fill_test_case_detail_values(invalid_ips_arr, row):
    """
    Returns an array with the correspondent values from a spreadsheet row
    :param invalid_ips_arr: The current array to fill
    :param row: An array from a spreadsheet row
    :return: The same incoming array with its values
    """
    if invalid_ips_arr['test_case']['test_case_id'] == '' and row['TEST_CASE_ID'] != '':
        invalid_ips_arr['test_case']['test_case_id'] = row['TEST_CASE_ID']

    if invalid_ips_arr['test_case']['build'] == '' and row['BUILD'] != '':
        invalid_ips_arr['test_case']['build'] = row['BUILD']

    if invalid_ips_arr['test_case']['tester'] == '' and row['TESTER'] != '':
        invalid_ips_arr['test_case']['tester'] = row['TESTER']

    if invalid_ips_arr['test_case']['notes'] == '' and row['NOTES'] != 'None':
        invalid_ips_arr['test_case']['notes'] = row['NOTES']

    if invalid_ips_arr['test_case']['c_environment'] == '' and row['C_ENVIRONMENT'] != '':
        invalid_ips_arr['test_case']['c_environment'] = row['C_ENVIRONMENT']
    return invalid_ips_arr
