from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium import webdriver
from ..definitions import CHROMEDRIVER_PATH, FIREFOXDRIVER_PATH
import os


class Driver:

    @staticmethod
    def _get_chrome_options(ui_mode=None):
        options = ChromeOptions()
        options.add_argument('--start-maximized')
        options.add_argument('--no-sandbox')
        options.add_argument("--window-size=1920,1080")
        options.add_argument('--ignore-certificate-errors')
        options.add_experimental_option('useAutomationExtension', False)
        options.add_argument('--disable-dev-shm-usage')
        preferences = {"download.default_directory": os.getcwd(),
                       "profile.default_content_settings.popups": 0,
                       "browser.download.manager.showWhenStarting": False,
                       "browser.helperApps.neverAsk.saveToDisk": "application/x-gzip"}
        options.add_experimental_option('prefs', preferences)
        if ui_mode == "headless":
            options.headless = True
            options.add_argument('--no-sandbox')
            options.add_argument("--headless")
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument("--window-size=1920,1080")
            options.add_argument('--start-maximized')
            options.add_argument('--ignore-certificate-errors')
        return options

    @staticmethod
    def _get_firefox_driver():
        fp = webdriver.FirefoxProfile()
        fp.set_preference("browser.download.folderList", 2)
        fp.set_preference("browser.download.dir", os.getcwd())
        fp.set_preference("browser.download.manager.showWhenStarting", False)
        fp.set_preference("browser.helperApps.alwaysAsk.force", False)
        fp.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/ms-excel")
        driver = webdriver.Firefox(executable_path=FIREFOXDRIVER_PATH, firefox_profile=fp)
        driver.maximize_window()
        return driver

    @staticmethod
    def _create_local_driver(browser, ui_mode=None):
        if browser == 'chrome':
            options = Driver._get_chrome_options(ui_mode=ui_mode)
            driver = webdriver.Chrome(executable_path=CHROMEDRIVER_PATH, options=options)
        elif browser == 'firefox':
            driver = Driver._get_firefox_driver()
        else:
            raise Exception
        return driver

    @staticmethod
    def _create_remote_driver(browser):
        if browser in ['firefox', 'chrome']:
            if browser == 'chrome':
                options = Driver._get_chrome_options(ui_mode='headless')
            elif browser == 'firefox':
                options = FirefoxOptions()
            capabilities = {
                'browserName': browser.lower(),
                'platform': 'LINUX'}
            configurations = {
                "timeout": 800000,
            }
            driver_config = {'capabilities': capabilities, 'configurations': configurations}
            driver = webdriver.Remote(
                command_executor='devops-qe-seleniumgrid.apps.gp-1-prod.openshift.cignacloud.com/wd/hub',
                desired_capabilities=capabilities, options=options)
            return driver
        else:
            raise Exception

    @staticmethod
    def create_driver(instance, browser, ui_mode=None):
        if instance == 'local':
            driver = Driver._create_local_driver(browser, ui_mode=ui_mode)
        elif instance == 'grid':
            driver = Driver._create_remote_driver(browser)
        else:
            raise Exception
        driver.set_page_load_timeout(60)
        driver.implicitly_wait(10)
        return driver