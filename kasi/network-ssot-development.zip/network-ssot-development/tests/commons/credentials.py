from ndosecrets import get_secret,get_local_secret

DEBUG = False
SEND_TC_RESULTS = True

NAUTOBOT_ENVIRONMENT = get_local_secret("environment")
VAULT_SETTINGS = get_secret(f"ssot/environment/{NAUTOBOT_ENVIRONMENT}")
api_key = VAULT_SETTINGS.get('testing_api_key')
DEVELOPMENT = "http://cvlappxd33547.silver.com:8080"
STAGING = "http://cvlappxd35871.silver.com:8080"

def get_project_credentials(project_name='DJANGO'):
    """work around until the secrets library is fully integrated"""
    try:
        username = VAULT_SETTINGS.get("testing_username")
        password = VAULT_SETTINGS.get("testing_password")

        return username, password
    except:
        raise Exception("Error on Credentials retrieval")