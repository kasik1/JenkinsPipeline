btn_ok = "/Window/Window[@Name='System Information']/Button[@ClassName='Button'][@Name='OK']"
btn_ok_systeminfo = "/Window/Window[@Name='System Information']/Button[@ClassName='Button'][@Name='OK']"
wnd_main_class="/Window[@ClassName='KCMLMasterForm_32']"
tree_submenu = "/Window/Pane/Tree/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem/TreeItem[@Name='{}']"
accmaintenance = "Accounts Payable|Account Maintenance"
docentry = "Accounts Payable|Document Entry"
docentry_expanded = "Document Entry"     #Remove after expand menu issue fixed
cashbook = "General Ledger|Cashbook Menu|Cashbook"
gl_systemparameters = "General Ledger|System Maintenance|System Parameters"
treeGLUserDetails = "General Ledger|System Maintenance|User Details"
gl_userdetails_expanded = "User Details"    #Remove after expand menu issue fixed
agentServicePath = "/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[contains(@Name,'{}')]"
txtkcc = "kcc"
txtCRMmanager = "CRMMAN"
ActionConfirm = "ActionConfirm"
PressRETURNtoResume = "Press RETURN to Resume"

# Window - Keyloop Drive WorPlace
ap_systemparameters = "Accounts Payable|System Maintenance|System Parameters"
ap_systemparameters_expanded = "System Maintenance|System Parameters"
ap_remittances = "Accounts Payable|Remittances"
ap_display = "Accounts Payable|Account Display"
ar_display = "Accounts Receivable|Account Display"
ap_display_expanded = "Account Display"
arAccMaintenance = "Accounts Receivable|Account Maintenance"
arDocEntry = "Accounts Receivable|Document Entry"
arStatements = "Accounts Receivable|Statements"
treeGLConverttToConsumerFinance = "General Ledger|Payment Management|Convert to Consumer Finance"
gl_takeEarnings = "General Ledger|Payment Management|Take Earnings"
GLReschedulePayment = "General Ledger|Payment Management|Reschedule Payments"
gl_legalentity = "General Ledger|System Maintenance|Legal Entity"
gl_cashbooksetup = "General Ledger|Cashbook Menu|Cashbook Setup"
nl_epaymentbalancesheetmap = "Nominal Ledger|Miscellaneous Options|Electronic Payment Balance Sheet Map"
sl_takedeposits = "Sales Ledger|Take Deposits"
nominalledger = "//TreeItem[@Name='Nominal Ledger']"
sl_displayaccounts = "Sales Ledger|Display Accounts"
wndKeyloopDriveWorkPlace = "Keyloop Drive WorkPlace"
treeitemBranchControls = "Vehicle Management|System Maintenance|Branch Controls"
treeitemManageAdvancedInvoices = "Vehicle Management|Manage Advanced Invoices"
menuitemSystemBrowser = "//MenuItem[contains(@Name,'System Browser')]"
treeitemVehicleStockManagement = "Vehicle Management|Vehicle Stock Management"
wndVehicleStockManagementwrapper = "Vehicle Stock Management"
tblProductFeature = "WORKPLACE.GB_clsFeaturesConfiguration-1.kcmlgrid-1"
menuitemTakedeposits = "Tools|Take deposits"
menuEventTypes = "CRM|Miscellaneous Options|Events and Tasks Lookups|Event Types"
treeitemCRM = "/Window/Pane/Tree/TreeItem[@Name='CRM'][2]"
treeitemCRMwrapper = "CRM|CRM"
treeitemUserRoles= "System Utilities|Management Menu|User Roles"
nl_systemparameters = "Nominal Ledger|System Maintenance|System Parameters"
treeitemARTurnoverAnalysisReport = "Accounts Receivable|Reports and Enquiries|Turnover Analysis Report"
treeitemAPTurnoverAnalysisReport = "Accounts Payable|Reports and Enquiries|Turnover Analysis Report"
treeitemGLVerifyARAPSummary = "General Ledger|Miscellaneous Options|Verification Options|Verify AR/AP Summary"
treeitemRebuildARAPSummary = "General Ledger|System Maintenance|Rebuild Options|Rebuild AR/AP Summary"


#window - AVM sales administrator
wndAVMsalesadmin = "/Window[starts-with(@Name,'AVM Sales Administrator')]"
wndAVMSalesAdministrator = "AVM Sales Administrator"
tblOtherOptions = "Other Options"

# Window - System structure
wndSysStructure = "System Structure"
btn_sysstructure_ok = "/Window/Window/Pane/Button[@Name='OK']"

# #Window - Sales Executive
wndSalesExecutive = "/Window[starts-with(@Name,'Sales Executive')]"
tbl_OtherOptions = "SalesExecHome2-1.GB_clsMenuFav-2.kcmlgrid-1"
btn_logout = "/Window[starts-with(@Name,'Sales Executive')]/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Log out']"
btn_logout_yes="//Button[@Name='Yes']"
sl_generateandprintdocuments = "Sales Ledger|Generate & Print Documents"
sl_einvoiceregister = "Sales Ledger|E-Invoice Register"
tree_systemmenu_main="/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Tree[@ClassName='Tree_Class']"
wndSalesExecutivewrapper = "Sales Executive"
btnLogoutwrapper = "Log out"

#Window - Advanced Options
wndAdvOptions = "Advanced Options"
btnHome = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@ClassName='BarBase']/Button[@Name='dgo_ObjectID=WORKPLACE.WebSchemeMenu.toolbar.FILE_HOME.Home;']"
mnuSUUserDetails = "System Utilities|Management Menu|User Details"
wndAdvancedOptions = "Advanced Options"
mnuSUSysParameters = "System Utilities|System Maintenance|System Parameters"
treePermissions="System Utilities|Management Menu|Permissions & Security"
mnuProductFeatures  = "System Utilities|Management Menu|Product Features"
mnuCRMUserDetails = "CRM|System Maintenance|User Details"
toolbarHomewrapper = "Home"
treeMasterPostingTables = "Accounts Posting Tables|Master Table Maintenance|Master Posting Tables"
#Window - System Browser
treeSysBrowser = "System Utilities|System Browser"
wndSystemBrowser = "/Window[starts-with(@Name,'System Browser')]"
btnFind = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@Name='dgo_ObjectID=mnuMain.toolbar;']/Button[@Name='dgo_ObjectID=mnuMain.toolbar.ViewFindTable;']"
btnJSON = "//Window[@Name='Blob Viewer']/Button[@Name='JSON']"
btnJSONexplorerclose = "//Window[@Name='JSON Object Explorer']/Button[@Name='Close']"
btnBLOBviewerclose = "//Window[@Name='Blob Viewer']/Button[@Name='Close']"
lstBlobs = "//Window[@Name='Blob Viewer']/Pane/ListBox_Class[@AutomationId='listBlobs']"
wndSystemBrowserWrapper = "System Browser"
wndDisplayTablewrapper = "Display Table"
tableGL_11_arapsummSubledgersummary = "GL_11_arapsumm - Sub-ledger summary"
tableVMxsorder="VM_00_xsorder - External sales order headers"
txtmodule = "VM"
txtTable = "vtype"
txtSearchCol = "VTYPE"
tblVtypeTablename = "VM_11_vtype - Vehicle types"

#Window - search Filter
wndSearchFilter = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Search Filter']"
txtmodulecode= "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Search Filter']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@Name='Module code']/Edit[@Name='Module code']"
txttablename= "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Search Filter']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@Name='Table name']/Edit[@Name='Table name']"
btnNextSearchFilter = "/Window/Window[@Name='Search Filter']/Pane/Button[@Name='Next']"
txtUserID = "Pane/Pane/Edit[@Name='User ID']"
dgoGridFilter = "GridFilter"
wndFilter = "Filter"
toolbarToolsFilter = "ToolsFilter"
toolbarToolsColumns = "ToolsColumns"
wndMaintainColumnSelection = "Maintain Column Selection"
btnMaximize = "Maximize"
btnInvert = "Invert"
listitemPERIOD = "PERIOD - Period"
menuBLOBs = "BLOBs..."
wndBlobViewer = "Blob Viewer"
listitemEINVOICE = "EINVOICE"
btnJSONwrapper = "JSON"
wndJSONObjectExplorer = "JSON Object Explorer"
headerColumnField = "Column/Field"
headerCondition = "Condition"
headerValue = "Value"

#Window - Table Search
wndTableSearch = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Table Search']"
tblgridSingle = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Table Search']/Pane[@Name='Table Search']/Table[@Name='dgo_ObjectID=gridSingle;']"

#Window - User Table Searches
wndUserTableSearch  = "/Window/Window[@Name='User Table Searches']"

#Window - Spooler
treeSpoolQueueControl = "System Utilities|Spool Utilities|Spool Queue Control"
wndSpooler = "Spooler Control"
tblprinteddoc = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@ClassName='KTab']/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@ClassName='KClientGrid_32']/DataGrid[@ClassName='KCMLGridPad_32']/DataItem[@Name='{}']"
btnspoolerexit = "/Window[contains(@Name,'Spooler Control')]/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@ClassName='BarBase']/Button[@Name='Exit']"

#window - agent controller
mnuagentcontroller = "System Utilities|System Agent|Agent Controller"
wndagentcontroller="Agent Controller"


#Window - User Editor
wndUserEditor = "/Window[starts-with(@Name,'User Editor')]"
txtUESearch = "Pane/Pane/Pane/Pane[@Name='Search']/Edit[@Name='Search']"
btnleavingdate = "GB_UserEditor-1.GB_clsUserList-1.picbutton-4"
btnShowLeavers = "Pane/Pane/Pane/Button[@Name='Show leavers']"
btnResetLeaving = "GB_UserEditor-1.GB_clsUserList-1.picbutton-4"
tblUserLevelSettings = "GB_UserEditor-1.GB_clsRoleLevelSettingsU-1.kcmlgrid-1"

#Window - Set Leaving Date
wndLeavingDate = "/Window/Window[@Name='Set Leaving Date']"
txtLeavingDate = "Pane/Edit[@Name='Leaving date']"
btnLDOK = "Pane/Button[@Name='OK']"

#Window - CRM User details
wndCRMUserdetails = "/Window/Window[contains(@Name,'CRM User Details')]"
toolbarExit2 = "mnuFileExit"
wizardName = "Wizard View"
wndCRMUserdetailswrapper = "CRM User Details"
txtUserIDwrapper = "User ID"
txtRoleIDwrapper = "Role ID"
tabitemAccessControl = "Access Control"
checkboxCanamendcommunicationFromfield = "Can amend communication “From” field?"
dropdown_nameUsertype = "User type (role or user)"
listitemUserwrapper = "User"
listitemRolewrapper = "Role"
checkboxAutomaticallypopulate = "Automatically populate notes on manual enquiry tasks and events"
tabitemTasksEvents = "Tasks / Events"
tabitemWizards = "Wizards"
dgowizardcreatetask = "WIZARDS_gridWizards.Pad.Row7.Cell2.dbedit"
txtQuickEvent = "QuickEvent"
txtFollowupEventType = "FollowupEventType"
txtFSTO = "FSTO"
dgowizard = "WIZARDS_gridWizards"
headerWizardView = "Wizard View"

#Window - User Details
wndUserdetails1 = "/Window/Window[contains(@Name,'User Details')]"
btnDisplayleavers = "Pane/Pane/Pane/Pane/Button[@Name='Display leavers activity in dashboard']"
# toolbar_amend_userdetails = "mnuMain.toolbar.mnuEditAmend;"
# toolbar_save_userdetails = "mnuMain.toolbar.mnuEditSave;"
toolbarAmend = "mnuEditAmend"
toolbarSave = "mnuEditSave"
toolbarExit = "mnuFileExit"
#Window - Load Team
wndLoadTeam = "/Window/Window/Window[@Name='Load Team']"
listItemCallList = "CallList	Call List Allocation"
#Window - Select From Team
wndSelectFromTeam = "/Window/Window/Window[@Name='Select From Team']"
mnuCallAllocate = "CALL - CALL|Allocate - Allocate"
mnuAllocate = "Allocate - Allocate"

#window - maintain table
btn_destructive = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar/Button[@Name='dgo_ObjectID=mnuMain.toolbar.ViewEnableDestructiveOptions;']"
wndMaintainTable = "Maintain Table"
table_Rows = "/Window/Window/Pane[@ClassName='KCMLDlgWndClass_32']/Table/Table[@ClassName='KCMLGridPad_32']/Custom[@Name='dgo_ObjectID=gridTable.Pad.Row2;']"
btn_Yes = "/Window/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Confirm Delete']/Button[@Name='Yes']"
checkbox_destructive = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar/CheckBox[@Name='dgo_ObjectID=mnuMain.toolbar.ViewDisableDestructiveOptions;']"

# window - exit keyloop drive
wndexitkeyloopdrive = "/Window/Window[starts-with(@Name,'Exit Keyloop Drive')]"
wndExitKeyloopDrivewrapper = "Exit Keyloop Drive"

wndSysBrowser = "System Browser"
wndUserDetails = "User Details"

#Window - System Parameters
# wndSysParameters = "System Parameters"
wndSysParameters = "Visual Editor"
txtWANumber = "From WhatsApp Number"
txtFromSMSNumber = "From SMS Number"
checkboxEnablemultipleSMSWhatsAppnumbers = "Enable multiple SMS/WhatsApp numbers"
checkboxPreferredWhatsAppNumber =   "otherwise Email or SMS or WhatsApp will not be sent."

#Window - Table Properties
wndTableProperties = "Table Properties"

treeVMShowroom = "Vehicle Management|Showroom"


# Window - Print SL Day Books
treePrintSLDayBooks = "Sales Ledger|Print Daybooks"
WndPrintSLDaybooks="Print SL daybooks"
btnPrint = "Print"
btnDone = "Done"

# Window - Print NL Day Books
treePrintNLDayBooks = "Nominal Ledger|Print Daybooks"
WndPrintNLDaybooks="Print daybooks"
btnExit = "Exit"
dataitemAdoptedwrapper = "Adopted"

# Window - Print PL daybooks
treePrintPLDayBooks = "Purchase Ledger|Print Daybooks"
wndPrintPLdaybooks = "Print PL daybooks"
wndSelectItemFromMenu = "Select Item From Menu"

# Window - CRM Manager
toolBarMenu = "//ToolBar/Button[contains(@Name,'VIEW_PROFILE.Menu')]"

#window - Logging
btnLogging = "toolbar.Tool2"
wndLoggingCtrlPanel = "Logging Control Panel"
chkkcmlprofiling = "KCML runtime profiling"
chkGenerateXml = "Generate XML"
txtProfiler = "Profile file name"
btnAction = "cmdProfAction"
btnProfilerLogging = "WORKPLACE.WebSchemeMenu.toolbar.Tool1"

#window - System Menu
toolBarSystemMenu = "dgo_ObjectID=WORKPLACE.WebSchemeMenu.toolbar.WORKPLACE.VIEW_PROFILE.System_Menu;"




