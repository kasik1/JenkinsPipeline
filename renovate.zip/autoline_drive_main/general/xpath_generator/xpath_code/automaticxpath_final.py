from flaui.lib.pythonnet_bridge import setup_pythonnet_bridge
from robot.api.deco import keyword

setup_pythonnet_bridge()

import time
from FlaUI.Core import Application
from FlaUI.Core.Input import Keyboard
from FlaUI.UIA3 import UIA3Automation
from FlaUI.UIA2 import UIA2Automation
from FlaUI.Core.Patterns import IWindowPatternPropertyIds
from FlaUI.Core.Input import Wait
from FlaUI.Core.AutomationElements import AutomationElementExtensions
from FlaUI.Core.AutomationElements import ListBoxItem
from FlaUI.Core.AutomationElements import AutomationElement
from FlaUI.Core.Definitions import ControlType
from FlaUI.Core.Conditions import ConditionFactory
from FlaUI.Core.Patterns import WindowPatternBase
from FlaUI.Core import FrameworkAutomationElementBase
from FlaUILibrary.flaui.util.automationinterfacecontainer import AutomationInterfaceContainer
from FlaUILibrary.flaui.interface import WindowsAutomationInterface
from FlaUILibrary.keywords import KeyboardKeywords
from robot.api.deco import keyword 
from robot.libraries.BuiltIn import BuiltIn
from System import TimeSpan
import os
import re


# automation = UIA3Automation()
# app = Application.Attach(2328)
# mainWindow = app.GetMainWindow(automation)
# cf = automation.ConditionFactory


def Get_Active_Window(pid):
    automation = UIA3Automation()
    app = Application.Attach(pid)
    mainWindow = app.GetMainWindow(automation)
    cf = automation.ConditionFactory
    mainWindow.Focus()
    button = mainWindow.FindAllDescendants(cf.ByControlType(ControlType.Window))
    # print(button)
    button_count = len(button)
    print(button_count)
    if (button_count==0):
        # AutomationElementExtensions.DrawHighlight(mainWindow)
        windowname_final=mainWindow.Name
        return mainWindow
    return button[button_count-1] 

# file_paths = ["path/to/your/file1.py", "path/to/your/file2.py", "path/to/your/file3.py"]



def Update_Locators_in_py_File(pid, locator_type, controltype="Button",element_name=None):
    activewindow = Get_Active_Window(pid)
    windowname_final = activewindow.Name
    if "BP48 MASTER" in windowname_final:
        result=windowname_final.split(' ')[0].strip()
    else:
        result = windowname_final.split('-')[0].strip()
        result = result.replace(" ", "")
    print(result)
    automation = UIA3Automation()
    cf = automation.ConditionFactory
    file_path = f"{result}.py"
    if controltype == "Button":
        control_type_condition = ControlType.Button
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Pane))
    elif controltype == "Edit":  # Add more conditions as needed
        control_type_condition = ControlType.Edit
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Pane))
    elif controltype == "CheckBox":  # Add more conditions as needed
        control_type_condition = ControlType.CheckBox
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Pane))
    elif controltype == "Table":  # Add more conditions as needed
        control_type_condition = ControlType.Table
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Pane))
    elif controltype == "RadioButton":  # Add more conditions as needed
        control_type_condition = ControlType.RadioButton
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Pane))
    elif controltype == "TabItem":  # Add more conditions as needed
        control_type_condition = ControlType.TabItem
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Tab))
    elif controltype == "TreeItem":  # Add more conditions as needed
        control_type_condition = ControlType.Tree
        # if element_name is None:
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Tree))
        # else:
        #     panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Tree) and cf.ByName(element_name))
    elif controltype == "ToolBar":  # Add more conditions as needed
        control_type_condition = ControlType.Button
        panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.ToolBar))
    # panes = activewindow.FindAllDescendants(cf.ByControlType(ControlType.Pane))
    pane_count = len(panes)
    print(f"Total Panes: {pane_count}")
    with open(file_path, 'a') as file:
        file.write(f"############ All '{controltype}' Locators with '{locator_type}' property are listed below ###################\n")
        for count in range(pane_count):
            pane = panes[count]
            if element_name is None:
                    buttons = pane.FindAllChildren(cf.ByControlType(control_type_condition))
            else:
                buttons = pane.FindAllChildren(cf.ByControlType(control_type_condition) and cf.ByName(element_name))
            for button in buttons:
                if locator_type == "name":
                    button_name = button.Name
                elif    locator_type == "description":
                        button_name = button.Patterns.LegacyIAccessible.Pattern.Description.Value
                        button_name1 = button_name.replace("dgo_ObjectID=", "")
                        button_name1 = button_name1.replace(";", "")
                        button_name=button_name1
                if len(button_name) != 0:
                        if controltype == "Button":
                            variable_name = f'btn{button_name}'
                        elif controltype == "Edit":  # Add more conditions as needed
                            variable_name = f'txt{button_name}'
                        elif controltype == "TabItem":  # Add more conditions as needed
                            variable_name = f'tab{button_name}'
                        elif controltype == "ToolBar":  # Add more conditions as needed
                            variable_name = f'tbr{button_name}'
                            # variable_name = f'tool_{button_name}'
                        elif controltype == "Table":  # Add more conditions as needed
                           button_name1=button.Name 
                           button_name1 = button_name1.replace("dgo_ObjectID=", "")
                           button_name1 = button_name1.replace(";", "")
                           button_name=button_name1
                           result = button_name1.split('.')[0]
                           variable_name = f'tbl{result}'
                        elif controltype == "CheckBox":  # Add more conditions as needed
                            variable_name = f'chk{button_name}'
                        elif controltype == "RadioButton":  # Add more conditions as needed
                            variable_name = f'rbn{button_name}'
                        elif controltype == "TreeItem":  # Add more conditions as needed
                            button_name1=button.HelpText 
                            button_name1 = button_name1.replace("dgo_ObjectID=Tree.", "")
                            button_name1 = button_name1.replace(";", "")
                            segments = button_name1.split('|')
                            last_value = segments[-1].strip()
                            variable_name = f'tree{last_value}'
                        final_name = variable_name
                        if "..." in final_name:
                            finalname2 = final_name.rsplit('...', 1)
                            result = finalname2[-2]
                            va = result.replace(' ', '')
                            value = va.replace(';', '')
                        else: 
                            finalname2 = final_name.rsplit('.', 1)
                            result = finalname2[-1]
                            va = result.replace(' ', '')
                            value = va.replace(';', '')
                            pattern1 = re.compile('[()&/\s-]')
                            value = re.sub(pattern1, '', value)
                        if locator_type == "name":
                            if controltype == "TreeItem":
                                tree_help_index = button_name1.rfind('.')  
                                if tree_help_index != -1:  # Check if '.' exists in the string
                                    final_help = button_name1[tree_help_index + 1:]
                                    locator_info = f'{value} = "{final_help}"'
                                    file.write(f"{locator_info}\n")
                            if controltype == "Toolbar":
                                locator_info = f'tbr{value} = "{button_name}"'
                                file.write(f"{locator_info}\n")
                            else:
                                locator_info = f'{value} = "{button_name}"'
                                file.write(f"{locator_info}\n")
                        elif    locator_type == "description":
                            if controltype == "Button":
                                locator_info = f'btn{value} = "{button_name}"'
                                file.write(f"{locator_info}\n")
                            if controltype == "Edit":
                                locator_info = f'txt{value} = "{button_name}"'
                                file.write(f"{locator_info}\n")
                            if controltype == "CheckBox":
                                locator_info = f'{value} = "{button_name}"'
                                file.write(f"{locator_info}\n")
                            if controltype == "RadioButton":
                                locator_info = f'{value} = "{button_name}"'
                                file.write(f"{locator_info}\n")
                        elif locator_type == "xpath":
                            if controltype == "ToolBar":
                                locator_info = f'{value} = "//Button[@Name=\'{button_name}\']"'
                                file.write(f"{locator_info}\n")
                            else:
                                locator_info = f'{value} = "//{controltype}[@Name=\'{button_name}\']"'
                                file.write(f"{locator_info}\n")






############################ ALL Name Properties ###################
# Documentation: Replace the below process id 

# Update_Locators_in_py_File(9172,"name","Button")
# Update_Locators_in_py_File(9172,"name","Table")
# Update_Locators_in_py_File(9172,"name","Edit")
# Update_Locators_in_py_File(9172,"name","Edit")
# Update_Locators_in_py_File(9172,"name","TabItem")
# Update_Locators_in_py_File(9172,"name","ToolBar")
# Update_Locators_in_py_File(9172,"name","TreeItem","Ad-hoc Enquiry")
# Update_Locators_in_py_File(9172,"name","TreeItem")
# Update_Locators_in_py_File(9172,"name","CheckBox")
# Update_Locators_in_py_File(9172,"name","RadioButton")

################## Getting description for buttons and textboxes #############
# Update_Locators_in_py_File(9172,"description","Button")
# Update_Locators_in_py_File(9172,"description","Edit")
# Update_Locators_in_py_File(9172,"description","CheckBox")
# Update_Locators_in_py_File(9172,"description","RadioButton")