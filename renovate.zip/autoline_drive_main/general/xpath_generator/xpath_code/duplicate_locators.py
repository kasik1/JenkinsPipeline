import os
def get_py_files(relative_path):
    current_directory = os.getcwd()
    root_folder = os.path.join(current_directory, relative_path)
    print(root_folder)
    py_files = []
    for root, dirs, files in os.walk(root_folder):
        for file in files:
            if file.endswith(".py"):
                py_files.append(os.path.join(root, file))
    return py_files
 
def Check_Key_Value_Duplicates_In_Py(relative_path,file_number="multiple",verification_type="line"):
    if file_number == "multiple" and verification_type=="line":
            
            duplicates = {}
            all_lines_seen = {}  # Track all lines seen in all files: {line: [(file_path, line_num), ...]}
            try:
                print("printing multiple file duplicates")
                print(" " )
                file_paths = get_py_files(relative_path)
                for file_path in file_paths:
                    with open(file_path, 'r') as file:
                        for line_num, line in enumerate(file, 1):
                            if line.strip() and not line.strip().startswith("#"):
                                if line in all_lines_seen:
                                    if all_lines_seen[line][0] != file_path:
                                        if line not in duplicates:
                                            duplicates[line] =[all_lines_seen[line]]
                                        duplicates[line].append([file_path,line_num])
                                else:
                                    all_lines_seen[line] = (file_path, line_num)
                
                # for line, occurrences in duplicates.items():
                #     print(f"******************'{line.strip()}'******************")
                #     print(" ")
                #     for file_path, line_num in occurrences:
                #         print(occurrences.strip())
                #         print(f" found in {file_path} at line {line_num}\n")
                if len(duplicates) > 0:
                    # Duplicates found, perform actions
                    print("Duplicates found:")
                    for line, occurrences in duplicates.items():
                        print(f"******************'{line.strip()}'******************")
                        print(" ")
                        for file_path, line_num in occurrences:
                            print(f"Found in {file_path} at line {line_num}\n")
                            return   True      
                else:
                    # No duplicates found, perform actions
                    print("No duplicates found." ) 
                    return   False                  
            except FileNotFoundError as e:
                print("File not found:", e)
                return False
 
    elif file_number == "single" and verification_type == "line":
        
        try:
            print("Printing same file duplicates")
            print(" ")
            file_paths = get_py_files(relative_path)
            for file_path in file_paths:
                all_lines_seen = {} 
                duplicates = {}  # Reset for each file to track lines within the current file
                with open(file_path, 'r') as file:
                    for line_num, line in enumerate(file, 1):
                        if line.strip() and not line.strip().startswith("#"):
                            if line in all_lines_seen:
                                if line not in duplicates:
                                    duplicates[line] = [all_lines_seen[line]]  # Store the first occurrence
                                duplicates[line].append((file_path, line_num))  # Append current occurrence
                            else:
                                all_lines_seen[line] = (file_path, line_num)
                
            # Print duplicates found within the same file
                for line, occurrences in duplicates.items():
                    if len(occurrences) > 1:  # Ensure there are actually duplicates before printing
                        print(f"******************'{line.strip()}'******************")
                        print(" ")
                        for file_path, line_num in occurrences:
                            print(f"Found in {file_path} at line {line_num}\n")
                            return True
                    else:
                        return False   
        except FileNotFoundError as e:
            print("File not found:", e)
            return False


    elif file_number=="multiple" and verification_type=="keyorvalue":
        before_equal_duplicates = set()
        after_equal_duplicates = set()
        all_lines_seen={}
        duplicates = {}
        try:
            print("printing key or value match  duplicates")
            print(" ")
            file_paths = get_py_files(relative_path)
            # print(file_paths)
            for file_path in file_paths:
                with open(file_path, 'r') as file:
                    for line_num, line in enumerate(file, 1):
                        try:
                            equal_index = line.index("=")
                        # Remove spaces within the strings, not just trim them
                            before_equal = line[:equal_index].replace(' ', '').strip()
                            after_equal = line[equal_index+1:].replace(' ', '').strip()
                            if line.strip() and not line.strip().startswith("#"):
   
                                if (before_equal in before_equal_duplicates) or (after_equal in after_equal_duplicates):
                                    if line in all_lines_seen:
                                        if line not in duplicates:
                                            duplicates[line] = [all_lines_seen[line]]
                                        duplicates[line].append([file_path,line_num])
                                    else:
                                        all_lines_seen[line] = (file_path, line_num)
                                else:
                                    before_equal_duplicates.add(before_equal)
                                    after_equal_duplicates.add(after_equal)
   
                        except ValueError:
                        # "=" not found in line, you might want to handle or ignore such lines
                            pass
            for line, occurrences in duplicates.items():
                    print(f"******************'{line.strip()}'******************")
                    print(" ")
                    for file_path, line_num in occurrences:
                        print(f" found in {file_path} at line {line_num}\n")
        except FileNotFoundError as e:
            print("File not found:", e)
            return False
 
       
    else:
        print("Invalid arguments provided .Valid arguments are \n 1.file_number == multiple and verification_type==line \n 2.file_number == single and verification_type==line \n 3.ile_number==multiple and verification_type==keyorvalue")
relative_path = r"autoline_drive_main\resources"
# second_relative_path = r"autoline_drive_main\general"

# full_path = os.path.join(relative_path, second_relative_path)
value=Check_Key_Value_Duplicates_In_Py(relative_path,file_number="multiple",verification_type="line")
print(value)
# val=Check_Key_Value_Duplicates_In_Py(second_relative_path,file_number="multiple",verification_type="line")
# if val == False and val1 == False:
#   print(val)


# Check_Key_Value_Duplicates_In_Py(relative_path,file_number="single",verification_type="line")
# Check_Key_Value_Duplicates_In_Py(relative_path,file_number="multiple",verification_type="keyorvalue")
# Check_Key_Value_Duplicates_In_Py(relative_path,file_number="single",verification_type="keyorvalue")