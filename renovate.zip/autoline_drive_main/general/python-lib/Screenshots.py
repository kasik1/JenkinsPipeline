from PIL import ImageGrab
import datetime
import os

def take_screenshot(tag_name):
    
    # Get the current directory
    current_directory = os.getcwd()

    # Combine the current directory with the provided file path
    full_path = os.path.join(current_directory, "Screenshots")

    print(f"Screenshot : {current_directory}")

    # Create the directory if it doesn't exist
    os.makedirs(full_path, exist_ok=True)

    # Capture screenshot
    screenshot = ImageGrab.grab()

    # Save screenshot with the tag name as the filename
    # timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    file_name = f"{tag_name}.png"
    file_path = os.path.join(full_path, file_name)
    
    # Save the screenshot in binary mode
    screenshot.save(file_path, "PNG")

    print(f"Screenshot saved: {file_path}")
