import json
import os
import base64
import psutil
from robot.api.deco import keyword

class DataContainer:
    def __init__(self):
        self.productfeatures = {}
        self.moduleparameters = {}

# Instantiate the DataContainer class
container = DataContainer()

@keyword
def getProductFeatureSet(feature_list,filepath):

    current_directory = os.getcwd()
    print(current_directory)
    relative_path =  filepath
    path = os.path.join(current_directory, relative_path)
    print(path)

    with open(path) as file:
        data = json.load(file)
    
    currentTestInfo = {}
    for feature in feature_list:
        currentTestInfo.update(data[feature])
    print(currentTestInfo)

    container.productfeatures = currentTestInfo

    for key in container.productfeatures.keys():
        value = container.productfeatures[key]['enabled']
        value_str = str(value)
        print(key,value_str)

    # Serialize the container object to a JSON string
    container_json = json.dumps(container.__dict__)
    print(container_json)

    # Encode the container_json string into a sequence of bytes
    container_bytes = container_json.encode()

    # Convert the container_bytes to a Base64 string
    container_base64 = base64.b64encode(container_bytes).decode()

    return container_base64

@keyword
def kill_process_by_name():
  process_name='kclient.exe'
  for process in psutil.process_iter(['pid', 'name']):
    if process.info['name'] ==process_name :
      try:
        process.terminate()
        print(f"Process '{process_name}' (PID: {process.info['pid']}) terminated successfully.")
      except psutil.NoSuchProcess:
        print(f"No such process with name '{process_name}'.")
      except psutil.AccessDenied:
        print(f"Access denied to terminate process '{process_name}' (PID: {process.info['pid']}).")
      except psutil.ProcessLookupError:
        print(f"Error occurred while terminating process '{process_name}' (PID: {process.info['pid']}).")