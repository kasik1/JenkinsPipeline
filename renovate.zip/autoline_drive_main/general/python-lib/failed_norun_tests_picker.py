import json
import pymongo
import xml.etree.ElementTree as ET
import sys
from latesttestset import get_testsetname
import subprocess
import os

dbclient = "mongodb://c05drddrv969.dslab.ad.adp.com:27017"
dbname = "ivc"
collectionname = "results"

def connect_to_mongo_db():
    myclient = pymongo.MongoClient(dbclient)
    mydb = myclient[dbname]
    mycol = mydb[collectionname]
    return mycol

def get_failed_tests(testsetname):
    collection = connect_to_mongo_db()
    query = {
        "testsetname": testsetname,
        "status": {"$in": ["Failed"]},
        "name": {"$regex": "^RBT_"}
    }
    print(f"Executing query: {query}")
    results = collection.find(query)
    tests = list(results)
    print(f"Number of tests found: {len(tests)}")
    return tests

def get_NoRun_tests(testsetname):
    collection = connect_to_mongo_db()
    query = {
        "testsetname": testsetname,
        "status": {"$in": ["No Run"]},
        "name": {"$regex": "^RBT_"}
    }
    print(f"Executing query: {query}")
    results = collection.find(query)
    tests = list(results)
    print(f"Number of tests found: {len(tests)}")
    return tests


if len(sys.argv) > 1:
    arg_value = sys.argv[1]
    print(arg_value)
else:
    arg_value = None

testsetname = get_testsetname(arg_value)
names = ""

if testsetname:
    failed_tests = get_failed_tests(testsetname)
    norun_tests = get_NoRun_tests(testsetname)
    data = [norun_tests,failed_tests]
    names = []
    for d in data:
        names.extend([item['name'] for item in d])
        
    with open("C:\\action-runner\\_work\\taf-ivc-desktop-automation\\taf-ivc-desktop-automation\\test_names.json", "w") as f:
        json.dump(names, f)

else:
    print("No test set name found.")
    
# base_directory = "C:\\action-runner\\_work\\taf-ivc-desktop-automation\\taf-ivc-desktop-automation\\autoline_drive_main\\testcases"

# for test_id in names:
#     test_file_path = ""
#     if test_id.__contains__("ACC"):
#         if(test_id.__contains__("_D2")):
#             if(test_id.__contains__("AP")):
#                 test_file_path = [f"{base_directory}\\accounts\\ia\\accountpayable.robot"]
#             elif(test_id.__contains__("AR")):
#                 test_file_path = [f"{base_directory}\\accounts\\ia\\accountreceivable.robot"]
#             elif(test_id.__contains__("CB")):
#                 test_file_path = [f"{base_directory}\\accounts\\ia\\cashbook.robot"]
#             elif(test_id.__contains__("GL")):
#                 test_file_path = [f"{base_directory}\\accounts\\ia\\generalledger.robot"]
#         else:
#             if(test_id.__contains__("SL")):
#                 test_file_path = [f"{base_directory}\\accounts\\ia\\salesledger.robot"]
    
#     if test_id.__contains__("AFT"):
#         if(test_id.__contains__("_D2")):
#             # if(test_id.__contains__("AP")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\accountpayable.robot"
#             # elif(test_id.__contains__("AR")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\accountreceivable.robot"
#             # elif(test_id.__contains__("CB")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\cashbook.robot"
#             # elif(test_id.__contains__("GL")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\generalledger.robot"
#             pass
#         else:
#             if(test_id.__contains__("SPOS")):
#                 test_file_path = [f"{base_directory}\\aftersales\\sa\\servicetests.robot"]
#             elif(test_id.__contains__("VHC")):
#                 test_file_path = [f"{base_directory}\\aftersales\\sa\\vhc.robot"]

#     if test_id.__contains__("CM"):
#         if(test_id.__contains__("_D2")):
#             if(test_id.__contains__("CR")):
#                 test_file_path = [f"{base_directory}\\CRM\\ia\\cmcore_d2.robot"]
#             # elif(test_id.__contains__("AR")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\accountreceivable.robot"
#             # elif(test_id.__contains__("CB")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\cashbook.robot"
#             # elif(test_id.__contains__("GL")):
#             #     test_file_path = f"{base_directory}\\accounts\\ia\\generalledger.robot"
#         else:
#             if(test_id.__contains__("CALL")):
#                 test_file_path = [f"{base_directory}\\CRM\\sa\\callcentre.robot"]
#             elif(test_id.__contains__("CAMP")):
#                 test_file_path = [f"{base_directory}\\CRM\\sa\\campaign.robot"]
#             elif(test_id.__contains__("CR")):
#                 test_file_path = [f"{base_directory}\\CRM\\sa\\cmcore.robot"]


#     if test_id.__contains__("VEH"):
#         if(test_id.__contains__("_D2")):
#             if(test_id.__contains__("BO")):
#                 test_file_path = [f"{base_directory}\\vehicles\\ia\\ia_bo.robot"]
#             elif(test_id.__contains__("BSO")):
#                 test_file_path = [f"{base_directory}\\vehicles\\ia\\ia_bso.robot"]
#             elif(test_id.__contains__("FO")):
#                 test_file_path = [f"{base_directory}\\vehicles\\ia\\ia_fo.robot"]
#         else:
#             if(test_id.__contains__("BO")):
#                 test_file_path = [f"{base_directory}\\vehicles\\sa\\sa_bo.robot", f"{base_directory}\\vehicles\\fleet_rentals\\sa_Fleet_rentals.robot"]
#             elif(test_id.__contains__("BSO")):
#                 test_file_path = [f"{base_directory}\\vehicles\\sa\\sa_bso.robot"]
#             elif(test_id.__contains__("FO")):
#                 test_file_path = [f"{base_directory}\\vehicles\\sa\\sa_fo.robot"]
#             elif(test_id.__contains__("SHP")):
#                 test_file_path = [f"{base_directory}\\vehicles\\sa\\sa_shipments.robot"]

#     if(len(test_file_path)>0):
#         Found = False
#         for file in test_file_path:
#             if os.path.exists(file):
#                 try:
#                     command = f"robot -i {test_id} {file}"
#                     print(f"Running command: {command}")
        
#                     # Execute the command
#                     subprocess.run(command, shell=True)
#                     Found = True
#                     break
#                 except:
#                     pass
#             else:
#                 print(f"File {file} does not exist.")

