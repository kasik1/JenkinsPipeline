import openpyxl
import os
from openpyxl.workbook.protection import WorkbookProtection
from datetime import datetime
import pytz
from robot.libraries.BuiltIn import BuiltIn

def check_file_exists(file_path):
    return os.path.exists(file_path)

def append_data_to_excel(file_path, sheet_name, module, testname,status,starttime,endtime):
    if check_file_exists(file_path):
        print(f"The file {file_path} exists.")
    else:
        print(f"The file {file_path} does not exist.")
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = sheet_name
        sheet.cell(row=1, column=1, value="Month")
        sheet.cell(row=1, column=2, value="Date")
        sheet.cell(row=1, column=3, value="Module")
        sheet.cell(row=1, column=4, value="Test Name")
        sheet.cell(row=1, column=5, value="Status")
        sheet.cell(row=1, column=6, value="Start Time")
        sheet.cell(row=1, column=7, value="End Time")
        workbook.save(file_path)

    try:
        # current_date = datetime.now()

        # # Extract and print the current month name
        # current_month_name = current_date.strftime('%B')
        # formatted_date = current_date.strftime('%Y-%m-%d')

        current_date_utc = datetime.utcnow()
        current_month_name = current_date_utc.strftime('%B')
        indian_tz = pytz.timezone('Asia/Kolkata')
        current_date_indian = current_date_utc.replace(tzinfo=pytz.utc).astimezone(indian_tz)
        formatted_date = current_date_indian.strftime('%Y-%m-%d')

        workbook = openpyxl.load_workbook(file_path)
        workbook.security = WorkbookProtection(workbookPassword=None)
        sheet = workbook[sheet_name]
        test_exists_Row=0
        for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=1, max_col=2):
            for cell in row:
                if cell.value == formatted_date:                                      
                    if sheet.cell(row=cell.row,column=4).value == testname:
                        test_exists_Row=cell.row
                        break
                # return None # Return the cell coordinate if found

            # return None  # Return None if the target value is not found
        if(test_exists_Row==0):
            next_row = sheet.max_row + 1
        else:
            next_row=test_exists_Row      

        sheet.cell(row=next_row, column=1, value=current_month_name)
        sheet.cell(row=next_row, column=2, value=formatted_date)
        sheet.cell(row=next_row, column=3, value=module)
        sheet.cell(row=next_row, column=4, value=testname)
        sheet.cell(row=next_row, column=5, value=status)
        sheet.cell(row=next_row, column=6, value=starttime)
        sheet.cell(row=next_row, column=7, value=endtime)
        workbook.save(file_path)
    except Exception as e:
        print(f"Error appending data: {e}")
    finally:
        workbook.close()


