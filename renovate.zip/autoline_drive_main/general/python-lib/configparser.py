import xml.etree.ElementTree as ET
import os
def read_config_xml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    
    config_dict = {}
    
    for add_element in root.findall(".//add"):
        key = add_element.get("key")
        value = add_element.get("value")
        config_dict[key] = value
            
    return config_dict


def get_file_full_path(filename):
    directory=os.getcwd() 
    print(directory)                  
    for root, Directory, files in os.walk(directory):
        if filename in files:
            file_path=os.path.join(root, filename)
    print(file_path)
    file_path_abs=os.path.abspath(file_path)
    return file_path_abs