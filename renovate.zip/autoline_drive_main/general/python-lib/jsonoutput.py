
ROBOT_LISTENER_API_VERSION = 2
import json
import re

class jsonoutput:
    ROBOT_LISTENER_API_VERSION = 2

    def __init__(self, max_seconds=10):
        self.max_milliseconds = float(max_seconds) * 1000

        self.testinfo_dict={}        
        self.kw_final_dict={}
        self.test_dict={}
        self.ts_final_dict={}
        self.suite_dict={}
        self.suite_final_dict={}
        self.suitename=""
        self.tname=""
        self.json_file_path= "jsonlistener_output.json"  
        self.keydict={}
        self.finaldict={}

    def start_suite(self, suite_name, attribute):
        self.suitename=suite_name

    def start_test(self, test_name, attribute):
        self.tname=test_name

        self.testinfo_dict={
            test_name:  {
                'Suite': self.suitename,                
                # 'Status': {**attribute}['status'], 
                'Documentation': {**attribute}['doc'],
                'Tags': {**attribute}['tags'],
                'StartTime':{**attribute}['starttime'],
                # 'EndTime': {**attribute}['endtime'],
                # 'Message': {**attribute}['message'],
                
                        }
                    }
            
        # self.keydict={
        #         'keywords': {**{**self.kw_final_dict}}
        # }
        # self.finaldict={**self.test_dict}

    def end_keyword(self, kw_name, attribute):
        kname=attribute['kwname']
        kname=kname.replace('$',"")
        ktype=attribute['type']
        if ktype!='IF':
            self.kdict={kname:{
                                'Status': {**attribute}['status'],
                                'Type': {**attribute}['type'],
                                # 'Documentation': {**attribute}['doc'],
                                'StartTime': {**attribute}['starttime'],
                                'EndTime': {**attribute}['endtime']

                            }
                        }
                        
  
            self.kw_final_dict={**self.kw_final_dict,**self.kdict}
            self.finaldict={**self.testinfo_dict,**self.kw_final_dict}
            with open(self.json_file_path, "w") as json_file:
                 json.dump(self.finaldict, json_file,indent=4)
    
    
    # def end_test(self, test_name, attribute):
    #     self.test_dict={
    #         test_name:  {
    #             'Suite': self.suitename,                
    #             'Status': {**attribute}['status'], 
    #             'Documentation': {**attribute}['doc'],
    #             'Tags': {**attribute}['tags'],
    #             'StartTime':{**attribute}['starttime'],
    #             'EndTime': {**attribute}['endtime'],
    #             #'Message': {**attribute}['message'],
    #             'keywords': {**{**self.kw_final_dict}}
    #                     }
    #                 }        

    #     self.ts_final_dict={**self.test_dict}

    #     # print(self.ts_final_dict)
    #     # Specify the path to the JSON file
    #     json_file_path = "jsonlistener_output.json"

    #     #Write dictionary data to the JSON file
    #     print("exporting to Json")
    #     with open(json_file_path, "w") as json_file:
    #         json.dump(self.ts_final_dict, json_file, indent=4)
    #     print("end export")
        # with open(json_file_path, 'w') as json_file:
        #     for line in self.ts_final_dict:
        #          json.dump(line, json_file, indent=4)
                # data = json.loads(line)

    # def end_suite(self, suite_name, attribute):
    #     self.suite_dict={
    #         suite_name:
    #          {  'Status': {**attribute}['status'], 
    #             'StartTime':{**attribute}['starttime'],
    #             'EndTime': {**attribute}['endtime'],
    #             'Statistics': {**attribute}['statistics'],
    #             'details': {**self.ts_final_dict}}} 


    #     self.suite_final_dict={**self.suite_final_dict, **self.suite_dict}


        #print(self.suite_final_dict)

        

