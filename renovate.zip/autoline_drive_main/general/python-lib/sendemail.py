
import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import psutil
import subprocess
import shutil
import requests
import base64
import time
import configparser
import xml.etree.ElementTree as ET


def remove_files():
    current_directory = os.getcwd()
    print("Current Directory:", current_directory)
    folder_path=r"C:\ivcjenkins\workspace\REGRESSION_NIGHTLY_RUN_SINGLE\TestLibraries\Reports"
    # Get a list of all files in the folder
    file_list = os.listdir(folder_path)

     
    # Loop through the files and remove .jpg files
    for file_name in file_list:
        if  file_name.lower().endswith(('.png', '.jpg')):
            file_path = os.path.join(folder_path, file_name)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    print(f"Removed {file_name}")
                else:
                    print(f"{file_name} is not a file and won't be removed.")
            except Exception as e:
                print(f"Error occurred while removing {file_name}: {e}")
def move_files_with_extensions(testcasename):
    source_directory = r"C:\ivcjenkins\workspace\REGRESSION_NIGHTLY_RUN_SINGLE\TestLibraries\Screenshots"
    destination_directory = r"C:\ivcjenkins\workspace\REGRESSION_NIGHTLY_RUN_SINGLE\TestLibraries\Reports"
    extensions = ['.html', '.jpg', '.JPG', '.png']
    
    # Create the destination directory if it doesn't exist
    if not os.path.exists(destination_directory):
        os.makedirs(destination_directory)
    
    # Get a list of all files in the source directory
    file_list = os.listdir(source_directory)
    
    # Move files containing testcasename and with specified extensions
    for file in file_list:
        file_name, file_extension = os.path.splitext(file)
        if file_extension.lower() in [ext.lower() for ext in extensions] and testcasename.lower() in file_name.lower():
            source_path = os.path.join(source_directory, file)
            destination_path = os.path.join(destination_directory, file)
            try:
                shutil.move(source_path, destination_path)
                print(f"Moved {file} to {destination_directory}")
            except Exception as e:
                print(f"Error occurred while moving {file}: {e}")
   
def check_and_notify(test_case):
    if "RBT_VM" in test_case:
        return ("lakshmimadhuri.kota@keyloop.com", "aruna.theerthala@keyloop.com", "geethanjali.pasala@keyloop.com","chinna.kasireddy@keyloop.com")
    elif "RBT_ACC" in test_case:
        return ("pavan.nagireddy@keyloop.com", "geethanjali.pasala@keyloop.com", "chinna.kasireddy@keyloop.com")
    elif "RBT_AFT" in test_case:
        return ("lokesh.lakka@keyloop.com", "geethanjali.pasala@keyloop.com", "chinna.kasireddy@keyloop.com")
    elif "RBT_CM" in test_case:
        return ("aruna.vasam@keyloop.com", "geethanjali.pasala@keyloop.com", "chinna.kasireddy@keyloop.com")
    else:
        print("No matching case found for notification.")
        return None

def send_email(test_case, test_status,packname):
    # Run prerequisite tasks
    remove_files()
    move_files_with_extensions(test_case)
    # run_robot()

    # Email details
    IvcPack = packname
    "IVC Package"
    TestSuite = test_case
    SubModule = "Sub Module"
    status = test_status
    htmlBody = "<html><body><p>This is the email body.</p></body></html>"
    current_directory = os.getcwd()
    print("Current Directory:", current_directory)
    attachment_folder = r"C:\ivcjenkins\workspace\REGRESSION_NIGHTLY_RUN_SINGLE\TestLibraries\Reports"
    print("Attachment Directory:", attachment_folder)

    # Check recipient based on test case
    recipient_emails = check_and_notify(test_case)
    if not recipient_emails:
        print("No email sent as no matching recipient found.")
        return

    # Join recipient emails as a comma-separated string
    recipient_email_str = ", ".join(recipient_emails)

    # Create an email message instance
    mail = MIMEMultipart()
    mail['From'] = "ivcauto@keyloop.com"
    mail['To'] = recipient_email_str
    mail['Subject'] = f"IVC Robot Test Case | {IvcPack} | {TestSuite} | {SubModule} - {status}"

    # Attach the body
    mail.attach(MIMEText(htmlBody, "html"))

    # Attach files from the folder
    file_list = os.listdir(attachment_folder)
    for file_name in file_list:
        file_path = os.path.join(attachment_folder, file_name)
        if os.path.isfile(file_path):
            with open(file_path, 'rb') as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', f'attachment; filename={file_name}')
                mail.attach(part)

    # Configure the SMTP client
    try:
        client = smtplib.SMTP('172.22.250.248', 25)  # Replace with the appropriate SMTP server and port
        client.sendmail("ivcauto@keyloop.com", recipient_emails, mail.as_string())
        print(f"Email sent successfully to {recipient_email_str}")
    except Exception as e:
        print(f"Failed to send email: {e}")
    finally:
        client.quit()



def send_email1(testname,status):
    remove_files()
    move_files_with_extensions(testname)
   
    # run_robot()

    IvcPack = "IVC Package"
    TestSuite = testname
    SubModule = "Sub Module"
    status = status
    htmlBody = "<html><body><p>This is the email body.</p></body></html>"
    current_directory = os.getcwd()
    print("Current Directory:", current_directory)
    attachment_folder =r"C:\ivcjenkins\workspace\REGRESSION_NIGHTLY_RUN_SINGLE\TestLibraries\Reports"
    print("Current Directory:", attachment_folder)
    
    # Create an instance of the email message
    mail = MIMEMultipart()

    # Add email headers
    mail['From'] = "ivcauto@keyloop.com"
    mail['To'] = "Hyderabad.ARIRegression@keyloop.com"
    mail['Subject'] = f"IVC Robot Test Case | {IvcPack} | {TestSuite} | {SubModule} - {status}"
    file_list = os.listdir(attachment_folder)
   

    # Attach each file to the email
    for file_name in file_list:
        file_path = os.path.join(attachment_folder,file_name)
        attachment = open(file_path, 'rb')
        file_name = os.path.basename(file_path)
        part = MIMEBase('application','octet-stream')
        part.set_payload(attachment.read())
        part.add_header('Content-Disposition',
                        'attachment',
                        filename=file_name)
        encoders.encode_base64(part)
        mail.attach(part)
        # if os.path.isfile(file_path):
        #     attachment = mail.attach(file_path)
        #     attachment.PropertyAccessor.SetProperty("http://schemas.microsoft.com/mapi/proptag/0x3712001F", file_name)        

    # Configure the SMTP client
    client = smtplib.SMTP('172.22.250.248', 25)  # Replace with the appropriate SMTP server and port

    # Send the email
    client.sendmail("ivcauto@keyloop.com", "Hyderabad.ARIRegression@keyloop.com", mail.as_string())

    # Quit the SMTP client
    client.quit()

def kill_process_by_name():
    process_name='kclient.exe'
    for process in psutil.process_iter(['pid', 'name']):
        if process.info['name'] ==process_name :
            try:
                process.terminate()
                print(f"Process '{process_name}' (PID: {process.info['pid']}) terminated successfully.")
                break
            except psutil.NoSuchProcess:
                print(f"No such process with name '{process_name}'.")
            except psutil.AccessDenied:
                print(f"Access denied to terminate process '{process_name}' (PID: {process.info['pid']}).")
            except psutil.ProcessLookupError:
                print(f"Error occurred while terminating process '{process_name}' (PID: {process.info['pid']}).")
def update_profile(testname,status):
    config_path = r'C:\ivcjenkins\workspace\REGRESSION_NIGHTLY_RUN_SINGLE\TestLibraries\taf-ivc-desktop-automation\Drive.config'
    tree = ET.parse(config_path)
    root = tree.getroot()

    # Find the element with key 'dashxml'
    dashxml = None
    for add in root.findall(".//add"):
        if add.get('key') == 'dashxml':
            dashxml = add.get('value')
            packname = dashxml.split('_')[1].split('-')[0]
            if packname == "ivcprv":
               packname = "Live"
               print(packname)


    for add in root.findall(".//add"):      
            if add.get('key') == 'accelerator':
             accelerator=add.get('value')
             break
    arguments = {
        "product": "Drive",
        "version": packname,
        "filename": testname,
        "teststatus": "passed"
    }
    if accelerator == "true":
        print("profiler calling")
        server_base_url = "http://ari24-vm-09407.cust.itsystems.global:8080"
        job_name = "ARIIVC.EnhancedProfiler.Process.SingleRobot"

        # Build the parameter string
        params_input = "&".join(["{0}={1}".format(key, value) for key, value in arguments.items()])

        # URL for triggering the Jenkins job
        url1 = "{0}/job/{1}/buildWithParameters?delay=1sec&{2}".format(server_base_url, job_name, params_input)
        print("URL built is {0}".format(url1))

        # Perform the POST request with basic authentication
        auth_string = "ivc:11a5a900f24268eeb1ee58bb795530834e="
        headers = {
            # "Authorization": "Basic " + base64.b64encode(auth_string.encode()).decode()

            "Authorization": "Basic bmFnaXJlZHA6MTE0MmFhZjJhMDYzNTAxNWMzMTE0YjIzNjEwYTEzNzQzZQ=="
        }

        response = requests.post(url1, headers=headers)

        print("\n\n\n")
        print(response.status_code, response.reason)
        print(response.text)
    
    



def run_robot():
    # Replace the path with the actual path to the 'robot' executable
    robot_executable = 'robot'
    current_directory = os.getcwd()
    # Replace the path with the actual path to the test script
    test_script_path = attachment_folder = current_directory +'\\autoline_drive_main'

    # Replace the path with the actual path where you want the output reports to be generated
    output_directory = "Reports"

    # Create the command to run the 'robot' executable with the specified options
    command = f'{robot_executable} "--outputdir" "{output_directory}" {test_script_path}'

    try:
        # Execute the 'robot' command as a subprocess
        subprocess.run(command, shell=True, check=True)
        print("Robot test execution completed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred while running the Robot Framework command: {e}")
    except Exception as ex:
        print(f"An unexpected error occurred: {ex}")
# send_email("RBT_ACCAP114588002_D2","FAIL")
