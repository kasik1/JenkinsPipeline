import os
import win32com.client as win32

def read_cell_a1(cellvalue):
    excel = win32.GetActiveObject("Excel.Application")
    workbook = excel.ActiveWorkbook
    worksheet = workbook.ActiveSheet
    cell_value = worksheet.Range(cellvalue).Value
    return cell_value

def get_active_excel_row_count():
    excel = win32.GetActiveObject("Excel.Application")
    workbook = excel.ActiveWorkbook
    worksheet = workbook.ActiveSheet
    row_count = worksheet.UsedRange.Rows.Count
    return row_count

def get_active_excel_column_count():
    excel = win32.GetActiveObject("Excel.Application")
    workbook = excel.ActiveWorkbook
    worksheet = workbook.ActiveSheet
    column_count = worksheet.UsedRange.Columns.Count
    return column_count

def get_cell_value(row, column):
    excel = win32.GetActiveObject("Excel.Application")
    workbook = excel.ActiveWorkbook
    worksheet = workbook.ActiveSheet
    cell_value = worksheet.Cells(row, column).Value
    return cell_value

def read_excel_into_list():
    try:
        rows = get_active_excel_row_count()
        columns = get_active_excel_column_count()
        print(f"Number of rows: {rows}")
        print(f"Number of columns: {columns}")

        all_values = []
        for row in range(1, rows + 1):
            row_values = []
            for column in range(1, columns + 1):
                value = get_cell_value(row, column)
                row_values.append(value)
            all_values.append(row_values)

        return all_values
    finally:
        excel = win32.GetActiveObject("Excel.Application")
        print("Excel application found:", excel)

        # Disable alerts temporarily
        excel.DisplayAlerts = False

        # Quit Excel application
        excel.Quit()

        # Release the COM object
        excel = None
        
        # Ensure all Excel processes are killed
        os.system('taskkill /f /im EXCEL.EXE')
