from datetime import datetime, timedelta
 
def julian_to_date(julian_date_val, date_format=None):
 
    julian_date = float(julian_date_val)
   
    unix_time = (julian_date - 2440587.5) * 86400  
 
    dt_date_time = datetime(1970, 1, 1) + timedelta(seconds=unix_time)
   
    if date_format:
        formatted_date = dt_date_time.strftime(date_format)
    else:
        formatted_date = dt_date_time.strftime("%d/%m/%Y")
   
    return formatted_date