import os
import json
import sys
import pymongo
from json import load
import socket
from datetime import datetime
import sendemail
import xml.etree.ElementTree as ET
from pymongo import MongoClient

dbclient="mongodb://c05drddrv969.dslab.ad.adp.com:27017"
dbname="ivc"
collectionname= "releases"

def connect_to_mongo_db():
    # try:
        myclient = pymongo.MongoClient(dbclient)
        mydb = myclient[dbname]
        mycol = mydb[collectionname]
        return mycol

def get_testsetname(arg_value):
    # Connect to MongoDB
    collection  = connect_to_mongo_db()

    # Query the database
    result = collection.find_one({"packname": arg_value})
    if result:
        testsetname = result['testsetname']
        xml_files = ['Drive.config']
        if testsetname:
            for xmlfile in xml_files:
                update_config_file(xmlfile,testsetname)
                print(arg_value)
                print(f'Test set name for pack arg_value is "{testsetname}"')
                return testsetname
    else:
        return None
    
def update_config_file(xmlfile,testsetname):
    # Parse the XML file
    tree = ET.parse(xmlfile)
    root = tree.getroot()

    # Find the element with key="dashxml"
    for elem in root.findall(".//add[@key='dashxml']"):
        # Update the value attribute
        new_value = f"{testsetname}"
        elem.set('value', new_value)
        break

    # Write the changes back to the file
    tree.write(xmlfile)

# Example usage
# packname = 'ivcprv'
# testsetname = get_testsetname()

if len(sys.argv) > 1:
        arg_value = sys.argv[1]
        print(arg_value)
else:
    arg_value = None

get_testsetname(arg_value)

