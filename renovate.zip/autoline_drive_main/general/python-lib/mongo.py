import os
import json
import pymongo
from json import load
import socket
from datetime import datetime
import sendemail


dbclient="mongodb://c05drddrv969.dslab.ad.adp.com:27017"
dbname="ivc"
collectionname= "results"

# dbclient="mongodb://c05dciivc888.dslab.ad.adp.com:27017"
# dbname="drivemetrics"
# collectionname= "results"
def update_db_mongo_with_Result(testname,tstatus,testset,pack,author,starttime,endtime,duration,log):

    if tstatus == "PASS":
        status="Passed"
    elif tstatus == "FAIL":
        status="Failed"

    try:
        collection=connect_to_mongo_db()
        sysname=socket.gethostname()
        query = { 
            "testsetname": testset, 
            "packname": pack, 
            "name": testname 
        }

        count=get_counter(testname,testset,pack)
        print("count:" + count)
        print(query)
        putdata = { "$set": 
            { "status": status, 
            "duration": duration, 
            "logs": log, 
            "host": sysname,
            "counter": count,
            "author":author,
            "teststarttime": starttime,
            "testendtime": endtime,
            "runner": "Robot" 
            } 
        }
        collection.update_one(query, putdata)
    except Exception as e:
        print("MongoDB- Test status update failed:" + str(e))
   
def get_counter(testname,testset,pack):
    # try:
        collection=connect_to_mongo_db()
        query = { 
            "testsetname": testset, 
            "packname": pack, 
            "name": testname 
        }

        print(query)
        projection = {"status":1,"counter":1}
        data=collection.find_one(query, projection)
        if data:            
            rec_status = data.get("status")
            rec_counter = data.get("counter")            
            print("status:", rec_status)
            print("counter:", rec_counter)
        else:
            print("No matching document found.")

        if  rec_status=="No Run":
            finalcounter=0
        else:
            finalcounter= int(rec_counter)+1
        
        print(finalcounter)
        return f'{finalcounter}'

    # except Exception as e:
    #     print("MongoDB- Get counter value failed:" + str(e))
   

def connect_to_mongo_db():
    # try:
        myclient = pymongo.MongoClient(dbclient)
        mydb = myclient[dbname]
        mycol = mydb[collectionname]
        return mycol
    # except Exception as e:
    #     print("Mongo DB connection Error:"+ str(e))

def convert_date_timeformat(inputdata):    

    input_format = "%Y-%m-%d %H:%M:%S"
    output_format = "%d-%m-%Y_%H:%M:%S"

    # output_format = "%d-%m-%Y_%I:%M %p"
    
    input_datetime = datetime.strptime(inputdata, input_format)
    output_date_time_str = input_datetime.strftime(output_format)
    return output_date_time_str



     
     
