import pygetwindow as gw

# Iterate over all windows and minimize them
def closeAllApplications():
    for window in gw.getAllWindows():
        if window.isMinimized == False:  # Check if the window is not already minimized
            window.minimize()
