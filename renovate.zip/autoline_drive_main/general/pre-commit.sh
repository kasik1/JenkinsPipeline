#!/bin/sh
# This is a pre-commit hook

# Run Robot Framework tests in dry-run mode
echo "Running Robot Framework tests in dry-run mode..."
robot --dryrun autoline_drive_main/testcases

# Capture the exit status of the Robot Framework command
RF_EXIT_STATUS=$?

# If tests fail, exit with a non-zero status to prevent the commit
if [ $RF_EXIT_STATUS -ne 0 ]; then
    echo "Robot Framework tests failed in dry-run! Commit aborted."
    exit 1
fi

# Execute Python script
SCRIPT_FILE="autoline_drive_main/general/xpath_generator/xpath_code/duplicate_locators.py" 

LAST_LINE=$(python "$SCRIPT_FILE" | tail -n 1)
 
if [ "$LAST_LINE" != "True" ]; then
  echo "Last line is not True. Aborting commit."
  exit 1
fi 

exit 0
