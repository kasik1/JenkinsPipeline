import pymongo
import json
import os
from datetime import datetime, timedelta
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def getCurrentTestSet(pack, date, mycol):
    regex_pattern = f"{date}_{pack}"
    myquery = {
        "packname": pack,
        "testsetname": {'$regex': regex_pattern}
    }
   
    result_doc = mycol.find_one(myquery)
    return result_doc['testsetname'] if result_doc else None

def create_json_file(testset_name, results, output_path):
    if not os.path.exists(output_path):
        os.makedirs(output_path)
    
    for result in results:
        result["_id"] = str(result["_id"])
 
    data = {
        "testset_name": testset_name,
        "testCases": results
    }
 
    with open(os.path.join(output_path, f'{testset_name}.json'), "w") as json_file:
        json.dump(data, json_file, indent=4)

def get_results_for_testset(testset_name, mycol):
    results_cursor = mycol.find(
        {"testsetname": testset_name},
        {
            "_id": 1,
            "description": 1,
            "status": 1,
            "duration": 1,
            "author": 1,
            "teststarttime": 1,
            "testendtime": 1,
            "module": 1,
            "submodule": 1,
            "suitename": 1,
            "name": 1,
            "createdAt": 1
        }
    )

    results = []
    for result in results_cursor:
        status = result.get("status", "").upper()
        if not status.startswith("TEST_"):
            status = f"TEST_{status}"

        formatted_result = {
            "_id": str(result["_id"]),
            "description": result.get("description", ""),
            "status": status,
            "duration": result.get("duration", 0),
            "author": result.get("author", ""),
            "testendtime": result.get("testendtime", ""),
            "testPath": f"module={result.get('module', '')}#submodule={result.get('submodule', '')}#suitename={result.get('suitename', '')}#name={result.get('name', '')}",
            "createdAt": result.get("teststarttime", "")
        }
        results.append(formatted_result)

    return results

def update_results_json(pack, from_date_str, to_date_str, mongo_uri, db_name, collection_name, output_path):
    try:
        myclient = pymongo.MongoClient(mongo_uri)
        mydb = myclient[db_name]
        mycol = mydb[collection_name]
    except Exception as e:
        logging.error(f"Error connecting to MongoDB: {e}")
        return

    from_date_obj = datetime.strptime(from_date_str, "%Y-%m-%d")
    to_date_obj = datetime.strptime(to_date_str, "%Y-%m-%d")
    current_date = from_date_obj
   
    while current_date <= to_date_obj:
        date_for_test_set = current_date.strftime("%d-%m-%Y")
        test_set = getCurrentTestSet(pack, date_for_test_set, mycol)
       
        if test_set is not None:
            logging.info(f"Test set for pack '{pack}' on date '{date_for_test_set}': {test_set}")
            results = get_results_for_testset(test_set, mycol)
            create_json_file(test_set, results, output_path)
        else:
            logging.warning(f"Test set not found for pack '{pack}' on date '{date_for_test_set}'")
       
        current_date += timedelta(days=1)

if __name__ == "__main__":
    from_date_str = "2024-01-01"
    to_date_str = "2024-01-31"
    pack = "MT"
    mongo_uri = "mongodb://c05drddrv969.dslab.ad.adp.com:27017/"
    db_name = "ivc"
    collection_name = "results"
    output_path = r'C:\ivc_latest_wrapper\ivc_new\taf-ivc-desktop-automation\autoline_drive_main\general'
   
    update_results_json(pack, from_date_str, to_date_str, mongo_uri, db_name, collection_name, output_path)
