#Window - Operator Login
wndOperatorLogin = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Operator Login']"
txtaccessmode = "/Window/Window/Pane/Edit[@Name='Access mode']"
txtdepartment = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Operator Login']/Pane[@Name='Operator Login']/Edit[@Name='Department']"
txtoperator = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Operator Login']/Pane[@Name='Operator Login']/Edit[@Name='Operator']"
btnOperatorLoginOK = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Operator Login']/Pane[@Name='Operator Login']/Button[@Name='OK']"
btnCancelInOperatorLogin = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Operator Login']/Pane[@Name='Operator Login']/Button[@Name='Cancel']"
wndOperatorLogin = "Operator Login"
txtAccessmodewrapper = "Access mode"
txtDepartmentwrapper = "Department"
txtOperatorwrapper = "Operator"

#Window - Point of Sale
txtboxProduct = "product"
tblGrid= "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@ClassName='KTab']/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@Name='dgo_ObjectID=BodyGrid;']/Table[@ClassName='KCMLGridPad_32']"
btnAction = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@Name='dgo_ObjectID=Main.toolbar;']/Button[@Name='dgo_ObjectID=Main.toolbar.WORKPLACE.Action_;']"
btnLastWIP = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@Name='dgo_ObjectID=Main.toolbar;']/Button[@Name='dgo_ObjectID=Main.toolbar.WORKPLACE.Last_WIP;']"
dlgPressReturntoResume = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Press RETURN to Resume']"
btnOKInDialog= "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Press RETURN to Resume']/Button[@Name='OK']"
txtWIPNumber = "WIP number"
toolbar_Customer = "Main.toolbar.WORKPLACE.Customer;"
toolbar_Casefile = "Main.toolbar.WORKPLACE.Case_file;"
btnOpen = "Pane/Pane/Pane/Pane/Button[@Name='Open']"
btnActionname = "Action_"
txtLabour = "#LAB"
dataitemEstimate = "Estimate"
dataitemInvoicewizard = "Invoice wizard"
wndConfirm = "Confirm"
wndOtherJobsExist = "Other Jobs Exist"
wndSelectItemFromList = "Select Item From List"
wndMileageValidation = "Mileage Validation"
dgoBodyGrid = "BodyGrid"
btnNO = "No"
menuitemLinksVehiclepreparation = "Links|Vehicle preparation"
lineitemsource = "/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[@Name='VHC_TYRE_OSR']"
lineitemsource1 = "/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[@Name='VHC_TYRE_OSF']"
lineitemdes = "/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[@Name= 'Group2']"
dgogridTargets = "gridTargets"
txtnewproduct = "product"
dropdowngroute= "G	Group Route"
tabitemcodes = "Codes"  
drpdwnCarriage = "Carriage"
drpdwnRoute= "Route"
dropdownNameGcdhomeloan ="G	C/D - Home & Loan"
dataitemCheckinout = "Check in/out"
windowCheckInOut = "Check In/Out"
txtMileagein = "Mileage in"
txtMileageout = "Mileage out"
txtLabourstatus = "SO_HD_BOOKSTAT"
tabitemVehicle = "Vehicle"
txtprevious = "MK_VE_LASTMLG"
dgogridTable = "gridTable"
dataWIPNO = "WIPNO"
headerVALUE = "VALUE"
tableSO_cashp = "SO_11_cashp_0011 - Cash payment records"
tabledescCashp = "Cashp"
modulecodeSO = "SO"
typeM = "M"
menuitemViewInvoiceLayoutGrid = "View|Invoice Layout Grid"

#Window - Invoice Wizard
wndInvoiceWizard = "Invoice Wizard"
radiobtnSendasanemail = "Send as an e-mail"
btnRecipientemailaddress  = "Recipient email address"
wndEmailAddresses = "Email Addresses"
txtServicecode1 = "Service code 1"
descmileage = "InvoiceDetails-1.SO_clsR8InvServiceCode-1.vm_ve_mileage"
txtCurrentMileage = "Current Mileage"
descInvchoose = "InvoiceChoose-1.SO_clsR8InvoiceChoose-1.SO_clsR8InvoiceChoose_pInvLayoutGrid"
dataitemAction = "Action"
txtLineSelection = "Lines originally selected have changed, please use the selection screen to re-select lines."
dataitemLayout = "Layout"
dgoGroupdesc = "INVOICEWIZARD-1.SO_clsR8InvoiceWizardPlugin-1.kcmlgrid-1"

#Window - Options
wndOptions = "Options"
dataitemOptions = "Options"

#Window - Line Selection
wndLineSelection = "Line Selection"

#Window - Labour Details
wndLabourDetails = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Labour Details']"
txtStatus = "SO_la_LOADSTAT"
txttechnician = "so_la_wlclockr"
txttimetaken = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Labour Details']/Pane[@Name='Labour Details']/Edit[@Name='Time taken']"
btnOKLabourDetails = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Labour Details']/Pane[@Name='Labour Details']/Button[@Name='OK']"
wndLabourDetailswrapper = "Labour Details"
dataworkstatus = "C" 
datatechician = "Tech1"   
txtTimetakenwrapper = "Time taken"


#Window - Action For
wndActionFor = "/Window[@ClassName='KCMLMasterForm_32']/Window[@ClassName='KCMLMasterForm_32']"
btnPrint = "/Window[@ClassName='KCMLMasterForm_32']/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Print']"
btnPrintacountinvoice = "Print"
btnFull = "/Window/Window/Pane/Button[@Name='Full...']"
btnPrintcredit = "/Window/Window/Pane/Button[@Name='Print credit note']"
wndAction = "Action For"
dataitemType = "//DataItem[@Name='Type']"
btnType = "//SplitButton[@Name='Type']"
tblType = "#Ctrl1"
listitemCashOnDelivery = "//ListItem[contains(@Name,'Cash on delivery (GBP)')]"
btnPartial = "Partial..."
legacydescGross = "Gross"

#Window - Report Generator
tblgridPromts = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@Name='dgo_ObjectID=gridPrompts;']"
chkTotalsOnly = "gridPrompts.Pad.Row11.Cell2.dbedit"
btnDisplay = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@Name='dgo_ObjectID=mnuMain.toolbar;']/Button[@Name='dgo_ObjectID=mnuMain.toolbar.FileDisplay;']"
tblReport = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@ClassName='KTab']/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@Name='dgo_ObjectID=grdOutput;']/Table[@ClassName='KCMLGridPad_32']/Custom[@Name='dgo_ObjectID=grdOutput.Pad.Row12;']/DataItem[@Name='156.66']"
btnExit = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@Name='dgo_ObjectID=mnuMain.toolbar;']/Button[@Name='dgo_ObjectID=mnuMain.toolbar.FileExit;']"

#Window - Service Operator View
mnuPointOfSale = "Point of Sale|Point-of-sale"
wndSPOS = "Service Point Of Sale"
treeVehicleStockManagement = "Vehicle Management|Vehicle Stock Management"
wndServiceOperatorView = "Service Operator View"
wndPPOS = "Parts Point Of Sale"
tabVehicle = "Vehicle"
btnMore = "More..."
wndpointofsale = "Point-of-sale"
btnCreateVehOK = "/Window[@Name='Create Vehicle']/Pane/Button[@Name='OK']"

#Window - Overwrite Customer Details?
wndOverwriteCustomerDetails = "Overwrite Customer Details?"

#Window - Part Details
wndPartDetails = "Part Details"
dropdownGroup = "Group"

#window - press Return to resume
txtwipno = "//Text[@AutomationId='65535']"
wndPressRETURNtoResume = "Press RETURN to Resume"

#Window - Credit Reasons
wndCreditReasons = "Credit Reasons"
dataitemWarranty = "//DataItem[@Name='Warranty']"
dataitemNocreditreasonselected = "No credit reason selected"



#Window - Service Retail Cask Sales
wndServiceRetailCash = "Action For Service Retail Cash Sales"
btnPayment = "Payment"
wndPaymentDetail = "Payment Detail"
txtAmountPayment = "Amount"
txtReference1Payment = "Reference 1"
txtReference2Payment = "Reference 2"
txtPaymentCode = "//Edit[@Name='Payment code']/SplitButton"
btnNotification = "Notification"
btnPrintCashSaleInvoice = "Print"
btnPrintCreditNote = "Print credit note"
btnCreditNoteMode = "Full..."
tabCreditReason = "Incorrect"

#Window - Refund reasons
wndRefundReasons = "Refund reasons"

#window - complete service code/mileage
txtServicecs = "SO_HD_SERVCODE"
dropdownServices = "SO_HD_SERVCODE.button"
txtMileage = "//Edit[@AutomationId='26738']"
wndCompleteServiceCodeMileage = "Complete Service Code/Mileage"
dataservicecode = "MEC"   
datamileage = "12"
descCurrentMileage = "SO_HD_MILEAGE"
descPreviousMileage = "MK_VE_LASTMLG"


#window - Customer Search
dataitemcust = "//DataItem[contains(@Name,'{}')]"

#window - Casefile for
wndCasefilewrapper = "Casefile for"

#Window - Select POS Parameters
wndSelectPOSParam = "Select POS Parameters"
rbnFlagPriorities = "/Window/Pane/RadioButton[@Name='Flags-Priorities']"

#Window - POS Parameters
wndPOSParam = "POS Parameters"
tabMiscellaneous = "Miscellaneous"
chckboxEnableAdminOperator = "/Window/Pane/Pane/Pane/CheckBox[@Name='Enable Admin operator']"
txtboxAdminOperatorPriority = "/Window/Pane/Pane/Pane/Edit[@Name='Admin operator priority']"
dropdwnAdminOperatorPriority = "Admin operator priority"
toolbarConfirm = "ActionConfirm"
toolbarActionAmend = "ActionAmend"
toolbarActionCancel = "ActionCancel"
treePOSParameters = "Point of Sale|System Maintenance|POS Parameters"
treePOSOperator = "Point of Sale|Miscellaneous Options|POS Operators"
radiobtnMainTablesFastrack = "Main-Tables-Fastrack"
tabTables = "Tables"
editRetention = "Retention"

# Window Operator File
wndOpFile = "Operator File"
txtOperatorNum = "/Window/Pane/Edit[@ClassName='KCMLDBEdit_32']"
wndOperators = "Operators"
txtAdminOp = "editOPADMIN"
drpdwnOpen = "/Window/Pane/Pane/Pane/Pane/Pane/Edit/SplitButton[@Name='Open']"

# Window - VHC Today
wndVHCToday = "VHC Today"
dgoOnsite = "VHCStatistics1-1.GB_clsReport-4.kcmlgrid-1"
headerOnsiteDateTime = "Onsite Date Time"
headerDueOutDateTime = "Due Out Date Time"
dgoVHCOnsitePanel = "VHCStatistics1-1.GB_clsReport-1.kcmlgrid-1"
dataitemTotalOnsite = "Total Onsite"
dataitemTotal = "Total"
btnMaximizeVHC = "Maximize"

#window Extended vehicle details
wndExtendedVehicleDetails = "Extended Vehicle Details"
txtChassis = "Chassis number"
txtFranchiseCode = "Franchise code"
wndConfirmInput = "Confirm input"

#window - WL System Parameters
treeitemWLSystemParameters = "Workshop Loading|System Maintenance|System Parameters"
wndWLSystemParameters = "System Parameters"
tabitemOptionalFunctionality = "Optional Functionality"
checkboxNewappointments = "New appointments"
toolbarActionConfirm = "ActionConfirm"

#window - Workshop Load
dgoWLLOADAppointGrid = "WLLOAD.AppointGrid"
wndConfirmBooking = "Confirm Booking"
texteditTimeIn = "editTimeIn"
txtworkshopday = "Time entered is before start of workshop's day."
btnConfirm = "Confirm"
dataitemLoad = "Load"
wndWorkshopLoad = "Workshop Load"

#window - Vehicles Awaiting Preparation
wndVehiclesAwaitingPreparation = "Vehicles Awaiting Preparation"
dataitemdesc = "1.4 VTi 16V VT 5dr"
btnTransfer = "Transfer..."

#window - Transfer Pushed Lines To ...
wndTransferPushedLinesTo = "Transfer Pushed Lines To ..."
txtcombo1 = "combo1"
txtcombo2 = "combo2"
btnTransfer1 = "Transfer"
btnCreateWIP = "Create WIP"

#window - Print Batch of Invoices/Credits
menuitemBatchInvoicesCredits = "Point of Sale|Batch Invoices/Credits"
wndInvoiceGroups = "Invoice Groups"
dataitemInvoiced = "Invoiced"
wndChangingStatus = "Changing Status"
txtChangingstatusisnotallowed = "Changing status is not allowed:"
menuitemFileHistory = "File|History"
wndHistoryof = "History of"
tabPayments= "Payments"
dgogridPayment = "gridPayment"
headerPaymentValue = "Payment Value"
wndInvoiceLayoutGrid = "Invoice Layout Grid."
txtcheck = "The invoice layout can not be switched on when lines are already in a credit status."
wndPrintBatchofInvoicesCredits = "Print Batch of Invoices/Credits"
radiobtnCreditnotes = "Credit notes"
toolbarScanWIPs = "ScanWIPs"
toolbarReview = "Review"
wndReviewWIPs = "Review WIPs"
dgoGrid = "Grid"

#window - Edit Layout Group
wndEditLayoutGroup = "Edit Layout Group"
txtDescription = "Description"
txtAccountCodedesc = "edtAcc"
btnCreateGroup = "Create Group"
btnNewGroup = "New Group"
dataitemEditInvoiceGroup = "&Edit Invoice Group"

checkboxHidepartlines = "Hide  part  lines"
checkboxHidelabourlines = "Hide labour lines "
groupOption = "Options"
wndFilterOption = "Filter Options"
btnFilterInvoiceGrid = "Filter"
wndOptions = "Options"
btnClose = "Close"