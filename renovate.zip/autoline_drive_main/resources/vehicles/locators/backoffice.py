#Vehicle Rental objects
#window names
wndReservationAvailability = "Reservations And Availability"
window_createbooking = "/Window/Window[@Name='Create Booking']"
window_insuranceoption = "Select Item From Menu"
window_confirmmileage = "Confirm Mileage Rates"
window_allocatevehicle = "/Window/Window/Window[@Name='Allocate Vehicle/Supplier']"
window_printinvoice = "//Window[@Name='Print Invoice']"
window_printcredit = "Print Credit"
window_creditreason = "Credit reason"
window_startrental = "//Window[@Name='Start Rental']"
window_rentalagree = "//Window[contains(@Name,'Rental Agreement')]" 
window_booking="/Window/Window[contains(@Name,'Booking')]"
window_operatorquestions = "//Window[contains(@Name,'Operator Questions')]"
window_pricedetails = "//Window[contains(@Name,'Enter Price Details')]"
window_VehiclesAwaitingPreparation = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Vehicles Awaiting Preparation']"
#textboxes
txt_account= "//Edit[@Name='SL account']"
txt_duration = "//Edit[@AutomationId='26747']"
txt_days = "//Edit[@AutomationId='dgo_ObjectID=DR_AG_DURATION']"
txt_vehiclegroup = "//Edit[@Name='Vehicle group']"
txt_tarifftype = "//Edit[@Name='Tariff type']"
txt_outlocation = "//Edit[@Name='Out location']"
txt_returnlocation = "//Edit[@Name='Return location']"
txt_registrationnum = "DR_AG_REGN"
txt_insurancedate = "DR_AG_INSEXPIR"
txt_odometer = "Odometer"
txt_fuel = "Fuel level out"
txt_pricecode = "/Window[@ClassName='KCMLMasterForm_32']/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Enter Price Details']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@ClassName='KCMLDBEdit_32']/Edit[@ClassName='KCMLChildEdit32']"
txt_price = "//Edit[@AutomationId='dgo_ObjectID=price.dbedit;']"
txt_quantity = "//Edit[@AutomationId='dgo_ObjectID=quantity.dbedit;']"
txt_searchagreement = "//Window[@Name='Agreement Search']/Pane/Edit[@AutomationId='editAgreement']"
txt_agreenum = "//Window[@Name='Miscellaneous Invoicing']/Pane/Edit[@Name='Agreement Number']"
txt_creditreason = "//Edit[@AutomationId='dgo_ObjectID=DR_CN_CODE;']"
txt_MIcreditreason = "//Pane/Edit[@Name='Credit reason code']"
txt_charge = "/Window[@ClassName='KCMLMasterForm_32']/Window[@Name='Amend Invoice Line']/Pane/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@ClassName='KCMLDBEdit_32']/Edit[@ClassName='KCMLChildEdit32']"
txt_compsearch = "Search"

#buttons
button_newbooking = "menuMain.toolbar.FileNew;"
button_openbooking = "menuMain.toolbar.FileOpen;"
button_invoice = "/Window/Window/Window[@Name='Print Invoice']/Pane/Button[@Name='Invoice']"
button_continue = "/Window/Window/Window[@Name='Print Invoice']/Pane/Button[@Name='Continue']"
button_credit="/Window/Window/Window[contains(@Name,'Print Credit')]/Pane/Button[@Name='Credit']"
button_creditcontinue="/Window/Window/Window[contains(@Name,'Print Credit')]/Pane/Button[@Name='Continue']"
button_CreateBookingOK = "//Pane[@Name='Create Booking']/Button[@Name='OK']"
button_AllocateVehOK = "//Pane[@Name='Allocate Vehicle/Supplier']/Button[@Name='OK']"
button_newcharge = "//Button[@Name='New charge']"
button_newline = "//Button[@Name='New Line']"
button_newpayment = "//Button[@Name='New Payment']"
button_priceok = "//Window[@Name='Enter Price Details']/Pane/Button[@Name='OK']"
button_amendinvoiceok = "//Window[@Name='Amend Invoice Line']/Pane/Button[@Name='OK']"
button_amendcreditnoteok = "//Window[@Name='Amend Credit Note Line']/Pane/Button[@Name='OK']"
button_misccreateok = "//Window[@Name='Create']/Pane/Button[@Name='OK']"
button_printok = "//Window[@Name='Print']/Pane/Button[@Name='OK']"
button_creditreasonok = "//Window[@Name='Credit reason']/"
button_LTIOk = "/Window[contains(@Name,'Long Term Invoicing')]/Pane/Button[@Name='OK']"
button_CRMOK = "//Window[@Name='CRM Search']/Pane/Button[@Name='OK']"
button_rentaldetailsok = "//Window[@Name='Rental details']/Pane/Button[@Name='OK']"
button_newpaymentok = "//Window[@Name='Process Payment']/Pane/Button[@Name='OK']"
button_paymentdetailsok = "//Window[@Name='Cash Entry']/Pane/Button[@Name='OK']"

#dialogs
dlg_servicedates = "Service Dates"
tab_drivers = "Drivers"
tab_prices = "Prices"
tab_payments = "Payments"
dlg_information = "For information only"
dlg_StartRentalTiming = "Start rental in advance?"

#radiobuttons
rbmiscinvoice = "//Window[@Name='Create']/Pane/RadioButton[@Name='Invoice']"
rbmisccredit = "//Window[@Name='Create']/Pane/RadioButton[@Name='Credit']"
rbLTItypemonthly = "/Window[contains(@Name,'Long Term Invoicing')]/Pane/RadioButton[@Name='Monthly']"
rbLTIsummary = "/Window[contains(@Name,'Long Term Invoicing')]/Pane/RadioButton[@Name='Summary']"
rbLTInonsummary = "/Window[contains(@Name,'Long Term Invoicing')]/Pane/RadioButton[@Name='Non-summary']"
rbLTIpostinvoice = "/Window[contains(@Name,'Long Term Invoicing')]/Pane/RadioButton[@Name='Post Invoices']"
rbraisepayment = "//Window[@Name='Process Payment']/Pane/RadioButton[@Name='Raise a payment']"
#window process payment
wndProcessPayment = "Process Payment"
wndCashEntry = "Cash Entry"
#tree
treeitem_rentalreservations="//*[@Name='Reservations']"
treerentalCompany = "//TreeItem/TreeItem[contains(@Name,'{}')]"
#check box
chk_producesummaryinvoice = "//*[@Name='Produce summary invoice']"
chkCanOverrideCreditlimit = "//*[@Name='Can override credit limit check progress code']"
#toolbarmenu
menu_print = "//Window[contains(@Name,'Rental Agreement')]/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@ClassName='BarBase']/Button[@Name='Print']"
menu_exit = "/Window/Window[contains(@Name,'Rental Agreement')]/Pane[@ClassName='KCMLMenuTool_32']/ToolBar[@ClassName='BarBase']/Button[@Name='Exit']"
chkpaymentscheduleview="//*[@Name='Allow view of payment schedule']"
chkProportionallysplitcharges = "Proportionally split charges"
chkInterestChargeInclVAT = "Interest charge includes VAT"

#Window Sales executive
window_salesexecutive = "/Window[contains(@Name,'Sales Executive')]"
wndNoEnquiryLoaded = "No Enquiry Loaded"
button_otheroptions = "//*[@Name='Other options']"
btn_createsalesenquiry="//*[@Name='Create a Sales Enquiry']"
window_advancedoptions = "/Window[contains(@Name,'Advanced Options')]"
tree_enquirytypeuseraccess = "Enquiry Type User Access"
window_vmuserdetails="/Window[contains(@Name,'Vehicle user details')]"
btnCreateNewwrapper = "Create New"

#window VM user details
txtUserType = "User Type"
lst_user = "/List/ListItem[@Name='User']"
tab_enqtypeaccess = "Enquiry Type Access"
table_enqtypeaccess = "ENQUIRYTYPEACCESS_gridEnquiryTypes"

#window vehicle document entry
tbl_vehiclespecification = "VehSpecJournal-1.VM_SK_clsSpecJournal-1.kcmlgrid-1"
btn_VehSpecOK = "//Window[@Name='Vehicle Specification']/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='OK']"
vehdocentry_post = "GL_DocEntry.MenuMain.toolbar.GL_DocEntry.MenuMain.Tools.TOOLS_Post;"
tbrToolsPost = "TOOLS_Post"
txtFundingCompany = "Funding company"
btnAdd = "Add"

#window Cost Posting Adjustments
tblCostPosting = "WORKPLACE.VM_SK_clsSpecJournal-1.kcmlgrid-1"


#window Payment schedule
lableinsurancevalue = "//Window[@Name='Payment schedule']//Pane//Edit[@Name='Insurance charge']"  
lablemaintenancecharge = "//Window[@Name='Payment schedule']//Pane//Edit[@Name='Maintenance charge']"

#window Screen Resolution Warning
wndScreenResolutionWarning =  "//Window[@Name='Screen Resolution Warning']"

#window Payment schedule
tblPaymentScheduleGrid= "WORKPLACE.VM_FI_clsPaymentScheduleGrid-1.kcmlgrid-1"

#window vehicle stock management
wndVehicleStockManagement = "Vehicle Stock Management"
wndVSMpath =  "//Window[@Name='Vehicle Stock Management']"
tblDescription = "/Window/Pane/Pane/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@ClassName='KClientGrid_32']/Table[@ClassName='KCMLGridPad_32']/Custom[@Name='dgo_ObjectID=VM_SK_SpecSummary-1.VM_SK_clsSpecification-1.kcmlgrid-1.Pad.Row5;']/DataItem[@Name='Description']"
tbl_vsmvehiclesearch = "StockAdminVehicles-1.VM_SR_clsAdminSrch_Criteria-1.kcmlgrid-1"
tbl_postinglog = "VM_SK_PostingLog-1.VM_SK_clsPostingLines-1.kcmlgrid-1"
btn_postinglogclose = "//Window[@Name='Posting log']/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Close']"
tblKeywordSearch = "StockAdminVehicles-1.VM_SR_clsAdminSrch_Criteria-1"
dataitemManufacturerOrderDetails = "Manufacturer order details"
txtSupplierName="Name"
txtSupplierPostcode="Postcode"
txtSupplierAddress="Address"
dataitemSupplierDetails = "Supplier details"
txtLastOwner="VM_PO_InvoiceDetails-1.VM_SK_clsLastOwner-1.vm_sk_lastname"
txtPOName="VM_PO_InvoiceDetails-1.VM_clsMultiVed-1.vm_po_name"
#txt_KeywordSearch= "/Window/Pane[1]/Pane/Pane/Table[2]/Table/Pane[@AutomationId='103']/Edit"
txt_KeywordSearch = "//Dataitem[@LegacyIAccessiblePattern.Value='Keyword Search']"
tbl_VehicleSearch = "StockAdminVehicles-1.VM_SR_clsVehicleSrch_Results-1.kcmlgrid-2"
tbl_vdvehiclesearch = "WORKPLACE.TabObject.#Ctrl28;"
tbl_VMShortcut= "WORKPLACE.VM_SK_clsShortcut-1.kcmlgrid-1"
tblTopPane = "WORKPLACE.VM_SK_clsTopPanel-1.kcmlgrid-1" 
wndDocumentLine = "Document Line"
txt_documentnumber = "//Window[@Name='Document Line']/Pane/Pane/Pane/Edit[@Name='Document number']"
txt_AvailableOptions="Window/Pane/Pane/Pane/Edit/SplitButton"
#txt_AvailableOptions = "Window/Pane/Pane/Pane/Edit[@ClassName='KCMLDBEdit_32']"
#window Change Accounts Status
# window_ChangeAccountsStatus = "/Window/Window[contains(@Name,'Change Accounts Status')]"
window_ChangeAccountsStatus = "Change Accounts Status"
txtRegdatexpath = "//Edit[@Name='Registration date']"
tbl_gridStatus= "gridStatus"
btn_CASOK="Window/Window/Pane/Button[@Name='OK']"
tbl_AvailOptions = "VM_SK_SpecSummary-1.VM_SK_clsAvailOptions-1.kcmlgrid-1"
tblSpecificationLine = "VM_SK_SpecSummary-1.VM_SK_clsSpecification-1.kcmlgrid-1"
txt_AttachPurchaseOrder = "/Menu/MenuItem[@Name='Attach to purchase order...']"
txtSetCostingStatusReceived = "/Menu/MenuItem[@Name='Set costing status to received']"
txt_PushToVehiclePreparation = "/Menu/MenuItem[@Name='Push to vehicle preparation...']"
txt_PullFromVehiclePreparation = "/Menu/MenuItem[@Name='Pull from vehicle preparation...']"
txt_DeleteOption = "/Menu/MenuItem[@Name='Delete']"
txt_BranchDropdown = "/Window/Window/Pane/Edit/SplitButton[@Name='Branch']"
txt_DepartmentDropdown = "/Window/Window/Pane/Edit/SplitButton[@Name='Department']"
tbl_VehicleAwaitingList = "gridHeaders"
tblCalcSummary="VM_SO_SalesOrderSummary-1.VM_SO_clsCalcSummary-1.kcmlgrid-1"
tblDepositDetails = "VM_SO_SalesOrderSummary-1.VM_clsVehicleDetails-1.kcmlgrid-1"
tblSpecificationLineOption = "/Window/Pane/Pane/Pane/Table/Table/Custom[@Name='dgo_ObjectID=VM_SK_SpecSummary-1.VM_SK_clsSpecification-1.kcmlgrid-1.Pad.Row{};']/DataItem[@Name='Description']"
optionOpenSpecificationLine = "/Menu/MenuItem[@Name='Open...']"
tableVATAmount = "/Window/Pane/Pane/Pane/Table/Table/Custom[@Name='dgo_ObjectID=VM_SK_SpecSummary-1.VM_SK_clsSpecification-1.kcmlgrid-1.Pad.Row{};']/DataItem[@Name='VAT Amount']"
txtColor = "/Window//Pane/Edit[@Name='Colour']"
txtColourDesc = "VM_SK_Definition-1.VM_SK_clsDefinition-1.vm_ve_colourdesc"
txtPurchasePrice = "//Edit[@Name='Total purchase price']"
txtVatableAmount = "//Edit[@Name='VATable amount']"
tblPurchaseVehicle = "Purchase vehicle"
txtSupplierName="Name"

# window Outside Purchase 
wndOutsidePurchase = "Outside Purchase"
btnPlus = "VM_SK_OutsidePurchaseDetail-1.VM_PC_clsOutsidePurchaseDetail-1.picbutton-1"
txtAccountNumber = "Account no"
txtAccountNumbervalue = "V0001"


# window Additional vehicle details
dataitemAdditionalvehicledetails = "Additional vehicle details"
txtTankCapacity="VM_SK_Summary-1.VM_SK_clsTechnical-1.vm_ve_tankcap"
txtEngineCapacity="VM_SK_Summary-1.VM_SK_clsTechnical-1.vm_ve_cc"
dropDownFueltype="VM_SK_Summary-1.VM_SK_clsTechnical-1.vm_ve_fuel"
dropDownTransmission="VM_SK_Summary-1.VM_SK_clsTechnical-1.vm_ve_transtype"
dropDownBodystyle="VM_SK_Summary-1.VM_SK_clsTechnical-1.vm_ve_body"

# window Stock Funding
dataitemStockfunding = "Stock funding"
wndStockFundingDetails = "Stock funding details"
txtStartDate = "Start date"
txtMaturityDate = "Maturity date"
tblFundingStatus = "Funding confirmed"
tblFundingSettled = "Funding settled"



#window Progress Transition Wizard
# window_ProgressTransitionWizard = "/Window/Window[contains(@Name,'Progress Transition Wizard')]"
window_ProgressTransitionWizard = "Progress Transition Wizard"
# txt_consigmentdate= "//Edit[@Name='Consignment date']"
txt_consigmentdate= "Consignment date"
txt_consigmentnote= "Consignment note"
# txt_consigmentnote= "//Edit[@Name='Consignment note']"
# txt_adoptiondate= "//Edit[@Name='Adoption date']"
txt_adoptiondate= "Adoption date"
txt_actualdatereceived= "Actual date received"
# txt_actualdatereceived= "//Edit[@Name='Actual date received']"
tblManagetheSalesEnquiry = "Manage the sales enquiry"


#window direct vehicles sale
window_directvehiclesales = "/Window/Window[@Name='Direct vehicle sales']/Pane[@ClassName='KCMLDlgWndClass_32']"
txt_enquirytype = "Pane[@ClassName='KCMLDlgWndClass_32']/Edit[@Name='Enquiry type']"
txt_manufaturersaletype = "Pane[@ClassName='KCMLDlgWndClass_32']/Edit[@Name='Manufacturer sale type']"
txt_sourceofbusiness = "Source of business"
txt_reference="Pane[@ClassName='KCMLDlgWndClass_32']/Edit[@Name='Referencce text']"
txt_invoicedate="Edit[@Name='Invoice date']"
txt_invoiceaccount="Invoice account"
tblstockspec="VM_Enquiry_DirectSaleVehicle-1.VM_SK_clsSpecification-1.kcmlgrid-1"

#window customer search
btn_custsearchok = "/Window/Window/Window[@Name='Customer Search']/Pane[@Name='Customer Search']/Button[@Name='OK']"
btnSelectwrapper = "Select"

#window print invoice
window_print = "//Window[contains(@Name,'Print')]/Pane[@ClassName='KCMLDlgWndClass_32']"

#window print credit order
tbl_creditreason="Credit reasons-1.VM_SO_clsCreditReasons-1.kcmlgrid-1"

#window point of sale
button_Action = "/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Action']"
button_CreateWIP = "/Window/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Create WIP']"

# Top Menu Items
mnuPostingLog = "History|Posting log"
mnuApplyCosts = "Keyloop|Apply Costs..."

mnuSalesInvoiceHistory = "History|Sales invoice history"

# Window Posting Log
wndPostingLog = "Posting log"

# Window Apply Costs
wndCostPostingAdjustments = "Cost Posting Adjustments" 
txtControl = "Control" 


# Window VM User Details
wndVehicleUserDetails = "Visual Editor - Vehicle user details"

# Window Search Filter
wndSrhFilter = "Search Filter"

# Window Create Booking
wndCreateBooking = "Create Booking"
txtVehicleGroup = "Vehicle group"

# Window Operator Questions
wndOperatorQuestions = "Operator Questions"

# Window Booking
wndBooking = "Booking"

# Window Allocate Vehicle Supplier 
wndAllocateVehicleSupplier = "Allocate Vehicle/Supplier"

# Window Start Rental
wndStartRental = "Start Rental"

# Window Print Selection
wndPrintSelection = "Print Selection"

# Window Advanced Selection
btnAdvancedSelection = "Advanced Selection"

# Window Advanced Search Criteria
wndAdvancedSearchCriteria = "Advanced Search Criteria"
tblShowClosedVehicle = "Showroom Vehicle Search Criteria-1.VM_SR_clsVehicleSrch_Criteria-1.kcmlgrid-1"


# Window Rental Agreement
wndRentalAgreement = "Rental Agreement"
btnNewCharge = "New charge"
tbrFilePrint = "FilePrint"
cntxtmnuCredit = "Credit"

# Window Enter Price Details
wndEnterPricDetails = "Enter Price Details" 

# Window Print Invoice
wndPrintInvoice = "Print Invoice"
wndReprintInvoice = "Reprint Invoice"

# Navigation 
treeVehReservations = "Vehicle Rentals|Reservations"
treeVehRePrintInvoice = "Vehicle Rentals|Reprint Invoice"
treeVehMiscINvoicCredit = "Vehicle Rentals|Misc. Invoicing/Credits"
treeUpdVehStat = "Vehicle Rentals|System Maintenance|Update Vehicle Statistics"

# Window Update Vehicle Rental Vehicle Statistics
wndUpdVehRentalVehStat = "Update Vehicle Rental Vehicle Statistics"
btnExecute = "Execute"

# Window Miscellaneous Invoicing 
wndMiscInvoicing = "Miscellaneous Invoicing"
txtCreditReasonCode = "Credit reason code"
btnNewLine = "New Line"

# Window Agreement Search
wndAgreementSearch = "Agreement Search"

# Window Amend Invoice Line
wndAmendInvoice = "Amend Invoice Line"

# Window Vehicle Specification Line 

txtEstimatedCost = "Estimated cost"
txtDiscountSpecLine = "Discount"
dropDownVATCode = "/Window/Window/Pane/Pane/Pane/Edit/SplitButton[@Name='VAT code']"

# Window Vehicles Awaiting Preparation
wndVehAwaitingPrep = "Vehicles Awaiting Preparation"
btnCreateWIP = "Create WIP"

# Window Push Specification To Vehicle Preparation
wndPushSpec = "Push Specification To Vehicle Preparation"

tblProgressTransitionWizardDescription = "/Window/Pane/Pane/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@ClassName='KClientGrid_32']/Table[@ClassName='KCMLGridPad_32']/Custom[@Name='dgo_ObjectID=VM_SK_SpecSummary-1.VM_SK_clsSpecification-1.kcmlgrid-1.Pad.Row9;']/DataItem[@Name='Description']"
tblSpecSummaryOption = "/Window/Pane/Pane/Pane[@ClassName='KCMLDlgWndClass_32']/Table[@ClassName='KClientGrid_32']/Table[@ClassName='KCMLGridPad_32']/Custom[@Name='dgo_ObjectID=VM_SK_SpecSummary-1.VM_SK_clsSpecification-1.kcmlgrid-1.Pad.Row10;']/DataItem[@Name='Description']"

# Window Direct vehicle sales
wndDirectVehSales = "Direct vehicle sales"

# Window Vehicle Specification
wndVehSpecification = "Vehicle Specification"
radiobtnConsigned = "Consigned"

# Window Document Warnings
wndDocWarnings = "Document Warnings"

# Window Vehicle Document Entry
treeVehDocEntry = "Vehicle Management|Vehicle Document Entry"
wndVehDocEntry = "Vehicle Document Entry"
tblDocWarning = "Unsettled funding exists. This will be settled automatically using document date"

# Window Long Term Invoicing
wndLongTermInvoicing = "Long Term Invoicing"
treeLongTermInvoicing = "Long Term Invoicing"

# Window Create
wndCreate = "Create"

# Window Amend Credit Note Line
wndAmendCreditNoteLine = "Amend Credit Note Line"

# Window Credit Note Printed
wndCreditNotePrinted = "Credit Note Printed"
tbrFileNew = "filenew"
tbrAgreementStartRental = "agreementstartrental"

# Window Visual Editor - Branch Controls
wndBranchControlswrapper = "Branch Controls"
tabitemSalesEnquirieswrapper = "Sales Enquiries"
txtDefaultsalecustomer = "/Window/Pane/Pane/Pane/Edit[@Name='Default sale customer']"
txtDefaultsalecustWrapper = "Default sale customer"

#Window - Vm User details
treeVMuserdetails = "Vehicle Management|System Maintenance|User Details"
tabPaymentSchedule="Payment Schedule"

txtDocref1 = "DOCREF1"
txtType = "TYPE"

treeCompany12 = "System level|Test Company 11|Test Company 11|Test Company 11|Test Company 12"
testComp12 = "Test Company 12"

treeCompany11 = "System level|Test Company 11|Test Company 11|Test Company 11|Test Company 11"
testComp11 = "Test Company 11"

treeCompany21 = "System level|Test Company 11|Test Company 11|Test Company 21|Test Company 21"
testComp21 = "Test Company 21"

treeCompany51 = "System level|Test Company 11|Test Company 51|Test Company 51|Test Branch 51"
testComp51 = "Test Branch 51"

testComp11IA = "Default Branch 11 TC 11"
btnSelectCompany = "System Menu-1.GB_clsMenu-1.button-1"
btnSelectCompanyAVM = "WORKPLACE.GB_clsMenu-1.button-1"
txtboxCompanyName = "System Menu-1.GB_clsMenu-1.Currently_selected_branch"
txtboxCompanyNameAVM = "WORKPLACE.GB_clsMenu-1.Currently_selected_branch"
# Window - System Structure
wndSysStructure = "System Structure"
btnBranch = "WORKPLACE.GB_clsMenu-1.button-1"


# window - Enquiry details
wndEnquirydetails = "Enquiry details"
drpdwnEnquiryType = "Enquiry Type"
drpdwnBranchCode = "Branch code"
drpdwnEnquiryDetailsSourceOfBuisiness = "Source of business"
valRetailSale = "Retail Sale"
txtCustomer = "Customer"
dgoenquiryno = "WORKPLACE.VM_clsEnquiryBanner-1.kcmlgrid-1"

wndVehAdministrator = "Vehicle Administrator"

tblInvoiceOrder = "Invoice order"
wndConfirmOrder = "Confirm Order"
wndDeliveryDate = "Delivery Date"
dropdwnStatus = "Status"
txtdeliverydate = "Delivery date"
Provisional = "Provisional"

wndSalesEnquiry = "Sales Enquiry"

#window Vehicle Display
treeVehicleDisplay = "Vehicle Management|Vehicle Display"
wndVehicleDisplay = "Vehicle Display"
wndSaveVehicle = "Save Vehicle"
txtVDColourDescription = "Definition-1.VM_VE_clsDefinition-1.vm_ve_colourdesc"
txtVDTrimDescription = "Definition-1.VM_VE_clsDefinition-1.vm_ve_trimdes"
dataitmSalesCustomer = "Sales customer"
txtWords = "Words"
btnChangeAllLinks = "Definition-1.VM_VE_clsOwners-1.picbutton-1"

#window New vehicle wizard
wndNewVehWizard = "New Vehicle Wizard"
txtVDVIN = "VIN"
txtVDColour = "Colour"
txtVDTrim = "Trim"
txtVDColourDesc = "VM_VE_NewDefinition-1.VM_VE_clsDefinition-1.vm_ve_colourdesc"
txtVDTrimDesc = "VM_VE_NewDefinition-1.VM_VE_clsDefinition-1.vm_ve_trimdesc"
txtVDLastOdometerReading = "Last odometer reading"
tblVehicleStatus = "Closed - Status movement"
tblVehClosedwithTradein = "Closed - Trade-in deleted from sale"

#window - New Enquiry
wndNewEnquirywrapper = "New Enquiry"
btnSavewrapper = "Save"
wndSaveSalesEnquirywrapper = "Save Sales Enquiry"
btnYeswrapper = "Yes"

#window - Enquiry
wndEnquirywrapper = "Enquiry"
btnCreatetaskwrapper  = "Create task"
wndCreateTaskwrapper = "Create Task"
txtNoteslegacywrapper = "TaskWizard1Page-1.CM_clsEventNotes-1.CM_EV_NOTES"
txtNotesLegacywrapper1 = "QuickEvent6-1.CM_clsEventNotes-1.CM_EV_NOTES"
txtUsernotes = "ADP User - Create task now"
txtTaskEventwrapper = "Event type"
txtTaskEventwrapper1 = "Task\Event type"
txtDueDatewrapper = "Due Date"
tabitemActiveTasks = "Active Tasks"
dataitemOutgoing = "Outgoing follow up phone call"
wndEditATask = "Edit A Task"
dataitemActionthetask = "Action the task"
wndCreateFollowup = "Create Followup for Outgoing follow up phone call (FSTO)"
dataitemCreatecustomtask = "Create custom task"

txtVDRegistrationDate = "Registration date"
tabsalestools = "Sales Tools"
btnEdit_Enquiry = "Edit"
btnSave_Enquiry = "Save"
btnExit_Enquiry = "Exit"


#window system browser
wndSysBrowser = "System Browser"
wndDisplay = "Display Table"
tblgridtable = "gridTable"
tblxporder =  "xporder"
tblxstock = "xstock"
treeVMdeposittable = "VM_11_deposit - Deposits taken"
treeDocqueue = "AK_11_docqueue_XS-ELEMENTS - Document Store Queue"
treeArchiveIndex = "AK_11_index - Archive index"
dropDownDirection = "Direction"
dropDownDescending = "Descending"
tabledocqueue = "docqueue"
tableindex = "index"
moduleAK = "AK"
moduleVM  = "VM"
wndEditLegalEntity = "Visual Editor - Legal Entities"
txtVATRegistrationNumber = "VAT registration number"
tblcontextmenu=   "/Menu[@Name='Context']/MenuItem[@Name='{}']"
treesysbrowsertable=    "//TreeItem/TreeItem[@Name='{}']"
treeVMSales="VM_00_vehsales - Vehicle selling details"
treeVMStock="VM_00_xstock - External stock vehicle details"
treeVMporder="VM_00_xporder - External purchase order"
txtVATRegistrationNumberxpath = "//Edit[@Name='VAT registration number']"
dropDownfiltervalue = "XLINKID"
listItemcondition = "E"
txtFilterValue = "2"
columnname = "SALEDATE"
columnname1 = "PRODDATE"
columnname2 = "RECDATE"
columnname3 = "RECDATEE"
columnname4 = "SUPPODATE"


# Window - View enquiry history
wndViewenquiryhistory = "View Enquiry History"
tblViewenquiryhistory = "View enquiry history"
btnRemoveEnquiryHistory = "Remove"
btnCloseEnquiryHistory = "Close"
tblAdvancedInvoicetxt = "Advanced invoice history-1.VM_DP_clsHistory-1.kcmlgrid-1"  



#window Manufacturer base details
treeManufbasedetails = "Vehicle Specification Data|Miscellaneous Options|Manufacturer Base Details"
wndManufBaseDetails = "Visual Editor - Vehicle Manufacturer base details"
chkAllowAllVIN = "Allow all characters in VIN"

#window print purchase vehicle
windowPrintAudiusedvehicle="Print Audi used vehicle purchase document"
windowPrintusedvehicle="Print Used vehicle purchase document"

#window Vehicle Transfer
mnuVehicleTransfer = "Tools|Vehicle transfer..."
wndVehicletransfer = "Transfer Vehicle To Branch"
drpdwnReceivingBranch = "Receiving branch"
txtboxdocumentNumber = "DocLineNoPaid-1.GL_clsDocHeaderVED-1.gl_ih_docnum"

#window Sales invoice history
wndSalesInvoiceHistory = "Sales invoice history"
btnItemPosting = "Item Postings"

#window Item Postings
wndItemPostings = "Item Postings"
tblitemposting = "WORKPLACE.GL_clsDocLineGrid-1.kcmlgrid-1"
tblVSBDefaultAccount = "VSB Default Bank Account*"

#window Approval Process Configuration Editor
treeApprovalConfig = "Workflow|System Maintenance|Approvals Configuration"
treeAVMCreditLimitOverride = "Modules|Vehicle Management|AVM Credit Limit Override"
treeApprovalManager = "Workflow|Approval Manager"
wndApprovalConfigEditor = "Approval Process Configuration Editor"
wndApprovalManager = "Approval Manager"
tblReqMyApproval = "Requests for my Approval"
wndNotesforApproval = "Enter Notes for Approval"
btnApprove = "Approve"
chkApprovalProcessOption = "Enabled"
# window Manufacturer order details
dataitemManufacturerorderdetails = "Manufacturer order details"
txtSupplierAccount = "VM_PO_OrderDetails-1.VM_PO_clsSupplier-1.vm_po_supplier"

# window Supplier details
dataitemSupplierdetails = "Supplier details"
txtSupplierAccountforUsed = "VM_PO_InvoiceDetails-1.VM_clsMultiVed-1.vm_po_supplier"

# window Master Posting Tables
wndMasterPostingTables = "Master Posting Tables"
tblTools="mnuViewBespokeOption"

# window Tools
wndTools="Tools"
btnImport="Import"

# window Import from ...
wndImportFrom ="Import from ..."
btnServer="Server"

# window Open File
wndOpenFile="Open File"
btnFileName="File name"
btnOpen="Open"

# window Open File
wndScheduleCode="Schedule Code"
wndScheduleExists="Schedule Exists"
txtSCHEME="pt_sc_SCHEME"
toolbarFind="Find"

# window Posting Schedules
wndPostingSchedules="Posting Schedules"
btnFinish="Finish"
