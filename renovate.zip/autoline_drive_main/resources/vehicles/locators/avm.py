#window bulk purchase order
window_AVM = "Advanced Vehicle Management"
trBPO = "Vehicle Management|Advanced Vehicle Management|Advanced Purchase Orders"
txt_bporef = "/Window//Pane/Edit[@Name='Purchase order reference']"
txt_bpoordedesc = "/Window//Pane/Edit[@Name='Order description']"
button_addorderline = "/Window//Pane/Button[@Name='Add Line']"
window_Editpurchaseorderline = "Edit Purchase Order Line"
txt_manuf = "//Window//Pane/Edit[@Name='Manufacturer']"
txt_model = "//Window//Pane/Edit[@Name='Model']"
txt_variant = "//Window//Pane/Edit[@Name='Variant']"
txt_orderqty = "//Window//Pane/Edit[@Name='Order quantity']"
txt_speclist = "//Window//Pane/Edit[@AutomationId='26783']"
tbl_bpospeclines= "AVM_PO_LineSpec-1.VM_AVM_PO_clsLineOptions-1.kcmlgrid-1"
button_bpospeclineok = "/Window/Window/Pane/Button[@Edit='OK']"
window_printpurchaseapproval = "Print Purchase approval"
button_confirmprogresscode = "/Window/Window/Button[@Name='Yes']"
button_avmconfirmall = "Button[@Name='Confirm All']"
button_avmok = "Button[@Name='OK']"
window_apo = "//Window[@Name='Advanced purchase orders']"
tbl_ponum = "WORKPLACE.VM_AVM_PO_clsTopPanel-1.kcmlgrid-1"
#window Shipment
windowshipments = "No Shipment Loaded"
tblshipnum = "WORKPLACE.VM_AVMShip_clsTopPanel-1.kcmlgrid-1"
tblOpenShipment = "Start-1.VM_AVMShip_clsSearch-1.kcmlgrid-1"
window_newshipment = "New Shipment"
txt_shipmentname = "Shipment name"
txt_shippingref = "Shipping reference"
txt_shipmentterms = "Shipment terms"
window_vehselect = "Vehicle selection"
tbl_bposelect = "AVMShipBPOList-1.VM_AVM_PO_clsSearch-1.kcmlgrid-1"
button_addall = "Add All"
button_addinvoice = "Add Invoice"
button_processall = "Process All"
window_invoiceheaderdetails = "Invoice header details"
tbl_selectinvoiceacc = "AVMShip_SupplierDetails-1.VM_AVMShip_clsInvSupplierList-1.kcmlgrid-1"
txt_invnum = "Invoice number"
txt_invdate = "Date"
txt_invtotal = "Invoice total £"
window_shipment = "Shipment"
buttonAddInvItem = "Add Item"
window_invoiceitemdetails = "Invoice item details"
txt_upliftcode = "Uplift code"
button_invprocess = "Process"
txt_suppinvref = "//Window[@Name='Record Display']//Pane//Edit[@Name='Supplier invoice reference']"
window_shipmentdoc = "Shipment Documents"


# Window - Bulk Sales Order
wndBulkSalesOrder = "Bulk Sales Order"

#window - search invoices
wndSearchInvoice = "Search invoices"
# Window - Advanced Vehicle Management Invoices and Credits
wndAVMInvoicesAndCredits = "Advanced Vehicle Management Invoices and Credits"
treeAVMInvoices = "Vehicle Management|Advanced Vehicle Management|Invoices"
treeAVMCredits = "Vehicle Management|Advanced Vehicle Management|Credits"
tblByBulkSalesOrder = "By Bulk Sales Order"
tblByInvoiceDate = "By invoice date"
tblIndividual = "Individual"
tblConsolidate = "Consolidated"
tblProcess = "Process"
wndVehValidation = "Vehicle Validation"
btnAVMQuickCorrect = "Quick correct"
wndQuickCorrect = "Quick Correct"
wndInvoices = "Invoices"
btnReqApproval = "Request Approval"



# Window - Advanced Sales Orders
wndBSO = "Advanced Sales Orders"
tblEnquiryNum = "WORKPLACE.VM_AVMSO_clsTopPanel-1.kcmlgrid-1"
treeBSO = "Vehicle Management|Advanced Vehicle Management|Advanced Sales Orders"
tblNewBSO = "&New"
tblTakeDeposits="Take Deposits"
tblManageTheOrder="WORKPLACE.VM_AVMSO_clsShortcut-1.kcmlgrid-1"
tblReservedVehicles="Reserved Vehicles"
tblDisplay="Display"
tblSalesSummary="Sales summary"
tblSpecSummary = "Specification summary"
tblVehiclesTable = "Details2-1.VM_clsAVMVehicleList-1.kcmlgrid-1"
wndUnabletoInitialiseProgress = "Unable to Initialise Progress Transition"
wndSaveBSOSalesEnquiry = "Save Sales Enquiry"
btnSelectUnprinted = "Select unprinted"
btnPrintSelected = "Print selected"
wndPrintDeliveryNote = "Print Delivery note"
tblDeliveryNotes = "AVMSO_DeliveryNotes-1.VM_clsAVMSO_DeliveryNotes-1.kcmlgrid-1"
treePrintDeliveryNotes = "Vehicle Management|Advanced Vehicle Management|Print Delivery Notes"

# Window - Take Deposits
txtVMPaymentType="Payment type"
txtVMValue = "Value "
txtVMVehicleRef="Vehicle Ref"
txtDepReference = "Reference"
txtVMDepositReference="Deposit reference"
toolbarNew="optionsnew"
txtBSOSearch="Search"

txt_date_takedeposit_vm = "Date "
txt_PaymentTypeDropDown_takedeposit_vm = "/Window/Window/Pane/Pane/Pane/Edit[@ClassName='KCMLDBEdit_32']/SplitButton[@Name='Payment type']"
txt_CustomerName_takedeposit_vm = "/Window/Window/Pane/Pane/Pane/Pane[@ClassName='KCMLDBEdit_32']/Edit[@Name='Customer name ']"
txt_GrossWrapper_takedeposit_vm = "Gross"

grossvalue_takedeposit_vm = "500"

txt_VehicleReferenceInTakedepositWrapper_takedeposit_vm = "Reference "
# txt_VehicleReferenceInTakedepositWrapper_takedeposit_vm = "Vehicle Ref"
txt_TakeDepositReferenceWrapper_takedeposit_vm = "Deposit reference"
takedepositaccount="d9997"
PaymentType_takedeposit_vm = "V"
lable_takeDeposits_vm = "/Window/Window/Window/Text[starts-with(@Name,'Created document number')]"


# Window - Change Progress Code
wndChangeProgressCode = "Change Progress Code"
tblConfirmSignedOrder = "Confirm signed order"
tblUnconfirmOrder = "Unconfirm order"

# Window - Approve AVM Sales Order
wndApproveAVMSalesOrder = "Approve AVM Sales Order"
tblFinalApproval = "Final Approval"

# Window - Print Order
tblPrintOrder = "Print order"
wndPrinSalesOrder = "Print Sales order"
txtboxFilter = "Filter"

# window - Reserve vehicles
wndReserveVeh = "Reserve vehicles"
tblReserve = "Reserve"
tblShowStock = "Show Stock"
txtReservationPwd = "Reservation password"
tblReserveStock = "Reserve stock" 
tblSearchUsedVeh = "BulkUsedMatchStock-1.VM_AVMSO_clsBulkUsedSrch-1.kcmlgrid-1"

wndPrintSalesQuotation = "Print Sales quotation"
tblPrintQuotation = "Print quotation"

tblProvisionallyApproveThisOrder = "Provisionally approve this order"
tblRecordAsLostSale = "Record as a Lost Sale"
tblAdvancedInvoiceHistory = "Advanced invoices history"
tblDepositHistory = "Deposits history"

# window - Order Line Details
wndOrderLineDetails = "Order Line Details"
VMdropdownOpen = "Open"
listItemTrims = "Trims"
tblClothUpholstery = "Cloth upholstery"
tblColour = "Metallic - Scuba blue"
txtQtyReq = "Quantity required"
tabPricing= "Pricing"
tabPaymentAllocationsPerUnit="Payment Allocations Per Unit"
txtOfferValueInclVAT="OrderLineSummary-1.VM_AVMSO_clsLinePriceDiscount-1.vm_avmsol_offervalueti"
tblOrderLineAllocations="OrderLineAllocations-1.VM_SO_clsInvAlloc-1.kcmlgrid-1"
textboxReference="Reference"
# Window - Order Lines 
wndAddorderLines = "Add order lines"
drpdwnManufacturer = "Manufacturer"
drpdwnModel = "Model"
drpdwnVariant = "Variant"

wndSelectCustAddress = "Select Address For Customer"
btnUseTisAddress = "Use This Address"

txtCompany = "Company"

wndOrderProcessing = "Order Processing Company Account Search"
wndCompanyDetails = "Company Details"
textboxAccount = "Account"

treeNewCompany = "//Tree/TreeItem/TreeItem[@Name='New company']"
# treeVehCompany = "//Tree/TreeItem[contains(@Name,'VehCompany')]"
cntxtmnuNewCust = "New Customer..."

wndVehCreateCustomerWizard = "Create Customer Wizard"
drpdwnTitleCode = "Title code"

txtDOCRef3 = "DOCREF3"
wndPrintSalesInvoice = "Print Sales invoice"
wndPrintConsolidatedSalesInvoice = "Print Consolidated Invoices"
wndPrintConsolidatedCreditNote = "Print Consolidated Credit note"
tblAdditionalDetails = "Additional Details"
tblInvoiceDetails = "Invoice Details"
txtInvoiceAcc = "Account"
txtInvoiceAccDesc = "Invoice-1.VM_AVMSO_clsVed-1.vm_avmsh_invaccount"
txtInvoiceAccxpath = "//Window/Pane/Pane/Pane/Edit[@Name='Account']"
tblAdvancedInvoices = "Take Advanced invoices"
tabPrice= "Pricing"
tabPaymentAllocsPerUnit="Payment Allocations Per Unit"
txtOfferPriceInclVAT="OrderLineSummary-1.VM_AVMSO_clsLinePriceDiscount-1.vm_avmsol_offerpriceti"
tblOrderLineAllocations="OrderLineAllocations-1.VM_SO_clsInvAlloc-1.kcmlgrid-1"
#window manage advanced invoices
drpdwnAVMCashType = "//Table/Table/Edit/SplitButton[@Name='Type']"
txtboxCashType = "Advanced invoice details-3.VM_DP_clsCashGrid-1.kcmlgrid-1.Pad.Row2.Cell1.dbedit"
drpdwnAVMVATCode = "//Edit/SplitButton[@Name='VAT code']"
tblAMVinvoices = "AVM_InvoiceVehicles-1.VM_clsAVMVehicleList-1.kcmlgrid-1"
tblVariant = "1.2 T FSI 5dr"

#system browser
treeitemVMenquiry = "VM_11_enquiry - Sales enquiry header"
txtEquals = "Equals"
tblattchedtoEnquiry = "1	Attached to Enquiry/Order"
tblNewDeposit = "0	New Deposit"

#window document viewer
tblDocviewerval = "WORKPLACE.AK_clsViewer-1.kcmlgrid-2"
#window advanced invoice history
wndAdvancedInvoiceHistory = "Advanced invoice history"
tblDeposit = "VM_DepositHistory-1.VM_DP_clsHistory-1.kcmlgrid-1"
btnRemove = "Remove"
btnRemove1 = "//Button[@Name='Remove']"
btnMove = "Move"
btnMove1 = "//Button[@Name='Move']"
btnRefund = "Refund"
btnRefund1 = "//Button[@Name='Refund']"
tblCreditReasons = "Deal cancelled"

#window deposit history
wndDepositHistory = "Deposit history"

#window Used Bulk sales vehicles
treeUsedBSO = "Vehicle Management|Used Vehicle Bulk Processes|Bulk Sales Orders"
wndItemisedPrintSalesQuotation = "Print Itemised used vehicle bulk sales quotation"
wndUsedPrintSalesOrder = "Print Used vehicle bulk sales order"

# Window - Bulk Sales order Invoices and Credits
wndBSOInvoicesAndCredits = "Bulk Used Vehicle Invoices and Credits"
treeUsedBSOInvoices = "Vehicle Management|Used Vehicle Bulk Processes|Invoices"
treeUsedBSOCredits = "Vehicle Management|Used Vehicle Bulk Processes|Credits"
wndPrintBulkSalesInvoice = "Print Bulk Sales Invoice"
wndPrintConsolidatedBulkSalesInvoice = "Print Consolidated Bulk Sales Invoice"

#Window Finance Details
tblFinanceDetails = "Finance Details"
txtFinanceCompany = "Finance company"
txtFinanceScheme = "Finance scheme"
txtRate = "Rate"
txtConsumerFinanceCharge = "Consumer finance charge"

#window Edit Customer Balance
wndEditCustBal = "Edit Customer Balance"
tblRateDetails = "gridRollback"