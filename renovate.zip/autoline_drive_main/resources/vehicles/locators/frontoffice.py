#Window - Sales Activity
wndSalesActivity = "/Window[starts-with(@Name,'Sales Activity')]"
txtEnqSearch = "Pane/Pane/Pane/Pane/Edit[@Name='Search']"
tblEnquiries = "MyEnquiries_Icon-1.VM_clsMyEnquiries-1.kcmlgrid-2"

#Window - Enquiry
wndEnquiryWrapper="Enquiry"
btnEnqEdit = "Pane/Button[@Name='Edit']"
btnChangeCustomerDetails = "Pane/Pane/Pane/Button[@Name='Change customer details']"
btnMoreDetails = "Pane/Pane/Pane/Button[@Name='More details']"
btnEnqUndo = "Pane/Button[@Name='Undo']"
btnUndo = "Undo"
wndWarning = "Warning"
tblSelectedVehicles="VM_Enquiry_SelectedVehicles-1.VM_clsEnquiryCompare-1.kcmlgrid-1"
tblUnConfirmSignedOrder = "Unconfirm this order"
tblPrintOrder = "Print order"
#Window - Enquiry customer
wndEnqCust = "Enquiry Customer"
wndEnquiryCustomer = "/Window/Window/Window/Window[@Name='Enquiry Customer']"

#Window - Sales Executive
Window_SalesExecutive = "/Window[starts-with(@Name,'Sales Executive')]"
tblSalesExecHome = "SalesExecHome2-1.GB_clsMenuFav-1.kcmlgrid-1"


#Window - New Enquiry
Window_NewEnquiry = "//Window[starts-with(@Name,'New Enquiry')]"
tab_customer="//*[@Name='Customer']"
tab_vehicle="//*[@Name='Vehicles']"
btn_Search = "/Window/Window[@ClassName='KCMLMasterForm_32']/Pane[@ClassName='KCMLDlgWndClass_32']/Pane[@ClassName='KTab']/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Search']"
btn_Ok_NewEnquiry = "/Window/Window/Window/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='OK']"
save_option = "/Menu[@Name='Context']/MenuItem[@Name='Save']"
window_EnquiryDetails = "Enquiry Details"
txt_EnquiryTypeDropdown = "Enquiry type"
txt_BranchCodeDropdown = "Branch code"
txt_SourceOfBusinessDropdown = "Source of business"
menuitemRetailSale = "Retail Sale"
menuitemTestCompany11 = "Test Company 11"
menuitemOther = "Other"
window_SaveSalesEnquiry = "/Window/Window/Window[@Name='Save Sales Enquiry']"
btn_Yes_SaveSalesEnquiry = "/Window/Window/Window/Button[@Name='Yes']"
window_AddFindVehicle = "/Window/Window/Window[@Name='Add/find a vehicle']"
txt_FindStockVehicle = "//Text[@Name='Find Stock Vehicle']"
window_VehicleSearch = "/Window/Window/Window/Window[@Name='Vehicle Search']"
btn_VehicleDone = "/Window/Window/Window/Window/Pane[@ClassName='KCMLDlgWndClass_32']/Button[@Name='Done']"
window_Finance = "/Window/Window/Window[@Name='Finance']"
txt_InterestCharges = "/Window/Window/Window/Pane/Edit[@Name='Interest charges']"
txt_TotalAmountPayable = "/Window/Window/Window/Pane/Edit[@Name='Total amount payable']"
win_OfferMode = "/Window/Window/Window[@Name='Offer Mode']"
txt_Offer_InterestCharges = "/Window/Window/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[@Name='Interest charges']/following-sibling::DataItem[@Name='30,000.00']"
txt_Offer_TotalAmount = "/Window/Window/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[@Name='Total amount payable']/following-sibling::DataItem[@Name='30,000.00']"
txt_CustomerSearch = "Customer"
btn_NextActions = "/Window/Window/Pane/Button[@Name='Next actions']"
Window_SalesActions = "/Window/Window/Window[@Name='Sales Actions']"
txt_LocationDropdownNew = "/Window/Window/Window/Pane/Pane/Pane/Edit/SplitButton[@Name='Location']"
txt_AccountNew = "Account "
txt_TillAccountNew = "Till account "

txt_PaymentTypeDropDownNew = "/Window/Window/Window/Pane/Pane/Pane/Edit[@ClassName='KCMLDBEdit_32']/SplitButton[@Name='Payment type']"
txt_ValueNew = "Value "
txt_VehicleRefNew = "/Window/Window/Window/Pane/Pane/Pane/Pane/Edit[contains(@Name,'Reference')] | /Window/Window/Window/Pane/Pane/Pane/Pane/Edit[contains(@Name,'Vehicle Ref')]"
txt_DepositReferenceNew = "Deposit reference"
lable_takeDepositsNew = "/Window/Window/Window/Window/Text[@AutomationId='65535']"
toolbar_SLExit = "mnuMain.toolbar.OptionsExit;"

#Window - Customer Search
tblCustomerSearch = "CRM Search-1.CM_clsSearchReport-1.kcmlgrid-1"
#Window - Casefile for 
btn_Casefile_Close = "//*[@Name='Close']"

#Window - Other enquiries for 
Window_OtherEnquiries  = "/Window[starts-with(@Name,'Other enquiries for')]"
btn_Continue = "//*[@Name='Continue']"
wndOtherEnquiries = "Other enquiries for"
tblRecordAsALostSale = "Record as a Lost Sale"
tblEnquiryBanner="WORKPLACE.VM_clsEnquiryBanner-1.kcmlgrid-1"
#Window - Finance Maintenance
WndFinanceMaintenance = "Finance Maintenance"
toolbar_VMAmend ="mnuMain.toolbar.WORKPLACE.Amend;"
txt_Frequency = "Frequency"

wndFinanceSchemeError = "Finance Scheme Error"

window_salesexe="//Window[contains(@Name,'Sales Executive')]"
btn_viewallsales="//*[@Name='View Active Sales Enquiries']"
window_salesactivity="//Window[contains(@Name,'Sales Activity -')]"
txt_search="//Edit[@ClassName='KCMLChildEdit32'][@Name='Search']"
btn_openenquiry="//*[@Name='Open Enquiry']"
window_enquiry="//Window[contains(@Name,'Enquiry')]"
window_start="//Window[contains(@Name,'Start')]"
btn_edit="//Button[@Name='Edit']"
btn_bookdemo="//Button[@Name='Book demo']"
window_salesenquiry="//Window[contains(@Name,'Sales Enquiry')]"
chk_demonstation="//*[@Name='Demonstration now']"
btn_salesorder="//Window[contains(@Name,'Sales order booking')]"
btn_quickavailablity="//TabItem[contains(@Name,'QuickAvailability')]"
txt_vehicle="//Edit[@Name='Vehicle']"
window_task="//Window[contains(@Name,'Create Task\Event Wizard')]"
window_startbooking="//Window[contains(@Name,'Start booking')]"
window_enquiryitem="//Window[contains(@Name,'Enquiry Items Requiring Action')]"
item_demobooking="//DataItem[@Name='Complete the demonstrator booking']"
window_finishbooking="//Window[contains(@Name,'Finish booking')]"
btn_done="//Button[@Name='Done']"
btn_1="//DataItem[@Name='1']"
tab_tradein="//TabItem[@Name='Trade-in']"
tab_addtradein="//*[@Name='Add a trade-in']"
txt_sourceofbusiness="//Edit[@AutomationId='26826']/SplitButton[@Name='Source of business']"
item_customer="//ListItem[@Name='Customer']"
window_tradein="//Window[contains(@Name,'Trade-in Details')]"
txt_registrationnumber="//Edit[@Name='Registration number']"
txt_colour="//Edit[@Name='Colour']"
txt_trim="//Edit[@Name='Trim']"
tab_stockprofiling="//TabItem[@Name='Stock Profiling']"
txt_estimatedstock="//Edit[@Name='Estimated in stock']"
txt_sellingprice="//Edit[@Name='Expected selling price']"
txt_valuationdate="//Edit[@Name='Valuation date']"
drp_disposal="//Edit[@Name='Disposal method']/SplitButton"
drp_retail="//*[@Name='Retail']"
txt_customervaluation="//Edit[@Name='Customer valuation']"
txt_basicvaluation="//Edit[@Name='Basic valuation']"
btn_quickcorrect="//*[@ClassName='KCMLButton_32' and @Name='Quick Correct...']"
window_quickcorrect="//Window[contains(@Name,'Quick Correct')]"
btn_customernumber="//Button[@Name='Customer number']"
txt_search="//Pane[@Name='Search']/Edit[@ClassName='KCMLChildEdit32'][@Name='Search']"
item_search="//DataItem[@Name='Select']"
btnSelect = "Select"
txt_customernumber="//Edit[@Name='Customer number']"
btn_exit="//*[@ClassName='KCMLButton_32' and @Name='Exit']"
txt_enquirynumber="//*[@Name='dgo_ObjectID=WORKPLACE.VM_clsEnquiryBanner-1.kcmlgrid-1.Pad.Row3;']//DataItem[contains(@Name,'- Enquiry (Retail Sale)')]"
btn_undo="//*[@ClassName='KCMLButton_32' and @Name='Undo']"

tblPurchaseReq = "VM_Enquiry_CustomerPurchaseRequirementsNew-1.VM_SR_clsVehicleSrch_Criteria-1.kcmlgrid-1"
tree_item_resc_paymnt = "//TreeItem[@Name='Payment schedule']/following-sibling::TreeItem[@Name='Payment schedule']"

#window system parameters
trVMSysParam = "Vehicle Management|System Maintenance|System Parameters"
windowVMSysParamName = "System Parameters"
windowVMSysParam = "//Window[contains(@Name,'Visual Editor - System Parameters')]"
windowVMSysParam1 = "/Window/Pane[1]/Pane/Pane/CheckBox[5]"
chk_FuelType = "Pane/Pane/Pane/CheckBox[@Name='Must select fuel type(s)']"
tabAccountsStatuses="Accounts Statuses"
txtAccountsPostingScheme="Accounts posting scheme"
txtPostSchemen="ACCOUNTS_vm_sp_POSTSCHEMEN"

#window search criteria
windowSearchCriteria = "Search Criteria"
linkAudi="//Hyperlink[@Name='Audi']"
linkDiesel= "//Hyperlink[@Name='Diesel']"
linkHybrid = "//Hyperlink[@Name='Hybrid']"

treeVMFinanceMaintenance = "Vehicle Management|Finance Maintenance"
treeVMFinanceSchemes = "Payment schedule|Finance schemes|Payment schedule"
wndVMFinanceSchemeError = "//*[@Name='Finance Scheme Error']"

#Window Vehicle Search
tblVehSearch = "/Window/Window/Window/Window/Pane/Pane/Pane/Table[@ClassName='KClientGrid_32']/Table[@ClassName='KCMLGridPad_32']/Custom[@Name='dgo_ObjectID=StockVehicles-1.VM_SR_clsVehicleSrch_Criteria-1.kcmlgrid-1.Pad.Row5;']/DataItem[2]"
txtSRVehSearch="/Window/Window/Window/Window/Pane/Pane/Pane/Table[@ClassName='KClientGrid_32']/Table[@ClassName='KCMLGridPad_32']/Pane[@ClassName='KCMLDBEdit_32']/Edit[@ClassName='KCMLChildEdit32']"

#Window - Showroom
tblOpenEnquiry = "/Window/Pane/Pane/Pane/Table/Table/Custom/DataItem[contains(@Name,'{}')]/following-sibling::DataItem[@Name='Open Enquiry']"
btnEditShowroom = "Edit"
tblFunding = "VM_Enquiry_Funding-1.VM_FI_clsSchemeList-1.kcmlgrid-1"
menuItemSave = "/Menu/MenuItem[@Name='Save']"
btnNextActions = "Next actions"
tabFunding = "Funding"
tblMyEnquiries="VM_Enquiry_Search-1.VM_clsMyEnquiries-1.kcmlgrid-2"
tabSalesTools="Sales Tools"
tblReviewpaymentallocations="Review payment allocations"
tabTradein = "Trade-in"
btnAddTradein = "Add a trade-in"
tabVehicles = "Vehicles"
tabSummary = "Summary"
btnExpandAllSections = "Expand all sections"
tblSummary = "VM_Enquiry_Summary-1.VM_Enq_clsGenericLayout-1.kcmlgrid-1"
wndPricing = "Pricing"
txtPricingValue = "Pricing value"
tblTradeInListWrapper="VM_Enquiry_TradeIn-1.VM_Enq_clsTradeInList-1.kcmlgrid-1"
btnDelete="Delete"
btnFinishWrapper="Finish"
tblAddaVehicle="Add a vehicle"
tblFindStockVehicle="Find Stock Vehicle"
tblTradeInList="VM_Enquiry_TradeIn-1.VM_Enq_clsTradeInList-1.kcmlgrid-1"
#Window = Vehicle Search
wndVehicleSearch="Vehicle Search"
tblVehicleSearchFO="StockVehicles-1.VM_SR_clsVehicleSrch_Criteria-1.kcmlgrid-1"
tblSearchNow="Search Now"
tblSelect="Select"
tblSelectAll = "Select All"

#Window - Manage Advanced Invoices
wndManageAdvancedInvoices = "Manage Advanced Invoices"
txtvalidationmsg = "Advanced invoice must be refunded from within the enquiry as it is still attached"


#Window = Vehicle Specification Line
wndSpecificationLineShowroom = "Vehicle Specification Line"
txtListPrice = "List price (Exc. VAT)"

#Window - Funding
wndFunding = "Funding"
tblAddPaymentSchedule = "//Custom[@Name='dgo_ObjectID=VM_Enquiry_Funding-1.VM_FI_clsSchemeList-1.kcmlgrid-1.Pad.Row{};']/DataItem[@Name='Add']"

#Window - Sales Actions
wndPrint = "Print"
wndPrintInvoice = "Print Invoice"
btnLost="Lost"
tblMyEnquiries="VM_Enquiry_Search-1.VM_clsMyEnquiries-1.kcmlgrid-2"

#Window - External Vehicle Management Hub 
treeExternalManagementHub = "Vehicle Management|External Vehicle Management Hub"
wndExternalManagementHub ="External Vehicle Management Hub"
txtStatusList="Status"
tblVehicleSelect="VehicleExceptions-1.VM_XVM_VS_clsVehicleSelect-1.kcmlgrid-1"
tblVehicleExceptions="VehicleExceptions-1.VM_XVM_VS_clsVehicleExceptions-1.kcmlgrid-1"
tblCorrelation="Correlation"
dlgCorrelationID ="Correlation ID"

#Window -  Payment Allocation Types
treePaymentAllocationTypes = "Vehicle Management|Miscellaneous Options|Payment Allocation Types"
wndPaymentAllocationTypes ="Payment Allocation Types"
toolbarInsert="EditInsert"
toolbatDelete="mnuEditDelete"
txtPaymentType1="Type"
txtDescription="Description"
txtOfferto="Offer to"
txtOfferfrom="Offer from"
tblDetails="DETAILS_gridReview"
txtDefaultAccount="Default Account"
#Window -  Delete Current Row
wndDeleteCurrentRow ="Delete Current Row"

#Window - Payment Allocations
wndPaymentAllocations="Payment Allocations"
tblInvAllocations="WORKPLACE.VM_SO_clsInvAlloc-1.kcmlgrid-1"

#Window - Showroom
wndShowroom="Showroom"
tblEnquiryBanner="WORKPLACE.VM_clsEnquiryBanner-1.kcmlgrid-1"

#window Trade-in details
wndTradeinDetails = "Trade-in Details"
wndpointofsale = "Point-of-sale"
txtVin="VIN"
txtSubVariantCode="Sub-variant code"
txtColour="Colour"
txtTrim="Trim"
txtOdometerReading="Odometer reading"
txtTrim="Trim"

#Window Vehicle Types
wndVehicleTypes = "Vehicle Types"

#Window Supersede Order
wndSupersedeOrder = "Supersede Order"

#Window Supersede Order
wndDeleteTradeIn = "Delete Trade-In"

#Window Order Vehicle
wndOrderVehicle = "Order Vehicle"

#Window Specification Synchronisation
wndSpecificationSynchronisation = "Specification Synchronisation"
tblEnquiryBanner="gridShortCut"
tblChoosevehicleSpecification="Choose which stock vehicle specification changes, if any, to apply to the sales order"