
import pytest
import httpx

@pytest.mark.asyncio
async def test_async_api_call():
    async with httpx.AsyncClient(verify=False) as client:
        response = await client.get("https://jsonplaceholder.typicode.com/posts/1")
        assert response.status_code == 200
        assert response.json()["id"] == 1
