
import pytest
from selenium.webdriver.common.by import By

@pytest.mark.ui
def test_sample_login_headless(browser, fake_data):
    browser.get("https://example.com/login")
    browser.find_element(By.ID, "username").send_keys(fake_data['username'])
    browser.find_element(By.ID, "password").send_keys("fakePassword123")
    browser.find_element(By.ID, "submit").click()

    assert "Dashboard" in browser.title
