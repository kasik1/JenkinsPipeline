
from fixtures.faker_fixture import fake_data
from fixtures.browser_fixture import browser
