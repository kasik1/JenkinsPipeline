
from faker import Faker

def generate_fake_user():
    fake = Faker()
    return {
        "username": fake.user_name(),
        "email": fake.email(),
        "password": fake.password()
    }
