
import json
from pathlib import Path

def load_test_metadata(filename="test_case_metadata.json"):
    path = Path(__file__).resolve().parent.parent / "data" / filename
    with open(path, "r") as f:
        return json.load(f)
