
import pytest
from faker import Faker

@pytest.fixture(scope="function")
def fake_data():
    fake = Faker()
    return {
        "username": fake.user_name(),
        "email": fake.email(),
        "full_name": fake.name()
    }
