import json
import os

def load_json_data(file_name):
    path = os.path.join(os.path.dirname(__file__), '..', 'test_data', file_name)
    with open(path) as f:
        return json.load(f)