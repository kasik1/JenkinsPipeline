import pytest
import requests

@pytest.mark.parametrize("json_test_data", ["test_get_users"], indirect=True)
def test_get_users(json_test_data):
    base_url = "https://jsonplaceholder.typicode.com"  # sample API
    endpoint = json_test_data["endpoint"]
    expected_status = json_test_data["expected_status"]
    
    response = requests.get(f"{base_url}{endpoint}")
    assert response.status_code == expected_status