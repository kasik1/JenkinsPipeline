import pytest
from commons.json_loader import load_json_data

@pytest.fixture
def json_test_data(request):
    data = load_json_data("g_users.json")
    return data[request.param]