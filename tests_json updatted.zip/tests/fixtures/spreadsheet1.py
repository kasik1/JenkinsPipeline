from ..commons.functions import fill_test_case_detail_values_from_json
from ..commons.json_reader import JsonReader
import pytest
import os

@pytest.fixture
def test_data(request):
    fixture_name = request.param
    # Adjust the path to your JSON file as needed
    json_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'test_cases.json')
    json_rows = JsonReader(json_path).read()
    data = {
        'test_case': {
            'test_case_id': '',
            'build': '',
            'tester': '',
            'notes': '',
            'c_environment': ''},
        'data': []
    }
    for row in (row for row in json_rows if row.get('TEST_TYPE') == fixture_name):
        data = fill_test_case_detail_values_from_json(data, row)
        data['data'].append(row)
    return data