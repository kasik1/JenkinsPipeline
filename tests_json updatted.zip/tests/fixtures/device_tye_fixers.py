import pytest
from commons.json_reader import JsonReader
from commons.faker_factory import FakerFactory
import os

@pytest.fixture
def device_type_data():
    path = os.path.join(os.path.dirname(__file__), '..', 'data', 'device_types.json')
    return JsonReader(path).read()

@pytest.fixture
def fake_device_type():
    return FakerFactory().fake_device_type()