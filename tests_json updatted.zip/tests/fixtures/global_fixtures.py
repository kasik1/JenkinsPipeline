import logging
import os
import random
import socket
from ..commons.credentials import api_key, DEVELOPMENT,STAGING
from ..commons.functions import fill_test_case_detail_values
import requests
import pytest
import urllib3

urllib3.disable_warnings(category=urllib3.exceptions.InsecureRequestWarning)

def get_default_url():
    """determines correct url to use"""
    hostname = socket.gethostname()
    if hostname.endswith("internal.cigna.com"):
        raise Exception("Please run the tests on a local/low level environments")
    return f'http://{hostname}:8080'

def pytest_addoption(parser):
    """
    :param parser: CMD options parser
    """
    default_url = get_default_url()
    parser.addoption('--browser', action='store', default='chrome', help='browser: chrome or firefox')
    parser.addoption('--mode', action='store', default='local', help='test-mode: local or grid')
    parser.addoption('--server', action='store', default=default_url, help='server: full url or dev / stag / prod')
    parser.addoption('--branch', action='store', help='The branch name of the build to be tested')
    parser.addoption('--ui_mode', action='store', help='Ui mode for browser')
    parser.addoption('--workspace', action='store', help='Jenkins workspace for each build e.g. NDOPortal_PR-777')
    parser.addoption('--build', action='store', help='Jenkins build number')


@pytest.fixture(scope='session')
def browser(request):
    return request.config.getoption('--browser')


@pytest.fixture(scope='session')
def test_mode(request):
    return request.config.getoption('--mode')


@pytest.fixture(scope='session')
def ui_mode(request):
    return request.config.getoption('--ui_mode')


@pytest.fixture(scope='session')
def server_from_terminal(request):
    """
    :param request: pytest request variable
    :return: The server option from the terminal
    This fixture has to be imported in the conftest.py file with pytest_addoption in order to make it work
    """
    return request.config.getoption('--server')


@pytest.fixture(scope='session')
def testing_environment(server_from_terminal):
    def _testing_environment(spreadsheet):
        environment = server_from_terminal

        if environment == 'DEV':
            return DEVELOPMENT

        if environment == 'STAG':
            return STAGING
        else:
            try:
                response = requests.get(environment, verify=False)
                response.raise_for_status()
            except requests.ConnectionError:
                msg = '\nError: Server provided not responded, please verify server URL'
                pytest.exit('Exiting session: ' + msg)
            return environment
    return _testing_environment


@pytest.fixture()
def test_data(request, spreadsheet):
    fixture_name = request.param
    data = {
        'test_case': {
            'test_case_id': '',
            'build': '',
            'tester': '',
            'notes': '',
            'c_environment': ''},
        'data': []
    }
    for row in spreadsheet.rows(column_index='TEST_TYPE', column_filter_value=fixture_name):
        data = fill_test_case_detail_values(data, row)
        data['data'].append(row)
    return data


@pytest.fixture
def rename_download():
    """
        :return: sub method for rename download files
        This fixture has to be imported in the test cases that use the download file
    """

    def _rename_download(name):
        """
            :param name: pytest request variable
            :return: renamed file address
            """
        filename = max([f for f in os.listdir(os.getcwd())], key=os.path.getctime)
        if filename != (os.path.join(os.getcwd(), filename), name):
            os.rename(os.path.join(os.getcwd(), filename), name)
        return filename

    return _rename_download


@pytest.fixture(scope='session')
def ndo_logger():
    """This fixture creates a global logger for the test suites."""
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("selenium.webdriver.remote.remote_connection").setLevel(logging.WARNING)
    log = logging.getLogger("ndo_logger")
    return log


@pytest.fixture(scope='session')
def ndo_logger():
    """This fixture creates a global logger for the test suites."""
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("selenium.webdriver.remote.remote_connection").setLevel(logging.WARNING)
    log = logging.getLogger("ndo_logger")
    return log


@pytest.fixture(scope='session')
def apikey():
    return api_key


@pytest.fixture
def get_object_id():
    def _get_object_id(module):
        response = module.get()
        print('================== Getting the last object id ==================')
        response_json = response.json()
        print(response_json)
        if 'results' in response.json():
            assert response_json['results'] != [], "Records not found inside of 'results' key from response"
            return response_json['results'][0]['id']
        else:
            assert response_json != [], "Records not found within the response"
            return response_json[0]['id']

    return _get_object_id


@pytest.fixture
def get_object_data():
    def _get_object_data(module, data):
        response = module.get()
        print('================== Getting the last object id ==================')
        response_json = response.json()
        print(response_json)
        if 'results' in response.json():
            assert response_json['results'] != [], "Records not found inside of 'results' key from response"
            return response_json['results'][0][f'{data}']
        else:
            assert response_json != [], "Records not found within the response"
            return response_json[0][f'{data}']

    return _get_object_data


@pytest.fixture
def get_random_object_id(ndo_logger):
    """This fixture returns a random element from a get module's payload."""

    def _get_random_object_id(module, slug_field='id', check_fields=[], check_expected_results=[]):
        """
                :param module: module to be tested.
                :param slug_field: slug field to find a specific element.
                :param check_fields: Items that the payload must have
                :param check_expected_results: Expected values for the check_fields.
                :return: A random element with the expected fields.
                This fixture returns a random element from a get module's payload.
        """

        response_module = module.get(ordering=('-' + slug_field))
        response = {}
        ndo_logger.debug("")
        ndo_logger.debug("============================== GET RANDOM OBJECT ID ==============================")
        if len(response_module.json()) > 0:
            while True:
                random_index = random.randint(0, len(response_module.json()) - 1)
                check_result = all([True if response_module.json()[random_index][field] in check_expected_results else
                                    False for field in check_fields])

                if check_result:
                    print(random_index)
                    print(slug_field)
                    res =response_module.json()['results'][0]
                    print(res)
                    response = response_module.json()['results'][random_index][slug_field]
                    ndo_logger.debug(f"The Random ID is: {response}")
                    break
        else:
            ndo_logger.warning("No records found.")
            assert response != {}, 'No records found'

        return response

    return _get_random_object_id