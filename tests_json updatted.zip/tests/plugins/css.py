css = """
<style>
#results-table-head tr {
    background-color: #035c67;
    color: white;
}

#environment {
    display: None
}

h2:first-child {
    display: None;
}
</style>
"""
