from collections import namedtuple
from ndosecrets import get_secret
import requests


TelemetryEvent = namedtuple(
    "TelemetryEvent",
    (
        "capabilityName",
        "test_case_name",
        "branch",
        "user",
        "duration",
        "module",
        "result",
        "cycle",
        "test_type",  # api or ui
        "classification",  # smoke or functional
        "workspace"
    ),
)


class TestSuiteSplunk():

    def __init__(self):
        credentials = get_secret("splunk")
        self.kpi_index = credentials['dev']["kpi_index"]
        self.kpi_token = credentials['dev']["kpi_token"]

    def send_request(self, url, index, token, payload):
        """
        This method is the final step. It sends the payload to splunk.

        :param url: Must be the url of a splunk event collector
        :param index: Splunk index name
        :param token: Token for accesing the splunk index
        :param payload: a dict with the payload to be sent
        :return: Returns the response of the splunk request.
        """
        headers = {"Authorization": f"Splunk {token}"}
        body = {"index": index, "event": payload._asdict()}
        print(f"Sending: {payload.test_case_name}")
        try:
            response = requests.post(url=url, headers=headers, json=body, verify=False)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            print(f"Error sending telemetry {str(e)}")
            return None
        return response.json()

    def send_qa_telemetry(self, test_case_name, module, duration, result, cycle, branch, test_type, classification,
                          workspace):
        """
        Send the test case result information to Splunk
        :param test_case_name: Name of the test case
        :param module: Name of the application that is being tested e.g. lbaas, c_live, fwrr
        :param duration: Duration of the test case in milliseconds
        :param result: Result of the test case e.g. 1 = pass, 2 = fail
        :param cycle: Assigned value to identify one execution from another
        :param branch: Branch that is being tested
        :param test_type: API or UI
        :param classification: Smoke or Functional
        """
        payload = TelemetryEvent(
            capabilityName='SSoT QA Testing',
            test_case_name=test_case_name,
            branch=branch,
            user='TEST_USER',
            duration=duration,
            module=module,
            result=result,
            cycle=cycle,
            test_type=test_type,
            classification=classification,
            workspace=workspace
        )
        url = 'https://esplunk-hec.sys.cigna.com/services/collector/event'
        self.send_request(url, self.kpi_index, self.kpi_token, payload)
