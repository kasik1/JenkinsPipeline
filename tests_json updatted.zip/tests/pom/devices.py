from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoT, SSoTCDevicesTypes as SSoTDT, SSoTDevices as SSoTD


class SSOTDevices(SSOTPage):
    """Contains the functions to run the manufacturer role module."""

    def add_device(self, data):
        """Add a device."""
        self.devices_page()
        self.click_add_button()
        self.set_device_data(data)
        self.click_submit_button()

    def check_title_after_add(self, name):
        locator = (By.XPATH, f"//span[contains(text(),'{name}')]")
        self.get_element(locator)

    def view_first_device(self):
        locator = (By.XPATH, '//tbody/tr[1]/td[2]/a[1]')
        self.click_on_element(locator)

    def are_device_stats_present(self):
        modules = ['Device', 'Management', 'Comments', 'Tags', 'Services', 'Images']
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'{module}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'{module} module is not present'

    def set_device_data(self, data):
        """Sets the data for the device's inputs."""
        self.get_element(SSoTD.name_selector)
        self.set_text(SSoTD.name_selector, data['NAME'], )
        self.set_select_data(SSoTD.device_role_selector, data['DEVICE_ROLE'])
        self.set_select_data(SSoTD.manufacturer_selector, data['MANUFACTURER'])
        self.set_select_data(SSoTD.device_type_selector, data['DEVICE_TYPE'])
        self.set_text(SSoTD.serial_number_selector, data['SERIAL_NUMBER'])
        self.set_text(SSoTD.asset_tag_selector, data['ASSET_TAG'])
        self.set_select_data(SSoTD.rack_selector, data['RACK'])
        self.set_select_data(SSoTD.site_selector, data['SITE'])
        self.set_select_data(SSoTD.status_selector, data['STATUS'])
        self.set_text(SSoTD.comments_selector, data['COMMENTS'])

    def set_data_inventory(self, data):
        """Sets the data for the device's inputs."""
        self.get_element(SSoTD.name_pattern_inventory)
        self.set_text(SSoTD.name_pattern_inventory, data['NAME'], )
        self.set_text(SSoTD.label_pattern_inventory, data['DEVICE_ROLE'])
        self.set_select_data(SSoTD.inventory_manufacture, data['MANUFACTURER'])

    def edit_device(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_device_data(data)
        self.click_on_element((By.NAME, "_update"))

    def inventory(self, name, data):
        """Delete a device."""
        self.click_link_text(name)
        self.click_inventory_tab()
        self.set_data_inventory(data)
        self.click_submit_button()

    def get_row_values(self, columns_to_get, row_n=1):
        """
        :param columns_to_get: List with columns to get the value e.g. ['name', 'region', 'status']
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        column_value = {}
        for column in columns_to_get:
            locator = (By.XPATH, f"//tbody/tr[{row_n}]/td[{columns[column]}]")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            column_value.update({column: value})
        return column_value

    def specific_search_dev(self, data):
        self.input_search_filters(data['name'])
        self.search_button_filters()

    def check_specific_search(self, data, row_n=1):
        """
        :param data: Dictionary with column: value from a row
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        xpaths = [f"//tbody/tr[{row_n}]/td[{columns['name']}]/a[contains(text(), '{data['name']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['status']}]/label[contains(text(), '{data['status']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['location']}]/a[contains(text(), '{data['location']}')]"]
        for xpath in xpaths:
            assert self.get_element((By.XPATH, xpath))

    def get_site_device(self):
        locator = (By.XPATH, "//td[contains(text(),'Location')]/following-sibling::td")
        region_site = self.get_element(locator)
        split_text = region_site.text
        return split_text

    def get_validate_site_region(self, site_text):
        locator_site = SSoTD.site_selector
        site = self.get_element(locator_site).text
        split_site = site.replace("×\n", "")
        site_text = site_text.replace(" (Site)", "")
        print(site_text,split_site)
        return any([True if site_text == split_site else False])

    def link_device_type(self, data):
        self.device_types_page()
        self.input_search_filters(data)
        self.search_button_filters()
        self.click_link_text(data)

    def add_component(self, tag):
        button_comp = self.get_format_selector(SSoTDT.component, tag)
        self.click_on_element(button_comp)

    def set_templete(self, name, option_front=False):
        self.set_text(SSoTDT.name_interface, name)
        self.set_text(SSoTDT.label_interface, name)
        if option_front:
            self.click_on_element((By.XPATH, "//option[contains(text(),'Rear_port:1')]"))
        self.click_submit_button()

    def update_templete(self, name):
        self.set_text(SSoTDT.edit_name_interface, name)
        self.set_text(SSoTDT.edit_label_interface, name)
        self.click_update_button()

    def buttons_component_item(self, name, button):
        locator = (By.XPATH, f"//td[contains(text(),'{name}')]/../td/a[@data-original-title='{button}']")
        self.click_on_element(locator)

    def assert_table_name(self):
        selector = (By.XPATH, "//a[contains(text(),'Name')]")
        self.get_element(selector)

    def assert_delete_interface(self, tab, name_device):
        self.search_device(name_device)
        self.click_link_text(name_device)
        try:
            self.go_to_tab(tab)
            return False
        except (TimeoutException, ValueError):
            return True

    def component_device(self, tag):
        tag_comp = self.get_format_selector(SSoTDT.tag_comp, tag)
        self.click_on_element(tag_comp)

    def get_components_table(self, name_device, tab, name_component):
        self.device_types_page()
        self.input_search_filters(name_device)
        self.search_button_filters()
        self.click_link_text(name_device)
        self.go_to_tab(tab)
        self.assert_table_name()
        try:
            locator = (By.XPATH, f"//td[contains(text(),'{name_component}')]")
            self.get_element(locator)
            return True
        except (TimeoutException, ValueError):
            return False

    def delete_device(self, name):
        """Delete a device."""
        self.click_link_text(name)
        self.click_delete_button()
        self.click_confirm_button()

    def title_img(self):
        locator_imag = (By.XPATH, "//strong[contains(text(),'Device')]")
        self.get_element(locator_imag)

    def set_file_name(self, name):
        locator_name = (By.ID, 'id_name')
        self.set_text(locator_name, name)

    def set_file_input(self, file):
        locator_name = (By.ID, 'id_file')
        self.set_text(locator_name, file)

    def submit_file(self):
        locator = (By.NAME, '_create')
        self.click_on_element(locator)

    def click_help_button(self):
        locator = (By.XPATH, "//i[contains(@class, 'mdi-help')]/parent::a")
        self.click_on_element(locator)
