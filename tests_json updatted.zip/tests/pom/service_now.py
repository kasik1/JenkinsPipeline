import time
from selenium.webdriver.common.by import By
from tests.pom.ssot import SSOTPage
import requests
import csv
import os

from tests.pom.selectors.ssot import SSoT, SSoTCDevicesTypes as SSoTDT, SSoTDevices as SSoTD, \
    SSoTLocations as SSoTS, SSoTSnow as SSoTSnow


class SSoTServiceNow(SSOTPage):
    """"SSOTVirtual_Chassis is the class with the methods for virtual chassis module."""

    def add_device(self, data):
        self.devices_page()
        self.click_add_button()
        self.set_device_data(data)
        self.click_submit_button()
        self.check_title_after_add(data['NAME'])

    def check_title_after_add(self, name):
        locator = (By.XPATH, f"//h1/span[contains(text(),'{name}')]")
        self.get_element(locator)

    def set_device_data(self, data):
        """Sets the data for the device's inputs."""
        self.get_element(SSoTD.name_selector)
        self.set_text(SSoTD.name_selector, data['NAME'], )
        self.set_select_data(SSoTD.device_role_selector, data['DEVICE_ROLE'])
        self.set_select_data(SSoTD.manufacturer_selector, data['MANUFACTURER'])
        self.set_select_data(SSoTD.device_type_selector, data['DEVICE_TYPE'])
        self.set_text(SSoTD.serial_number_selector, data['SERIAL_NUMBER'])
        self.set_text(SSoTD.asset_tag_selector, data['ASSET_TAG'])
        self.set_select_data(SSoTD.rack_selector, data['RACK'])
        self.set_select_data(SSoTD.site_selector, data['SITE'])
        self.set_select_data(SSoTD.status_selector, data['STATUS'])
        self.select_tag(data['TAG'])
        self.set_text(SSoTD.comments_selector, data['COMMENTS'])

    def add_ip_address(self, data):
        self.ip_addresses_page()
        self.click_add_button()
        locator = (By.ID, "id_address")
        self.set_text(locator, data['PRIMARY_IP4'])
        id_namespace = (By.XPATH, "//select[@id='id_namespace']/../span/span/span/span[1]")
        self.set_select_data(id_namespace, data['NAMESPACE'])
        locator_status = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
        self.set_select_data(locator_status, data['STATUS_IP'])
        self.click_submit_button()

    def add_interface(self, data):
        self.devices_page()
        self.input_search_filters(data['NAME'])
        self.search_button_filters()
        self.click_link_text(data['NAME'])
        add_component_button = (By.XPATH, "//*[@id='main-content']/div[3]/div[1]/button")
        self.click_on_element(add_component_button)
        interface_option = (By.XPATH, "//ul[@class= 'dropdown-menu']/li[5]/a")
        self.click_on_element(interface_option)
        name = (By.ID, "id_name_pattern")
        self.set_text(name, "test")
        locator_status = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
        self.set_select_data(locator_status, data['STATUS_IP'])
        ip = (By.XPATH, "//select[@id='id_ip_addresses']/../span/span/span[1]")
        self.get_element(ip)
        self.click_on_element(ip)
        ip_input_text = (By.XPATH, "//select[@id='id_ip_addresses']/../span/span/span/ul/li/input")
        self.get_element(ip_input_text)
        self.set_text(ip_input_text, data['PRIMARY_IP4'])
        time.sleep(2)
        ip_input = (By.XPATH, f"//li[contains(text(),'{data['PRIMARY_IP4']}')]")
        self.get_element(ip_input)
        self.click_on_element(ip_input)
        self.click_submit_button()

    def add_ip(self,data):
        device_name = (By.XPATH, "//span[@id= 'devicename']")
        self.get_element(device_name)
        edit_butt = (By.ID, "edit-button")
        self.click_on_element(edit_butt)
        self.title_present("Device")
        snow_assignment = (By.XPATH, "//select[@id='id_cf_servicenow_assignment_group']/../span/span/span/span[1]")
        self.set_select_data(snow_assignment, data['SNOW_ASSIGNMENT'])
        device_type = (By.XPATH, "//select[@id='id_cf_servicenow_device_type']/../span/span/span/span[1]")
        self.set_select_data(device_type, data['DEVICE_TYPE_snow'])
        id_ip_addresses = (By.XPATH, "//select[@id='id_primary_ip4']/../span/span/span/span[1]")
        self.set_select_data(id_ip_addresses, data['PRIMARY_IP4'])
        self.click_on_element((By.NAME, "_update"))
    
    def create_ci(self):
        ci_button = (By.XPATH, "//form[@id ='create_request']")
        self.click_on_element(ci_button)

    def check_ip_in_device(self, data):
        self.page_snow()
        self.click_link_text(data['NAME'])
        ip_range = data['PRIMARY_IP4']
        ip_range = ip_range.split("/")
        ip = ip_range[0]
        self.get_element((By.XPATH, f"//a[contains(text(),'{ip}')]"))
        return True

    def check_alert_text_error(self, message, timeout=60):
        """Check if the text alert is the expected."""
        selector = (By.XPATH, "//div[@class='alert alert-danger alert-dismissable']")
        return self.text_in_element(selector, message, timeout)

    def add_num_decommed(self):
        locator = (By.ID, "id_cf_decom_change_number")
        self.click_on_element(locator)
        self.set_text(locator, "CHG0658668")

    def set_status(self, select, data):
        """Set a selector from data."""
        self.click_on_element(select)
        self.set_text(SSoT.select_search_selector, data, enter=True, ssot_wait=True, down=True)

    def edit_device_data(self, data):
        """Sets the data for the device's inputs."""
        self.get_element(SSoTD.name_selector)
        self.set_status(SSoTD.status_selector, data['STATUS'])

    def set_select_data_for_search(self, select_locator, input_id, option):
        self.click_on_element(select_locator)
        locator = (By.XPATH, f"//input[@*[contains(., '{input_id}')]]")
        self.set_text(locator, option, enter=True, ssot_wait=True)

    def specific_snow_request_search(self, data):
        self.input_search_filters(data['device'])
        self.search_button_filters()
        # self.click_on_element((By.ID, 'search_button'))
        return True

    def verify_snow_ticket(self, field: str, field2: str, field3: str, row="DEVICE", row2="STAGE", row3="ACTION"):
        list_view = self.get_snow()
        for contact in list_view:
            if contact[row] == field:
                contact[row2] == field2
                contact[row3] == field3
                return True
            else:
                return False

    def get_snow_request_number(self):
        columns = self.get_index_of_table_columns()
        index = columns['ticket']
        element = self.get_element((By.XPATH, f"(//tbody/tr/td)[{index}]"))
        return element.text

    def get_snow_request_owner(self, owner):
        columns = self.get_index_of_table_columns()
        index = columns['owner']
        element = self.get_element((By.XPATH, f"(//tbody/tr/td)[{index}]"))
        text = element.text
        replace = text.replace('[', '').replace(']', '').replace('(', '').replace(')', '')
        if replace == "test_user":
            return owner
        else:
            split_text = text.split()
            string_text = split_text[1:-1]
            owner = ' '.join(x for x in string_text if x not in "[' ]")
            return owner

    def check_snow_request_row(self, device_name, stage, action):
        columns = self.get_index_of_table_columns()
        xpaths = [f"//tbody/tr/td[{columns['device']}]/*[contains(text(), '{device_name}')]",
                  f"//tbody/tr/td[{columns['stage']}]/*[contains(text(), '{stage}')]",
                  f"//tbody/tr/td[{columns['request type']}][contains(text(), '{action}')]"]
        for xpath in xpaths:
            assert self.get_element((By.XPATH, xpath))

    def get_req_pending_or_send(self, field: str, row1="DEVICE", row2="STAGE"):
        devices = []
        list_view = self.get_snow()
        for contact in list_view:
            if contact[row2] == field:
                number = contact[row1]
                devices.append(number)
                # print(contact[row1],contact[row2])
        result = set(devices)
        if len(result) > 0:
            return result

    def validate_change_status(self, initialstatus, changestatus):
        return any([True if contract in changestatus else False for contract in initialstatus])

    def edit_device(self, name, data):
        """Edit a device."""
        self.click_link_text(name)
        self.click_edit_button()
        self.edit_device_data(data)
        self.get_element((By.NAME, "_update"))
        self.click_on_element((By.NAME, "_update"))

    def go_to_snow_portal(self):
        new_page = "https://cignadev1.service-now.com"
        self.go_url(new_page)
        self.driver.switch_to.frame(self.driver.find_element_by_tag_name("iframe"))
        self.get_element(SSoTSnow.title_portal_snow, timeout=30)
        self.driver.switch_to.default_content()

    def search_snow_request(self, request):
        self.get_element(SSoTSnow.search_portal)
        self.click_on_element(SSoTSnow.search_portal)
        self.set_text(SSoTSnow.input_portal, request, enter=True)
        self.send_enter_key(SSoTSnow.input_portal)

    def get_current_request_number(self, request_number):
        time.sleep(60)
        handles = self.driver.window_handles
        for i in handles:
            print(self.driver.title)
            self.driver.switch_to.window(i)
            print(self.driver.title)
        iframe = self.driver.execute_script("return document.querySelector('macroponent-f51912f4c700201072b211d4d8c26010').shadowRoot.querySelector('div').querySelector('sn-canvas-appshell-root').querySelector('sn-canvas-appshell-layout').querySelector('sn-polaris-layout').querySelector('iframe')")
        self.driver.switch_to.frame(iframe)
        element = self.get_element(SSoTSnow.input_number)
        return element.get_attribute('value')

    def get_current_request_service_recipient(self):
        element = self.get_element(SSoTSnow.input_service_rec)
        return element.get_attribute('value')

    def get_current_request_primary_contact(self):
        element = self.get_element(SSoTSnow.input_primary_contact)
        return element.get_attribute('value')

    def click_button_cancel(self):
        try:
            self.driver.implicitly_wait(30)
            self.get_element(SSoTSnow.button_cancel)
            self.click_on_element(SSoTSnow.button_cancel)
        except:
            html = self.print_html()
            # print("html print:", html)

    def click_button_pending(self):
        try:
            self.driver.implicitly_wait(30)
            self.get_element(SSoTSnow.button_pending)
            self.click_on_element(SSoTSnow.button_pending)
        except:
            html = self.print_html()
            # print("html print:", html)

    def click_button_send(self):
        try:
            self.driver.implicitly_wait(30)
            self.get_element(SSoTSnow.button_send)
            self.click_on_element(SSoTSnow.button_send, timeout=45)
        except:
            html = self.print_html()
            # print("html print:", html)

    def check_job_send(self):
        job_result = (By.XPATH, "//span[@id='copy_title']")
        text = self.get_element(job_result).text
        assert text == 'Job Result: Send Snow Tickets'
        result_status = (By.ID, "pending-result-label")
        status = self.get_element(result_status).text
        if status == "STARTED" or status == "Running":
            print(status)
            time.sleep(15)
            return self.check_job_send()
        else:
            status = self.get_element(result_status).text
            print(status)
            return status

    def get_row_values_snow(self, columns_to_get, row_n=1):
        """
        :param columns_to_get: List with columns to get the value e.g. ['name', 'region', 'status']
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        column_value = {}
        for column in columns_to_get:
            locator = (By.XPATH, f"//tbody/tr[{row_n}]/td[{columns[column]}]")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            column_value.update({column: value})
        return column_value

    def check_specific_search_snow(self, data, row_n=1):
        """
        :param data: Dictionary with column: value from a row
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        xpaths = [f"//tbody/tr[{row_n}]/td[{columns['device']}]/a[contains(text(), '{data['device']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['stage']}]/span[contains(text(), '{data['stage']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['request type']} and text()='{data['request type']}']"]
        for xpath in xpaths:
            assert self.get_element((By.XPATH, xpath))

    def get_name_device(self):
        name = self.get_element((By.XPATH, "//h1"))
        return [name.text]

    def get_select_values_hardware(self, rows_get):
        rows_value = []
        for row in rows_get:
            locator = (
            By.XPATH, f"//label[contains(text(),'{row}')]/../div/span[1]")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            clean_value = value.replace("---------\n", "")
            clean_value = clean_value.replace("\n", "")
            rows_value.append(clean_value)

        return rows_value

    def click_request_item(self):
        self.get_element(SSoTSnow.requested_item)
        self.click_on_element(SSoTSnow.requested_item)

    def download_monitoring_file(self):
        self.get_element(SSoTSnow.download_monitoring)
        self.click_on_element(SSoTSnow.download_monitoring)

    @staticmethod
    def get_csv_values(file_name):
        """ Validate CSV content """
        path = os.getcwd()
        file_path = os.path.join(path, file_name)
        with open(file_path, newline='') as f:
            reader = csv.reader(f)
            for line in list(reader)[1:]:
                return line

    def validate_csv_values(self, csv_values, data, csv, result=True):
        key = {}
        csv_data = {}
        if csv == "snow":
            columns = ["Serial", "IP Address", "Device type", "Model ID", "Manufacturer", "Location", "Name"]
            for column, value in zip(columns, data):
                key[column] = value
            columns_csv = ['Name', 'Aliases', 'Hardware Status', 'Environment', 'Assignment group', 'Device type',
                           'Manufacturer', 'Location', 'IP Address', 'MAC Address', 'Fully qualified domain name',
                           'Serial number', 'Model ID', 'Description', 'PO number']
            for column, value in zip(columns_csv, csv_values):
                csv_data[column] = value
        else:
            columns = ["Site Code", "Serial", "IP Address", "Device Type", "Device Model", "Manufacturer", "Hostname",
                       "M/A/C/D", "Physical Address", "Status (Production, Spare, Returned to inventory"]
            for column, value in zip(columns, data):
                key[column] = value
            columns_csv = ['M/A/C/D', 'Site Code', 'Physical Address', 'Floor', 'Room', 'Rack', 'Application',
                           'Hostname', 'IP Address', 'Serial', 'Manufacturer', 'Device Model', 'Ownled/Leased',
                           'Status (Production, Spare, Returned to inventory', 'Device Type', 'Chassis Serial',
                           'Install Date', 'PO #', 'Contract #', 'Contract start date', 'Contract End Date']
            for column, value in zip(columns_csv, csv_values):
                csv_data[column] = value
        for i in key:
            if key[i] != csv_data[i]:
                result = False
        return result


    def delete_ip(self, data):
        self.ip_addresses_page()
        self.input_search_filters(data)
        self.search_button_filters()
        locator = (By.XPATH, f"//a[contains(text(),'{data}')]")
        if self.is_element_present(locator):
            self.click_link_text(data)
            self.click_delete_button()
            self.click_confirm_button()

    def bulk_delete(self):
        locator = (By.XPATH, "//button[@type='submit' and @name='_delete']")
        self.click_on_element(locator)
        locator = (By.XPATH, "//h4[text()='Confirm Bulk Deletion']")
        assert self.get_element(locator)
        locator = (By.XPATH, "//button[@type='submit' and @name='_confirm']")
        self.click_on_element(locator)

    def get_action_snow(self):
        columns = self.get_index_of_table_columns()
        xpath = f"//tbody/tr/td[{columns['request type']}]"
        action = self.get_element((By.XPATH, xpath))
        value = action.text
        return value.lower()

    def delete_device(self, name):
        """Delete a device."""
        self.click_link_text(name)
        self.click_delete_button()
        self.click_confirm_button()

    def get_status(self):
        locator = (By.XPATH, "//h5[contains(text(),'Management')]/following-sibling::div/table/tbody/tr/th[contains(text(),'Status')]/../td")
        element = self.get_element(locator)
        return element.text

    def check_req_in_snow(self):
        first_req = (By.XPATH, "(//a[contains(text(), 'REQ')])[1]")
        text = self.get_element(first_req).text
        name = (By.XPATH, "(//a[contains(text(), 'REQ')])[1]/../../td[4]/a")
        self.click_on_element(name)
        return text

    def key_enter(self):
        self.driver.close()

    def select_tag(self, data):
        self.get_element(SSoTD.tags_selector)
        self.click_on_element(SSoTD.tags_selector)
        self.get_element((By.XPATH, "//select[@id='id_tags']/../span/span/span/ul/li/input"))
        self.set_text((By.XPATH, "//select[@id='id_tags']/../span/span/span/ul/li/input"),data,down=True, enter=True, ssot_wait=True)

    def click_button_filter(self):
        locator = (By.XPATH, "//*[@id='main-content']/div[3]/button[1]")
        self.click_on_element(locator)

    def select_all_option(self):
        locator = (By.ID, "select-all-options")
        self.click_on_element(locator)

    def button_save(self):
        locator = (By.XPATH, "//*[@id='ObjectTable_config']/div/div/div[2]/form/div[3]/input[1]")
        self.click_on_element(locator)
