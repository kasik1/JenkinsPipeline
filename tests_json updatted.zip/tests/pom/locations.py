from .ssot import SSOTPage
from selenium.webdriver.common.by import By
from tests.pom.selectors.ssot import SSoTLocations as SSoTS


class SSOTLocations(SSOTPage):
    """"SSOTLocations is the class with the methods for module locations."""

    def add_location(self, data):
        """Add a location."""
        self.locations_page()
        self.click_add_button()
        self.set_location_data(data)
        self.click_submit_button()

    def title_img(self):
        locator_imag = (By.XPATH, "//strong[contains(text(),'Location')]")
        self.get_element(locator_imag)

    def view_first_location(self):
        locator = (By.XPATH, '//table[@class="table table-hover table-headings"]/tbody/tr[1]/td[2]/a[1]')
        self.click_on_element(locator)

    def is_location_description_present(self):
        locator = (By.XPATH, "//strong[contains(text(),'Location')]")
        return self.get_element(locator)

    def are_location_stats_present(self):
        modules = ['Racks', 'Devices', 'Circuits', 'Prefixes', 'VLANs', 'Virtual Machines']
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'Stats')]/../following-sibling::div/div/p[text()='{module}']")
            element = self.driver.find_elements(*locator)
            assert element, f'locations stats for {module} module is not present'

    def set_location_data(self, data):
        """Sets the data for the location's inputs."""
        self.get_element(SSoTS.name_selector)
        self.set_text(SSoTS.name_selector, data['NAME'])
        self.set_select_data(SSoTS.location_type, data['LOCATOR_TYPE'])
        self.set_select_data(SSoTS.status_selector, data['STATUS'])
        self.set_text(SSoTS.facility, data['FACILITY_TYPE'])
        self.set_text(SSoTS.description_selector, data['DESCRIPTION'])
        self.set_text(SSoTS.id_physical_adress, data['PHYSICAL_ADDRESS'])
        self.set_text(SSoTS.locator_code, data['LOCATOR'])
        self.set_text(SSoTS.id_physical_adress, data['PHYSICAL_ADDRESS'])
        self.set_text(SSoTS.comments_selector, data['DESCRIPTION'])

    def get_row_values(self, columns_to_get, row_n=1):
        """
        :param columns_to_get: List with columns to get the value e.g. ['name', 'region', 'status']
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        column_value = {}
        for column in columns_to_get:
            locator = (By.XPATH, f"//tbody/tr[{row_n}]/td[{columns[column]}]")
            element = self.get_element(locator)
            value = element.get_attribute('innerText')
            column_value.update({column: value})
        return column_value

    def specific_search(self, data):
        self.input_search_filters(data['name'])
        self.search_button_filters()

    def check_specific_search(self, data, row_n=1):
        """
        :param data: Dictionary with column: value from a row
        :param row_n: Index of the row to be checked
        """
        columns = self.get_index_of_table_columns()
        xpaths = [f"//tbody/tr[{row_n}]/td[{columns['name']}]/a[contains(text(), '{data['name']}')]",
                  f"//tbody/tr[{row_n}]/td[{columns['status']}]/label[contains(text(), '{data['status']}')]"]
        for xpath in xpaths:
            assert self.get_element((By.XPATH, xpath))

    def edit_location(self, name, data):
        """Edit a location."""
        self.click_link_text(name)
        self.click_edit_button()
        self.set_location_data(data)
        self.click_update_button()

    def delete_location(self, name):
        """Delete a location."""
        self.click_link_text(name)
        self.click_delete_button()
        self.click_confirm_button()
