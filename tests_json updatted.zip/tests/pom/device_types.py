import time

from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.ssot import SSoTCDevicesTypes as SSoTDT


class SSOTDeviceTypes(SSOTPage):
    """Contains the functions to run the devices type module"""

    def add_device_type(self, data):
        """Add a device type."""
        self.device_types_page()
        self.click_add_button()
        self.set_device_type_data(data)
        self.click_submit_button()

    def set_device_type_data(self, data):
        """Sets the data for the device_type's inputs."""
        self.get_element(SSoTDT.manufacturer_selector)
        self.set_select_data(SSoTDT.manufacturer_selector, data['MANUFACTURER'])
        self.set_text(SSoTDT.model_selector, data['MODEL'])
        self.set_text(SSoTDT.part_number_selector, data['PART_NUMBER'])
        self.set_text(SSoTDT.height_input_selector, data['HEIGHT'])
        self.set_select_data(SSoTDT.status_selector, data['STATUS'])
        self.set_text((By.ID, "id_comments"), data['MANUFACTURER'])

    def edit_device_type(self, model, data):
        """Edit a device type."""
        self.click_link_text(model)
        self.click_edit_button()
        self.set_device_type_data(data)
        self.click_update_button()

    def delete_device_type(self, model):
        """Delete a device type."""
        self.click_link_text(model)
        self.click_delete_button()
        self.click_confirm_button()

    def is_present_tab_device_type(self, tab_name):
        locator = (By.XPATH, f"//ul/li[@role='presentation']/a[text()='{tab_name}']")
        self.find_element(locator)
        return True

    def are_device_type_stats_present(self):
        modules = ['Chassis', 'Tags', 'Comments', 'Interfaces']
        for module in modules:
            locator = (By.XPATH, f"//strong[contains(text(),'{module}')]")
            element = self.driver.find_elements(*locator)
            assert element, f'Title {module} not present in the module in details view'

