"""Contains all the selectors for the SSoT Project."""
from selenium.webdriver.common.by import By


def get_locator(base_locator, index):
    """Return a complete locator by concatenating the base locator with the given index."""

    return base_locator.format(index)


class SSoT:
    """Selectors for the main page in ssot"""

    windows_selector = (By.TAG_NAME, "html")
    organization_menu_selector = (By.XPATH, "//span[@id='dropdown_title' and text()='Organization']")
    devices_menu_selector = (By.XPATH, "//span[@id='dropdown_title' and contains(text(),'Devices')]")
    devices_lifecycle_menu_selector = (By.XPATH, "//span[@id='dropdown_title' and contains(text(),'Device Lifecycle')]")
    devices_menu_selector_submenu = (By.XPATH, "//ul[@id='dropdownMenu3']/li/a[contains(text(),'Devices')]")
    inventory_page_menu_selector = (By.XPATH, "//li/a[contains(text(),'Inventory Items')]")
    contacts_menu_selector = (By.ID, "qa-test-contacts-link")
    plugins_menu = (By.XPATH, "//span[@id='dropdown_title' and contains(text(),'Apps')]")
    apps_menu = (By.XPATH, "//span[@id='dropdown_title' and text()='Apps']")
    manufacturers_menu_selector = (By.XPATH, "//ul[@id='dropdownMenu3']/li/a[contains(text(),'Manufacturer')]")
    location_menu_selector = (By.XPATH, "//ul[@id='dropdownMenu1']/li/a[contains(text(),'Locations')]")
    regions_menu_selector = (By.ID, 'qa-test-regions-link')
    racks_menu_selector = (By.ID, 'qa-test-racks-link')
    devices_types_menu_selector = (By.XPATH, "//li/a[contains(text(),'Device Types')]")
    roles_menu_selector = (By.ID, 'qa-test-device roles-link')
    rack_roles_menu_selector = (By.ID, 'qa-test-rack roles-link')
    rack_groups_menu_selector = (By.ID, 'qa-test-locations-link')
    tenant_group_menu_selector = (By.XPATH, "//a[contains(text(), 'Tenant Groups')]")
    tenant_menu_selector = (By.XPATH, "//a[contains(text(), 'Tenants')]")
    add_contact_selector = (By.ID, "add-button")
    submit_button_selector = (By.NAME, "_create")
    alert_success_selector = (By.XPATH, "//div[@class='alert alert-success alert-dismissable']")
    alert_error_selector = (By.ID, "django-messages")
    update_button_selector = (By.NAME, "_update")
    confirm_button_selector = (By.NAME, "_confirm")
    link_selector = (By.LINK_TEXT, "{}")
    virtual_chass = (By.XPATH, "//li/a[contains(text(),'Virtual Chassis')]")
    search_box_selector = (By.ID, "id_q")
    rows_selector = (By.XPATH, "//table[@class='table table-hover table-headings']/tbody/tr")
    title_row_selector = (By.CSS_SELECTOR, "table {}")
    select_search_selector = (
    By.XPATH, "//span[@class='select2-search select2-search--dropdown']/input[@class= 'select2-search__field']")
    platform_link = (By.XPATH, "//li/a[contains(text(),'Platforms')]")
    pagination = (By.CSS_SELECTOR, "ul.pagination.pull-right>li")
    next_pagination = (By.CSS_SELECTOR, "i.fa.fa-angle-double-right")
    navbar = (By.XPATH, "//div[@id= 'navbar']")
    title_modules = (By.XPATH, "//h1[contains(text(),'{}')]")
    page_snow = (By.XPATH, "//li/a[contains(text(),'ServiceNow Requests')]")
    elements_table_edit = (By.CSS_SELECTOR, "table.table.table-hover>tbody>tr>{}")
    search_nav = (By.XPATH, "(//input[@name='q'])[1]")
    circuits_menu = (By.XPATH, "//span[@id='dropdown_title' and text()='Circuits']")
    page_circuits = (By.XPATH, "//li/a[contains(text(),'Circuits')]")
    page_circuit_types = (By.XPATH, "//li/a[contains(text(),'Circuit Types')]")
    page_providers = (By.XPATH, "//li/a[contains(text(),'Providers')]")
    add_components = (By.XPATH, "//button[@id='add-device-components']")
    ipam_menu = (By.XPATH, "//span[@id='dropdown_title' and text()='IPAM']")
    ip_addresses = (By.XPATH, "//li/a[contains(text(),'IP Addresses')]")
    contracts_menu_selector = (By.XPATH, "//ul[@id='dropdownMenu10']/li/a[contains(text(),'Contracts')]")
    device_indicator_menu_selector = (By.XPATH, "//a[@href='/plugins/device-indicator/indicator/']")
    installed_apps_menu_selector = (
    By.XPATH, "//li[text()='General']/following-sibling::li/a[contains(text(), 'Installed Apps')]")
    discovery_device_menu_selector = (By.ID, "qa-test-discover a device-link")
    discovery_multiple_menu_selector = (By.ID, "qa-test-discover multiple devices-link")
    update_devices_menu_selector = (By.ID, "qa-test-update devices-link")
    icon_change_log = (By.XPATH, "(//div/table/tbody/tr)[1]/.//a[@data-original-title='Change log']")
    icon_view_ele = (By.XPATH, "(//div/table/tbody/tr)[1]/.//a[@title='View elevations']")
    upload_csv_menu_selector = (By.ID, "qa-test-upload csv-link")
    asn_assignment_menu_selector = (By.ID, "qa-test-asn assignments-link")
    button_export = (By.XPATH, "//a[@id='button_add']/../div/button")
    asn_companies_menu_selector = (By.ID, "qa-test-companies-link")
    asn_carriers_menu_selector = (By.ID, "qa-test-carriers/zones-link")
    jobs_menu_selector = (By.XPATH, "//span[@id='dropdown_title' and contains(text(),'Jobs')]")
    job_results_menu = (By.XPATH, "//li/a[contains(text(),'Job Results')]")
    inventory_list_page = (By.XPATH, "//ul[@id='dropdownMenu14']/li/a[contains(text(),'Inventory List')]")
    stag_inventory_list_page = (By.XPATH, "//ul[@id='dropdownMenu14']/li/a[contains(text(),'Staging List')]")
    bulk_snow_page = (By.XPATH, "//ul[@id='dropdownMenu14']/li/a[contains(text(),'ServiceNow Create Bulk Requests')]")
    partial_discover_page = (
    By.XPATH, "//ul[@id='dropdownMenu14']/li/a[contains(text(),'Run IP Fabric Partial Discovery')]")
    device_bulk = (By.XPATH, "//a[@href='/plugins/ssot-cigna/custom_device_bulk_import/']")
    delete_dropdown_device = (By.XPATH, "//*[@id='actions-dropdown']/span[1]")
    delete_button_link = (By.ID, "delete-button")
    jobs_menu = (By.XPATH, "//li/a[contains(text(),'Jobs')]")
    email_address_link = (By.XPATH, "//th[@class='field-addresses']/a")
    email_address = (By.ID, "id_addresses")
    save_button = (By.XPATH, "//input[@type='submit' and @value='Save']")
    user_link = (By.XPATH, "//span[text() = 'test_user']")
    missing_device_email_address_link = (By.XPATH, "(//a[text() = 'Missing devices report email addressess'])[2]")
    admin_link = (By.XPATH, "(//a[text()=' Admin'])")
    delete_email_link = (By.XPATH, "(//a[text()='Delete'])")
    device_status = (By.XPATH, "(//td[text() = 'Status']/following::label)[1]")
    yes_button = (By.XPATH, "//input[@type='submit' and @value='Yes, I’m sure']")
    add_email_button = (By.XPATH, "//div[@id ='content-navbar-collapse']/a")
    update_device_email_address_link = (By.XPATH, "(//a[text() = 'Ci needs update report email addressess'])[2]")
    duplicated_device_email_address_link = (By.XPATH, "(//a[text() = 'Duplicated ci report email addressess'])[2]")
    cmdb_dashboard_menu_selector = (By.XPATH, "//a[@href='/plugins/device-indicator/cmdb-dashboard/']")


class SSOTIndicators:
    """Selectors for the contact module"""
    filter_location_list = (By.CSS_SELECTOR, "#select2-id_location-results li:nth-child(2)")
    location_dropdown_list = (By.CSS_SELECTOR, "li.select2-results__option")
    advanced_button = (By.CSS_SELECTOR, "#tabs li:nth-child(2) a")
    filter_closed = (By.CSS_SELECTOR, "span.filter-selection span")
    filter_result = (By.CSS_SELECTOR, "#indicators-list-form tr:first-child td h3")
    filter_result_nom = (By.CSS_SELECTOR, "#indicators-list-form td")
    apply_button = (By.CSS_SELECTOR, "#default-filter button")
    rankgroup_dropdown = (By.XPATH, "(//span[@class='select2-selection select2-selection--multiple'][{}])[{}]")
    filter_dropdown = (By.XPATH, "(//span[@class='select2-selection select2-selection--multiple'][1])")
    filter_result_empty = (By.CSS_SELECTOR, "li.select2-results__option:nth-of-type(1)")
    status_list = (By.CSS_SELECTOR, "li.select2-results__option:nth-of-type(1)")
    filter_locations = (By.XPATH, "//div[contains(@class,'filters-applied')]/span")
    filter_location_value = (By.XPATH, "(//*[contains(@class,'filter-selection-choice-remove remove-filter-param')])["
                                       "{}]")
    filter_unclaimed_date = (By.XPATH, "(//*[contains(@class,'flatpickr-day today')]")
    filter_location_dropdown = (By.XPATH, "//label[text() ='Location']/following-sibling::span/span")
    filter_location_input = (By.XPATH, " //label[text() = 'Location']/following-sibling::span//input")
    filter_value = (By.XPATH, "//li[text() = '{}']")
    filter_status_dropdown = (By.XPATH, "//label[text() ='Status']/following-sibling::span/span")
    filter_status_input = (By.XPATH, " //label[text() = 'Status']/following-sibling::span//input")
    filter_role_dropdown = (By.XPATH, "//label[text() ='Role']/following-sibling::span/span")
    filter_role_input = (By.XPATH, "//label[text() ='Role']/following-sibling::span//input")
    filter_service_dropdown = (By.XPATH, "//label[text() ='ServiceNow Assignment Group']/following-sibling::span/span")
    filter_service_input = (By.XPATH, "//label[text() ='ServiceNow Assignment Group']/following-sibling::span/input")
    remove_filter = (By.XPATH, "//span[contains(@class,'filter-selection')]/span")
    snmp_enabled = (By.XPATH, "(//th[text() = 'SNMP Enabled']/following::td)[3]")
    snmp_working = (By.XPATH, "(//th[text() = 'SNMP Working']/following::td)[3]")
    icmp_enabled = (By.XPATH, "(//th[text() = 'ICMP Enabled']/following::td)[3]")
    icmp_working = (By.XPATH, "(//th[text() = 'ICMP Working']/following::td)[3]")
    devices_list = (By.XPATH, "(//table/following::h3)")


class SSoTContacts:
    """Selectors for the contact module"""

    title_selector = (By.NAME, "title")
    company_selector = (By.NAME, "company")
    first_name_selector = (By.NAME, "first_name")
    last_name_selector = (By.NAME, "last_name")
    mobile_phone_selector = (By.NAME, "mobile_phone")
    desk_phone_selector = (By.NAME, "desk_phone")
    other_phone_selector = (By.NAME, "other_phone")
    mail_selector = (By.NAME, "email")
    search_button_selector = (By.ID, "butto-apply-search")


class SSoTCManufacturers:
    """Selectors for the manufacture module"""

    name_selector = (By.NAME, "name")
    description_selector = (By.NAME, "description")


class SSoTCDevicesTypes:
    """Selectors for the devices type module"""

    manufacturer_selector = (By.XPATH, "//select[@id='id_manufacturer']/../span/span/span/span[1]")
    # input_sear=
    status_selector = (By.XPATH, "//select[@id='id_subdevice_role']/../span/span/span/span[1]")
    height_input_selector = (By.ID, 'id_u_height')
    model_selector = (By.NAME, "model")
    part_number_selector = (By.NAME, "part_number")
    tag_comp = (By.XPATH, "//li[@role='presentation']/a[contains(text(), '{}')]")
    component = (By.XPATH, "//strong[contains(text(),'{}')]/../following-sibling::div/div/a")
    name_interface = (By.NAME, "name_pattern")
    label_interface = (By.NAME, "label_pattern")
    edit_name_interface = (By.NAME, "name")
    edit_label_interface = (By.NAME, "label")


class SSoTCRoles:
    """Selectors for the roles module"""

    name_selector = (By.NAME, "name")
    color_selector = (By.XPATH, "//label[contains(text(),'Color')]/following-sibling::div")
    vr_role_selector = (By.ID, "id_vm_role")
    description_selector = (By.NAME, "description")

    site_selector = (By.XPATH, "//select[@id='id_site']/following-sibling::div/div/span[1]")


class SSoTDevices:
    """Selectors for the devices module"""

    def set_value(self, value):
        self.value = value

    def get_value(self):
        return self.value

    name_selector = (By.NAME, "name")
    device_role_selector = (By.XPATH, "//select[@id='id_role']/../span/span/span/span[1]")
    manufacturer_selector = (By.XPATH, "//select[@id='id_manufacturer']/../span/span/span/span[1]")
    device_type_selector = (By.XPATH, "//select[@id='id_device_type']/../span/span/span/span[1]")
    serial_number_selector = (By.NAME, "serial")
    asset_tag_selector = (By.NAME, "asset_tag")
    site_selector = (By.XPATH, "//select[@id='id_location']/../span/span/span/span[1]")
    rack_selector = (By.XPATH, "//select[@id='id_rack']/../span/span/span/span[1]")
    status_selector = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
    # assignment_selector = (By.XPATH, "//select[@id='id_cf_Assignment Group']/following-sibling::div/div/span[1]")
    platform_selector = (By.XPATH, "//select[@id='id_platform']/../span/span/span/span[1]")
    primary_ip4_selector = (By.NAME, "primary_ip4")
    comments_selector = (By.NAME, 'comments')
    devices_first_check_box = (By.XPATH, "(//tbody/tr/td/input[@type='checkbox'])[1]")
    devices_not_found = (By.XPATH, "//td[contains(text(), '— No devices found —')]")
    add_component_button = (By.XPATH, "//button[text()= ' Add Components ']")
    name_pattern_inventory = (By.NAME, "name_pattern")
    label_pattern_inventory = (By.NAME, "label_pattern")
    inventory_manufacture = (By.XPATH, "//select[@id='id_manufacturer']/following-sibling::div/div/span[1]")
    snow_device_type = (By.XPATH, "//select[@id='id_cf_ServiceNow Device Type']/following-sibling::div/div/span[1]")
    tags_selector = (By.XPATH, "//select[@id='id_tags']/../span/span")

    @property
    def components_option(self):
        selector = (By.XPATH, f"//li/a[@class='formaction' and contains(text(),'" + self.get_value() + "')]")
        return selector


class SSoTTenantGroup:
    """Selectors for the tenants group module"""

    parent_selector = (By.XPATH, "//select[@id='id_parent']/following-sibling::span")
    name_selector = (By.NAME, "name")
    description_selector = (By.NAME, "description")
    edit_tenant_group = (By.CSS_SELECTOR, "i.mdi.mdi-pencil")
    delete_tenant_group = (By.CSS_SELECTOR, "i.mdi.mdi-trash-can-outline")


class SSoTTenant:
    """Selectors for the tenant module"""

    group_selector = (By.XPATH, "//select[@id='id_tenant_group']/following-sibling::span")
    input = (By.XPATH,
             "//body/div[1]/main[1]/div[1]/div[3]/div[1]/div[1]/form[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/input[1]")
    name_selector = (By.NAME, "name")
    description_selector = (By.NAME, "description")
    comments_selector = (By.NAME, "comments")
    search_button = (By.ID, "button-search-magnifier")
    edit_tenant_group = (By.XPATH, "//tbody/tr[2]/td[5]/a[2]")
    delete_tenant_group = (By.XPATH, "//tbody/tr[2]/td[5]/a[3]")


class SSoTInventorySelectors:
    """Selectors for the inventory module"""

    def set_value(self, value):
        self.value = value

    def get_value(self):
        return self.value

    manufacturer_select = (By.NAME, 'manufacturer')
    manufacturer_select_option_1 = (By.XPATH, "(//select/option[@selected]/following-sibling::option)[1]")
    inventory_items_not_found = (By.XPATH, "//td[contains(text(), '— No inventory items found —')]")
    items_first_check_box = (By.XPATH, "(//tbody/tr/td/input[@type='checkbox'])[1]")
    checkbox_search = (By.XPATH, "(//tbody/tr/td/a[contains(text(),'Test Item')][1])/../../td[1]")
    edit_selected_button = (By.XPATH, "//div[2]/div/button[1]")
    action_button = (By.XPATH, "//div/button[2]/span[2]")
    delete_option = (By.NAME, "_delete")
    edited_manufacturer_select = (By.XPATH, "//span/b[@role='presentation']")
    edited_manufacturer_select_option_1 = (By.XPATH, "//ul[@id='select2-id_manufacturer-results']/li[1]")
    apply_button_selector = (By.NAME, "_apply")
    table_headers = (By.XPATH, "//th/a")
    search_input = (By.ID, "q-search")
    apply_filters = (By.ID, "butto-apply-search")
    return_value = (By.XPATH, "//td[contains(text(),'Return Value')]/following-sibling::td")

    @property
    def table_header_asset_tag(self):
        selector = (By.XPATH, "(//tr/td[not(@class='min-width')])[" + str(self.get_value()) + "]")
        return selector

    @property
    def inventory_form_input(self):
        selector = (By.NAME, self.get_value())
        return selector

    @property
    def asset_tag(self):
        selector = (By.XPATH, "//tr/td[contains(text(), '" + self.get_value() + "')]")
        return selector


class SSoTLocations:
    """Selectors for the site module"""
    name_selector = (By.NAME, "name")
    location_type = (By.XPATH, "//select[@id='id_location_type']/../span/span/span/span[1]")
    locator_code_selector = (By.NAME, "locator_code")
    status_selector = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
    region_selector = (By.XPATH, "//select[@id='id_region']/following-sibling::div/div/span[1]")
    facility_selector = (By.ID, "id_facility_type")
    ownership_type_selector = (By.ID, "id_ownership_type")
    facility = (By.ID, "id_facility")
    description_selector = (By.NAME, "description")
    property_id = (By.NAME, "cf_Property ID")
    primary_use = (By.NAME, "cf_Primary Use")
    clasif = (By.NAME, "cf_Site Classification")
    id_physical_adress = (By.ID, "id_physical_address")
    locator_code = (By.ID, "id_cf_snow_sys_id")
    country_selector = (By.NAME, "cf_Country")
    city_selector = (By.NAME, "cf_City")
    state_selector = (By.NAME, "cf_State")
    zip_selector = (By.NAME, "cf_Zip")
    comments_selector = (By.NAME, "comments")


class SSoTRacks:
    """Selectors for the rack module"""
    name_selector = (By.NAME, "name")
    facility_id_selector = (By.NAME, "facility_id")
    site_selector = (By.XPATH, "//select[@id='id_site']/following-sibling::div/div/span[1]")
    status_selector = (By.XPATH, "//select[@id='id_status']/following-sibling::div/div/span[1]")
    serial_selector = (By.NAME, "serial")
    asset_tag_selector = (By.NAME, "asset_tag")


class SSoTVirtualChassis:
    """Selectors for the rack module"""
    title = (By.XPATH, "//strong[contains(text(),'Virtual Chassis')]")
    name_input = (By.ID, "id_name")
    domain_input = (By.ID, "id_domain")
    site_selector = (By.XPATH, "//select[@id='id_location']/../span/span/span/span[1]")
    racks_selector = (By.XPATH, "//select[@id='id_rack']/../span/span/span/span[1]")
    add_members = (By.XPATH, "//strong[contains(text(),'Members')]/../following-sibling::div/a")
    device_add = (By.XPATH, "//select[@id='id_device']/../span/span/span/span[1]")
    input_position = (By.ID, "id_vc_position")
    input_priority = (By.ID, "id_vc_priority")
    save_button = (By.NAME, "_save")
    view_virtual = (By.XPATH, "//strong[contains(text(),'Virtual Chassis')]/../following-sibling::div/a")
    master = (By.NAME, "master")
    master_option = (By.XPATH, "//select[@id='id_master']/option[2]")
    view_master = (By.XPATH, "//tbody/tr[2]/td[1]/a[1]")
    primary_ip = (By.XPATH, "//td[contains(text(),'Primary IPv4')]/following-sibling::td")
    title_chassis = (By.XPATH, "//span[contains(text(),'{}')]")


class SSoTSnow:
    """Selectors for the service now module"""

    title_portal_snow = (By.CLASS_NAME, "title")
    search_portal = (By.XPATH, "//header/div[1]/div[1]/div[2]/div[1]/div[4]/form[1]/div[1]/label[1]/span[1]")
    input_portal = (By.ID, "sysparm_search")
    input_number = (By.ID, "sys_readonly.sc_request.number")
    input_service_rec = (By.ID, "sys_display.sc_request.requested_for")
    input_primary_contact = (By.ID, "sys_display.sc_request.u_primary_cntct")
    button_cancel = (By.NAME, "_cancel_snow_requests")
    button_pending = (By.NAME, "_set_requests_to_pending")
    requested_item = (By.XPATH, "//a[contains(text(),'RIT')][1]")
    download_snow = (By.XPATH, "//a[contains(text(),'servicenow-')]")
    download_monitoring = (By.XPATH, "//a[contains(text(),'monitoring-')]")
    button_send = (By.NAME, "_send_pending_requests")


class SSoTPlatform:
    """Selectors for the plataform"""

    name_input = (By.ID, "id_name")
    manufacturer_selector = (By.XPATH, "//select[@id='id_manufacturer']/../span/span/span/span[1]")
    napalm_driver_selector = (By.NAME, "napalm_driver")
    desc = (By.ID, "id_description")


class SSoTCircuits:
    """Selectors for the circuits"""

    provider_selector = (By.XPATH, "//select[@id='id_provider']/../span/span/span/span[1]")
    circuit_id = (By.ID, "id_cid")
    type_selector = (By.XPATH, "//select[@id='id_circuit_type']/../span/span/span/span[1]")
    status_selector = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
    comments_circuit = (By.ID, "id_comments")


class SSoTCircuitTypes:
    """Selectors for the circuits"""

    name_circuit = (By.ID, "id_name")
    desc_circuit = (By.ID, "id_description")


class SSoTProviders:
    """Selectors for the circuits"""

    name_provider = (By.ID, "id_name")
    asn_provider = (By.ID, "id_asn")
    account_number = (By.ID, "id_account")
    comment_provider = (By.ID, "id_comments")


class SSoTContracts:
    """Selectors for the contact module"""

    input_name = (By.NAME, "name")
    input_vendor = (By.ID, "id_provider")
    input_contract = (By.NAME, "contract_type")


class SSoTRequest:
    """Selectors for the contact module"""

    select_category = (By.XPATH, "//select[@id='id_category']/option[text()='{}']")
    input_desc = (By.NAME, "description")
    select_priority = (By.XPATH, "//select[@id='id_priority']/option[text()='{}']")
    input_completed = (By.NAME, "is_completed")


class SSoTDiscoveryDevice:
    """Selectors for the contact module"""
    card_json = (By.XPATH, "//h5[contains(text(),'JSON Format')]/following-sibling::div/pre")
    card_device_data = (By.XPATH, "//h5[contains(text(),'Device Data')]/following-sibling::div/table")
    td_val_device_data = (By.XPATH,
                          "//h5[contains(text(),'Device Data')]/following-sibling::div/table/tbody/tr/th/b[contains(text(),'{}')]/../../td")
    selects_data_not_found = (
    By.XPATH, "//h5[contains(text(),'Device Data')]/following-sibling::div/table/tbody/tr/td/div/../../th")
    input_data_not_found = (
    By.XPATH, "//h5[contains(text(),'Device Data')]/following-sibling::div/table/tbody/tr/td/input/../../th")
    selector_search = (By.XPATH, "//select[@id='id_manufacturer']/following-sibling::div/div/span[1]")
    selects_virtual_not_found = (
        By.XPATH, "//h5[contains(text(),'Virtual Chassis Data')]/following-sibling::div/table/tbody/tr/td/div/../../th")
    td_val_device_data_virtual = (By.XPATH,
                                  "//h5[contains(text(),'Virtual Chassis Data')]/following-sibling::div/table/tbody/tr/th/b[contains(text(),'{}')]/../../td")
    value_master = (By.XPATH, "//table/tbody/tr/th/b[contains(text(),'Master Device')]/../../td/a")
    value_virtual_chassis = (By.XPATH, "//table/tbody/tr/th/b[contains(text(),'Name')]/../../td/a")
    text_area_csv = (By.ID, "id_csv")
    input_file = (By.ID, "id_csv_file")
    button_save_net = (By.ID, "button_save_device")


class SSoTUpdateDevices:
    """Selectors for the contact module"""
    link_card_csv = (By.XPATH, "//a[contains(text(),'Update from CSV')]")
    button_card_csv = (By.XPATH, "//button[contains(text(),'CSV Data')]")
    text_area_csv = (By.ID, "id_csv")
    button_submit = (By.XPATH, "//button[contains(text(),'Submit')]")
    button_card_file = (By.XPATH, "//button[contains(text(),'CSV File Upload')]")
    input_file = (By.ID, "id_csv_file")
    name_device = (By.XPATH, "//div[@id='content-title']/h1")
    status_device = (By.XPATH, "//th[contains(text(),'Status')]/following-sibling::td")
    comment_device = (By.XPATH, "//h5[contains(text(),'Comments')]/following-sibling::div/p")
    region_device = (By.XPATH, "//th[contains(text(),'Region')]/following-sibling::td")
    rack_device = (By.XPATH, "//th[contains(text(),'Rack')]/following-sibling::td")
    location_device = (By.XPATH, "//th[contains(text(),'Location')]/following-sibling::td")
    platform_device = (By.XPATH, "//th[contains(text(),'Platform')]/following-sibling::td")
    service_now_device = (By.XPATH, "//span[contains(text(),'ServiceNow Device Type')]/../following-sibling::td")
    assignment_group_device = (By.XPATH, "//span[contains(text(),'Assignment Group')]/../following-sibling::td")
    device_driver = (By.XPATH, "//span[contains(text(),'SNMP Device Driver')]/../following-sibling::td")
    serial_device = (By.XPATH, "//th[contains(text(),'Serial Number')]/following-sibling::td")
    site_device = (By.XPATH, "//th[contains(text(),'Site')]/following-sibling::td")


class SSoTUploadCircuits:
    """Selectors for the contact module"""
    id_csv_file = (By.ID, "id_csv_file")


class SSoTAsnAssignments:
    """Selectors for the contact module"""
    as_num = (By.ID, "id_as_number")
    desc = (By.ID, "id_description")
    status = (By.XPATH, "//select[@id='id_status']/following-sibling::div/div/span[1]")
    date = (By.ID, "id_date_assigned")
    company = (By.XPATH, "//select[@id='id_company']/following-sibling::div/div/span[1]")
    carrier = (By.XPATH, "//select[@id='id_carrier']/following-sibling::div/div/span[1]")
    site = (By.XPATH, "//select[@id='id_sites']/following-sibling::div/div/div/span[1]")
    device = (By.XPATH, "//select[@id='id_devices']/following-sibling::div/div[1]/div[1]")
    button_submit = (By.XPATH, "//button[contains(text(),'Submit')]")
    name = (By.ID, "id_name")
    text_bulk = (By.ID, "id_csv")


class SSoTAssetManagement:
    """Selectors for the contact module"""
    name_title = (By.XPATH, "//label[@for='id_name']")
    name_input = (By.ID, "id_name")
    location_select = (By.XPATH, "//select[@id='id_location']/following-sibling::span/span/span/span[1]")
    device_type_select = (By.XPATH, "//select[@id='id_device_type']/following-sibling::span/span/span/span[1]")
    role_select = (By.XPATH, "//select[@id='id_role']/following-sibling::span/span/span/span[1]")
    comments_input = (By.ID, "id_comments")


class BulkSnow:
    service_now_assig = (By.XPATH, "//select[@id='id_cf_servicenow_assignment_group']/../span/span/span/span[1]")
    device_type = (By.XPATH, "//select[@id='id_cf_servicenow_device_type']/../span/span/span/span[1]")


class PartialDiscover:
    button_submit = (By.XPATH, "//button[contains(text(),'Submit')]")
    text_area = (By.NAME, "data")
