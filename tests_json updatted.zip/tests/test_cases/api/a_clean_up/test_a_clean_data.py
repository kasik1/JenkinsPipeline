import pytest


@pytest.mark.clean_data
class TestCleanUpRecords:

    @pytest.mark.parametrize('test_data', ['test_clean_records_for_testing'], indirect=True)
    def test_clean_records_for_testing(self, http, test_data, response_results, apikey, response_asserts):
        """
        This method is used to clean records  that were created from test case execution
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get(f"{row['name']}")
            response_results(response)
            results_json = response.json()['results']
            for result in results_json:
                id = result['id']
                split = end_point.split("?")
                url_delete = split[0]
                get_end_point = url_delete + '{}/'.format(id)
                module = http(get_end_point)
                module.set_headers(header)
                response = module.delete(id)
                response_results(response, print_json=False, print_content_type=False)
                response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)
