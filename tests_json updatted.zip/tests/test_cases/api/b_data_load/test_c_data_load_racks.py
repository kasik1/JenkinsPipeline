import pytest


@pytest.mark.data_load
class TestRacks:

    @staticmethod
    def update_record(module, payload, object_id):
        module.set_body(payload)
        response = module.put(object_id + '/')
        return response

    @staticmethod
    def create_record(module, payload):
        module.set_body(payload)
        response = module.post('')
        return response

    @staticmethod
    def set_payload_rack_group(name, location, slug):
        payload = {
            'name': name,
            'location': location,
            'slug': slug,
            'description': 'Created by Load Test Data Script',
        }
        return payload

    @staticmethod
    def set_payload_rack(location, name_rack, asset_tag):
        payload = {
            'location': location,
            'name': name_rack,
            'status': 'Active',
            'asset_tag': asset_tag,
            'comments': 'Created by Load Test Data Script',
        }
        return payload

    @staticmethod
    def get_object_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @pytest.mark.parametrize('test_data', ['test_data_load_rack_group'], indirect=True)
    def test_data_load_rack_group(self, http, test_data, response_results, apikey, response_asserts,
                                  response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        rack_roles = [
            {'name': 'Test-Rack group 01', 'slug': 'test-rack-group-01'},
            {'name': 'Test-Rack group 02', 'slug': 'test-rack-group-02'},
            {'name': 'Test-Rack group 03', 'slug': 'test-rack-group-03'}]
        location = self.get_object_id(http, response_results, apikey, '/api/dcim/locations/{}',
                                      "name=	QA-TD Location - view")

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for role in rack_roles:
                name = role['name']
                slug = role['slug']
                payload = self.set_payload_rack_group(name, location, slug)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    response = self.update_record(module, payload, object_id)
                    response_results(response, print_json_rows=False)
                    response_asserts(response)

                else:
                    response = self.create_record(module, payload)
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)

    @pytest.mark.parametrize('test_data', ['test_data_load_racks'], indirect=True)
    def test_data_load_racks(self, http, test_data, response_results, apikey, response_asserts,
                             response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        location = self.get_object_id(http, response_results, apikey, '/api/dcim/locations/{}',
                                      "name=	QA-TD Location - view")
        rack_names = [
            {'name': 'Test-Rack 01', 'asset_tag': 'qa_td_rack_01'},
            {'name': 'Test-Rack 02', 'asset_tag': 'qa_td_rack_02'},
            {'name': 'Test-Rack 03', 'asset_tag': 'qa_td_rack_03'}]

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for rack in rack_names:
                name = rack['name']
                asset_tag = rack['asset_tag']
                payload = self.set_payload_rack(location, name, asset_tag)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    response = self.update_record(module, payload, object_id)
                    response_results(response, print_json_rows=False)
                    response_asserts(response)

                else:
                    response = self.create_record(module, payload)
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)
