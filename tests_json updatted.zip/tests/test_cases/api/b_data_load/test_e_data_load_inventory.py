import pytest


@pytest.mark.data_load
class TestInventory:

    def setup(self):
        self.url_manufacturer = '/api/dcim/manufacturers/'
        self.url_device = '/api/dcim/devices/'

    @staticmethod
    def update_record(module, payload, object_id, response_results, response_asserts):
        module.set_body(payload)
        response = module.put(object_id + '/')
        response_results(response, print_json_rows=False)
        response_asserts(response)
        return response

    @staticmethod
    def create_record(module, payload, response_results, response_asserts):
        module.set_body(payload)
        response = module.post('')
        response_results(response, print_json_rows=False)
        response_asserts(response, status_code=201)
        return response

    @staticmethod
    def set_payload(inventory, name, manufacturer, asset_tag, device):
        payload = {
            'description': 'QA-TD',
            'manufacturer': manufacturer,
            'device': device,
            'part_id': inventory['part_id'],
            'serial': inventory['serial'],
            'label': inventory['label'],
            'asset_tag': asset_tag,
            'name': name
        }
        return payload

    @staticmethod
    def get_object_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "the result not is  successful with the filter"
        id = response.json()['results'][0]['id']
        return id

    @pytest.mark.parametrize('test_data', ['test_data_load_inventory'], indirect=True)
    def test_data_load_inventory(self, http, test_data, response_results, apikey, response_asserts,
                                 response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        inventory_items = [
            {'name': 'Test-Inventory-01', 'label': 'test-inventory-1', 'part_id': '12345', 'serial': '2345',
             'asset_tag': '123'},
            {'name': 'Test-Inventory-02', 'label': 'test-inventory-2', 'part_id': '123456', 'serial': '23456',
             'asset_tag': '1234'},
            {'name': 'Test-Inventory-03', 'label': 'test-inventory-3', 'part_id': '1234567', 'serial': '234567',
             'asset_tag': '12345'}]
        manufacturer = self.get_object_id(http, response_results, apikey, self.url_manufacturer,
                                          "name=Test-Manufacturer 01")
        device = self.get_object_id(http, response_results, apikey, self.url_device, "name=Test-Device 01")

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for item in inventory_items:
                name = item['name']
                asset_tag = item['asset_tag']
                payload = self.set_payload(item, name, manufacturer, asset_tag, device)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)
