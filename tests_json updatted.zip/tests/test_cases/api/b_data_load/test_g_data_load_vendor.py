import pytest


@pytest.mark.data_load
class TestContracts:
    def setup(self):
        self.url_vendor = '/api/plugins/nautobot-device-lifecycle-mgmt/provider/'

    @staticmethod
    def set_payload(vendor_name):
        payload = {
            'name': vendor_name,

        }
        return payload

    @pytest.mark.parametrize('test_data', ['test_data_load_vendor'], indirect=True)
    def test_data_load_vendor(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        vendors = ['test vendor']
        for row in test_data['data']:
            for vendor in vendors:
                vendor_name = vendor
                # slug = f"qa-td-vendor-{vendor}"
                end_point = row['ENDPOINT']
                header = {"Authorization": f'{apikey}'}
                module = http(end_point)
                module.set_headers(header)
                response = module.get(f"?name={vendor_name}")
                response_results(response)
                if response.json()['results']:
                    module = http(end_point+"/")
                    id = response.json()['results'][0]['id']
                    payload = self.set_payload(vendor_name)
                    module.set_headers(header)
                    module.set_body(payload)
                    response = module.put(id)
                    response_results(response, print_json_rows=False)
                    response_asserts(response)
                else:
                    module = http(self.url_vendor)
                    payload = self.set_payload(vendor_name)
                    module.set_headers(header)
                    module.set_body(payload)
                    response = module.post()
                    print(response.json())
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)
