import pytest


@pytest.mark.data_load
class TestDeviceFilters:
    def setup(self):
        self.url_device_type = '/api/dcim/device-types/'
        self.url_device_role = '/api/extras/roles/'
        self.url_locations = '/api/dcim/locations/'
        self.url_racks = '/api/dcim/racks/'
        self.url_statuses = '/api/extras/statuses/'

    @staticmethod
    def update_record(module, payload, object_id, response_results, response_asserts):
        module.set_body(payload)
        response = module.put(object_id + '/')
        response_results(response, print_json_rows=False)
        response_asserts(response)
        return response

    @staticmethod
    def create_record(module, payload, response_results, response_asserts):
        module.set_body(payload)
        response = module.post('')
        response_results(response, print_json_rows=False)
        response_asserts(response, status_code=201)
        return response

    @staticmethod
    def set_filter_payload(device_data, name, asset_tag, serial_number):
        return {
            "name": name,
            "asset_tag": asset_tag,
            "serial": serial_number,
            "status": device_data["status_id"],
            "device_role": device_data["role_id"],
            "device_type": device_data["device_type_id"],
            "location": device_data["location_id"]
        }

    @staticmethod
    def prepare_module_data(testdata, http, header):
        module = http(testdata)
        module.set_headers(header)
        return module

    @staticmethod
    def get_object_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @staticmethod
    def set_payload_device_location_filter(data, name, asset_tag, serial_number):
        payload = {
            'name': name,
            'location': data['location_id'],
            'role': data['role_id'],
            'device_type': data['device_type_id'],
            'asset_tag': asset_tag,
            'serial': serial_number,
            'status': data['status_id'],
            'comments': 'Created by Load Test Data Script',
            "custom_fields": {
                "ServiceNow Device Type": "-VG-",
                "servicenow_assignment_group": "GNS Remote Connectivity Support"}
        }
        return payload

    def get_filter_location_adc_data(self, http, response_results, header):
        """
        Get all required IDs for filter adc creation/update using provided filters
        """
        status_id = self.get_object_id(http, response_results, header, self.url_statuses + '{}',
                                       "name=Production")
        load_role_id = self.get_object_id(http, response_results, header, self.url_device_role + '{}',
                                          "name=Access Point")
        device_type_id = self.get_object_id(http, response_results, header, self.url_device_type + '{}',
                                            "model=Test-Device type 01")
        location_id = self.get_object_id(http, response_results, header, self.url_locations + '{}',
                                         "name=ADC")
        if not all([status_id, load_role_id, device_type_id, location_id]):
            return None
        return {
            'status_id': status_id,
            'role_id': load_role_id,
            'device_type_id': device_type_id,
            'location_id': location_id
        }

    @pytest.mark.parametrize('test_data', ['test_data_load_devices_filter_location_adc'], indirect=True)
    def test_data_load_devices_filter_location_adc(self, http, test_data, response_results, apikey, response_asserts,
                                                   response_assert_fields):
        """
           :param http: Endpoint Class which contains requests methods
           :param test_data: Test Data from the excel file
           :param response_asserts: Fixture that will assert the response with its validations
           :param response_results: Fixture that will print information about the Test
           :param response_assert_fields: Fixture that will assert fields to be present in te response
           """
        device_adc_loc = {
            "pc": {"name": "Test-Device_ADC", "asset_tag": "TEST-ASTADC", "serial_number": "TEST-SN_ADC"}
        }
        adc_name = (device_adc_loc['pc']['name'])
        header = {"Authorization": f"{apikey}"}
        adc_device_data = self.get_filter_location_adc_data(http, response_results, apikey)
        module = self.prepare_module_data(test_data['data'][0]['ENDPOINT'], http, header)
        payload = self.set_payload_device_location_filter(adc_device_data, device_adc_loc['pc']['name'],
                                                          device_adc_loc['pc']['asset_tag'],
                                                          device_adc_loc['pc']['serial_number'])
        adcresponse = module.get(f"?name={adc_name}")
        response_results(adcresponse)
        if adcresponse.json()['results']:
            object_id = adcresponse.json()['results'][0]['id']
            self.update_record(module, payload, object_id, response_results, response_asserts)
        else:
            self.create_record(module, payload, response_results, response_asserts)
            
