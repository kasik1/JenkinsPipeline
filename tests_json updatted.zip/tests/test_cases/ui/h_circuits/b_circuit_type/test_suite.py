import os
import time
from tests.fixtures.users import create_login
import pytest


class CircuitTypes:
    def setup(self):
        self.ADD_OK = "Created circuit type"
        self.UPDATE = "Modified circuit type"
        self.ADD_URL = "/circuit-types/add/"
        self.delete_circuit_type = "Deleted circuit type"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestCircuitTypesUserBase(CircuitTypes):

    @pytest.mark.parametrize('test_data', ['test_view_title_circuit_types'], indirect=True)
    def test_view_title_circuit_types(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Test check the title in the menu the tenants """
        title = 'Circuit Types'
        user_base.log_out()
        login_page(user_session)
        user_base.circuit_types_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_circuit_types_UB'], indirect=True)
    def test_add_circuit_types_UB(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.circuit_types_page()
            user_base.click_add_button()
            user_base.set_circuit_types_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_circuit_types'], indirect=True)
    def test_update_element_circuit_types(self, user_base, test_data,login_page, user_session):
        """ Tenants Group - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contact = user_base.search_circuit_types(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            user_base.edit_circuit_types(row['NAME'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_circuit_types'], indirect=True)
    def test_action_delete_circuit_types(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.circuit_types_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestCircuitTypesFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_view_circuit_types_details'], indirect=True)
    def test_view_circuit_types_details(self, ssot, test_data):
        """ Circuits Type- View tenant details """
        ssot.circuit_types_page()
        ssot.view_first_record_of_table()
        assert ssot.text_h5(name="Circuits")


@pytest.mark.parallel
@pytest.mark.functional
class TestCircuitTypes(CircuitTypes):
    """Class for the Circuit Type module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_circuit_types'], indirect=True)
    def test_add_circuit_types(self, ssot, test_data):
        """ Circuit Type - Add a Circuits. """
        for row in test_data['data']:
            ssot.add_circuit_types(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."

    @pytest.mark.parametrize('test_data', ['test_circuit_types_missing'], indirect=True)
    def test_circuit_types_missing(self, ssot, test_data):
        """ Circuit Type- Try to add a Circuits without the required fields. """
        for row in test_data['data']:
            ssot.add_circuit_types(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        for row in test_data['data']:
            found_contact = ssot.search_circuit_types(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.view_change_log_circuit_types(row['NAME'])
            assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_update_circuit_types'], indirect=True)
    def test_update_circuit_types(self, ssot, test_data):
        """ Circuit Type - Update a Circuits with the required fields by model. """
        for row in test_data['data']:
            found_contact = ssot.search_circuit_types(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_circuit_types(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Circuits Type - test_load_data_edit in tenants with the required fields by model. """
        ssot.circuit_types_page()
        data1 = ssot.get_info_table_edit(values=["Name"])
        name = ''.join(x for x in data1 if x not in "[' ]")
        _, edit, _ = ssot.get_circuit_types_buttons_by_name(name)
        edit.click()
        input_values = ssot.check_required_input(['name'])
        assert data1==input_values, "Required field values were not loaded correctly"

    @pytest.mark.parametrize('test_data', ['test_delete_circuit_types'], indirect=True)
    def test_delete_circuit_types(self, ssot, test_data):
        """ Circuit Type- Delete a Circuits by model. """
        for row in test_data['data']:
            found_contact = ssot.search_circuit_types(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.delete_circuit_types(row['NAME'])
            assert ssot.check_alert_text(self.delete_circuit_type), f"The alert text is not {self.delete_circuit_type}" \
                                                                   f" as we expected."


@pytest.mark.exports
class TestCircuitTypeExports:
    @pytest.mark.parametrize('test_data', ['test_export_circuit_type'], indirect=True)
    def test_export_circuit_type(self, ssot, test_data, rename_download):
        """ circuit type - export csv the current view. """
        ssot.circuit_types_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_circuit_type'], indirect=True)
    def test_check_export_circuit_type(self, ssot, test_data, rename_download):
        """ circuit type - chek the csv in local machine"""
        ssot.circuit_types_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'circuit_type_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data,csv)
        os.remove(file_path)