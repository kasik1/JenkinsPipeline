import pytest


class PartialDiscover:
    def setup(self):
        self.ADD_URL = "/plugins/service-now/ipfabric-partial-discovery"


@pytest.mark.smoke
class TestPartialDiscoverSmoke():

    @pytest.mark.parametrize('test_data', ['test_show_module'], indirect=True)
    def test_show_module(self, ssot, test_data, setup_server_url):
        ssot.partial_discovery_page()
        assert ssot.is_title_present('IP Fabric Partial Discovery', type='h1', timeout=60)

    @pytest.mark.parametrize('test_data', ['test_show_text_area'], indirect=True)
    def test_show_text_area(self, ssot, test_data, setup_server_url):
        ssot.partial_discovery_page()
        assert ssot.check_text_area()


@pytest.mark.functional
class TestPartialDiscover(PartialDiscover):
    """Class for the partial discovery"""

    @pytest.mark.parametrize('test_data', ['test_partial_discover'], indirect=True)
    def test_partial_discover(self, ssot, test_data, setup_server_url):
        """ partial discovery - testing the send data and validate that the requests to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.partial_discovery_page()
            ssot.set_data(row)
            ssot.button_send()
            ssot.check_job()

    @pytest.mark.parametrize('test_data', ['test_partial_discover_incomplete_data'], indirect=True)
    def test_partial_discover_incomplete_data(self, ssot, test_data, setup_server_url):
        """ partial discovery - testing the send data and validate that the requests to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.partial_discovery_page()
            ssot.set_data(row)
            ssot.button_send()
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_partial_discover_incomplete_data'], indirect=True)
    def test_partial_discover_button_send(self, ssot, test_data, setup_server_url):
        """ partial discovery - testing the send data and validate that the requests to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.partial_discovery_page()
            ssot.button_send()
            assert ssot.check_url(self.ADD_URL), "The add alert is present."


