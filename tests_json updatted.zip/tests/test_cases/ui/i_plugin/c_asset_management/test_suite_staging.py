
import pytest


class Stag_List:

    def setup(self):
        self.ADD_OK = "Created device"
        self.ADD_URL = "/stag-add/"
        self.UPDATE = "Modified device"
        self.DELETE = "Deleted device"


@pytest.mark.smoke
class TestStagListFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_show_module'], indirect=True)
    def test_show_module(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        ssot.stag_list_page()
        assert ssot.is_title_present('Device', type='h1', timeout=60)

    @pytest.mark.parametrize('test_data', ['test_show_table'], indirect=True)
    def test_show_table(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        ssot.stag_list_page()
        if ssot.check_headers_table(["Name"]):
            headers = ["Name", "Status", "Tenant", "Role", "Device type", "Location", "Rack", "Primary ip"]
            assert ssot.check_headers_table(headers)


@pytest.mark.parallel
@pytest.mark.functional
class TestStagList(Stag_List):
    """Class for the contracts module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_status_stag_device'], indirect=True)
    def test_status_stag_device(self, ssot, test_data,setup_server_url):
        for row in test_data['data']:
            ssot.go_url(setup_server_url)
            ssot.devices_page()
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_device_stag(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            ssot.search_stag_lis(row['NAME'])

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form_stag'], indirect=True)
    def test_required_fields_edit_form_stag(self, ssot, test_data, setup_server_url):
        """ Devices - test_load_data_edit in device."""
        ssot.go_url(setup_server_url)
        ssot.stag_list_page()
        data1 = ssot.get_info_table_edit(values=['Name', 'Role', 'Device type', 'Location', 'Rack'])
        elements = data1
        ssot.click_link_text(data1[0])
        ssot.click_edit_button()
        select_values = ssot.get_select_values_form_edit(['Location', 'Device type', 'Role'])
        input_values = ssot.get_input_values_form_edit(['Name'])
        assert all(element in elements for element in select_values + input_values), "in the edit view the required" \
                                                                                     " fields were not loaded, and the " \
                                                                                     "assert fails because it cannot " \
                                                                                     "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_update_stag'], indirect=True)
    def test_update_stag(self, ssot, test_data):
        """ Devices - Update a device with the required fields by name. """
        for row in test_data['data']:
            found_contact = ssot.search_stag_lis(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_stag_list(row['NAME'], data=row)
            assert ssot.check_title_dev(row['NAME']), f"The text is not {row['NAME']} as we expected."

    @pytest.mark.parametrize('test_data', ['test_delete_stag_device'], indirect=True)
    def test_delete_stag_device(self, ssot, test_data):
        for row in test_data['data']:
            ssot.devices_page()
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_device(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            assert not ssot.search_stag_lis(row['NAME'])




