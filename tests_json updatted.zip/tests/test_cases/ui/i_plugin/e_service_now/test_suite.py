from selenium.webdriver import Keys
import os
import time

import pytest


class SNOW:
    def setup(self):
        self.ADD_OK = "Created device"
        self.UPDATE = "Modified device"
        self.delete_device = "Deleted device"

@pytest.mark.smoke
class TestServiceNowSmoke(SNOW):
    @pytest.mark.parametrize('test_data', ['test_update_parameters'], indirect=True)
    def test_update_parameters(self, ssot, test_data, setup_server_url):
        ssot.page_snow()
        ssot.click_button_filter()
        ssot.select_all_option()
        ssot.button_save()


@pytest.mark.quicktest
class TestServiceNowQuickTest(SNOW):
    @pytest.mark.parametrize('test_data', ['test_ticket_snow_add'], indirect=True)
    def test_ticket_snow_add(self, ssot, test_data, setup_server_url):
        """ service now - Add a device with pre-production status and
        check in service now the correct creation of the ticket"""
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
            ssot.add_ip_address(data=row)
            ssot.add_interface(data=row)
            ssot.add_ip(data=row)
            ssot.create_ci()
            ssot.page_snow()
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            ssot.click_button_cancel()

    @pytest.mark.parametrize('test_data', ['test_button_send_without_selecting_tick'], indirect=True)
    def test_button_send_without_selecting_tick(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        ssot.go_url(setup_server_url)
        ssot.page_snow()
        ssot.click_button_send()
        assert ssot.check_alert_text_error(
            "There are no pending requests selected."), f"The alert text is not as we expected."

    @pytest.mark.parametrize('test_data', ['test_ticket_button_send'], indirect=True)
    def test_ticket_button_send(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
            ssot.add_ip_address(data=row)
            ssot.add_interface(data=row)
            ssot.add_ip(data=row)
            ssot.create_ci()
            ssot.page_snow()
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            pending_request = ssot.get_req_pending_or_send(field="Pending")
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            ssot.click_button_send()
            ssot.check_job_send()
            ssot.page_snow()
            request_number = ssot.get_snow_request_number()
            assert 'REQ' in request_number


@pytest.mark.functional
class TestServiceNow(SNOW):
    """Class for the devices module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_ticket_button_cancel'], indirect=True)
    def test_ticket_button_cancel(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
            ssot.add_ip_address(data=row)
            ssot.add_interface(data=row)
            ssot.add_ip(data=row)
            ssot.create_ci()
            ssot.page_snow()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            pending_request = ssot.get_req_pending_or_send(field="Pending")
            ssot.click_button_cancel()
            ssot.refresh_page()
            send_request = ssot.get_req_pending_or_send(field="Cancelled")
            assert ssot.validate_change_status(pending_request, send_request), "the ticket did not change to Canceled"

    @pytest.mark.parametrize('test_data', ['test_ticket_button_pending'], indirect=True)
    def test_ticket_button_pending(self, ssot, test_data):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.page_snow()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            pending_request = ssot.get_req_pending_or_send(field="Cancelled")
            ssot.click_button_pending()
            ssot.refresh_page()
            send_request = ssot.get_req_pending_or_send(field="Pending")
            assert ssot.validate_change_status(pending_request, send_request)
            ssot.select_checkbox(row['NAME'], "Pending", checkbox=True)
            ssot.click_button_cancel()

    @pytest.mark.parametrize('test_data', ['test_send_ticket_cancel'], indirect=True)
    def test_send_ticket_cancel(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.go_url(setup_server_url)
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
            ssot.add_ip_address(data=row)
            ssot.add_interface(data=row)
            ssot.add_ip(data=row)
            ssot.create_ci()
            ssot.page_snow()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            pending_request = ssot.get_req_pending_or_send(field="Pending")
            ssot.click_button_cancel()
            ssot.refresh_page()
            send_request = ssot.get_req_pending_or_send(field="Cancelled")
            assert ssot.validate_change_status(pending_request, send_request), "the ticket did not change to Canceled"
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            ssot.click_button_send()
            assert ssot.check_alert_text_error("There are no pending requests selected."), f"The alert text is not as we expected."
            send_request = ssot.get_req_pending_or_send(field="Cancelled")
            assert ssot.validate_change_status(pending_request, send_request)

    @pytest.mark.parametrize('test_data', ['test_send_ticket_pending'], indirect=True)
    def test_send_ticket_pending(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.go_url(setup_server_url)
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
            ssot.add_ip_address(data=row)
            ssot.add_interface(data=row)
            ssot.add_ip(data=row)
            ssot.create_ci()
            ssot.page_snow()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            ssot.click_button_pending()
            ssot.refresh_page()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            ssot.click_button_send()
            assert ssot.check_alert_text_error("There are no pending requests selected."), f"The alert text is not as we expected."

    @pytest.mark.parametrize('test_data', ['test_specific_snow_search'], indirect=True)
    def test_specific_snow_search(self, ssot, test_data, setup_server_url):
        """ Service now  - specific search in the page. """
        ssot.page_snow()
        column = ["device", "stage", "request type"]
        data = ssot.get_row_values_snow(column)
        assert ssot.specific_snow_request_search(data), "the values inserted in the search were not validated"
        ssot.check_specific_search_snow(data)

    @pytest.mark.parametrize('test_data', ['test_delete_device_snow'], indirect=True)
    def test_delete_device_snow(self, ssot, test_data, setup_server_url):
        """ Devices used in snow- Delete a device by name. """
        for row in test_data['data']:
            ssot.go_url(setup_server_url)
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['name']} found."
            ssot.delete_device(row['NAME'])
            assert ssot.check_alert_text(
                self.delete_device), f"The alert text is not {self.delete_device} as we expected."
            ssot.delete_ip(row['PRIMARY_IP4'])


@pytest.mark.manual
class TestServiceNowManual:
    """ these test cases are marked as manual because they have a high complexity since they interact with
    https://cignadev1.service-now.com, this interaction is complex and they need to be run manually due
    to credential issues and also methods of extraction of handling of csv that we validate """

    def setup(self):
        self.delete_device = "Deleted device"

    @pytest.mark.parametrize('test_data', ['test_snow_integration_add_request'], indirect=True)
    def test_snow_integration_add_request(self, ssot, test_data, setup_server_url):
        """ Devices - Create a Add Request for SNOW. """
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The success alert is not present."

            # Create the interface and ipv4 for the device
            ssot.add_ip_address(data=row)
            ssot.add_interface(data=row)
            ssot.add_ip(data=row)
            ssot.create_ci()
            assert ssot.check_ip_in_device(data=row)

            # Go the snow page in ssot
            ssot.page_snow()

            # Check that the request has the status Pending
            ssot.check_snow_request_row(row['NAME'], 'Pending', 'Update')

            # Send therequest to the endpoint to trigger the sending of the tickets
            check_ticket = ssot.verify_snow_ticket(row['NAME'], row['STAGE'], row['ACTION'])
            assert check_ticket, "the ticket was not created correctly, " \
                                 "or it does not have the same device name or the status or stag are incorrect"
            pending_request = ssot.get_req_pending_or_send(field="Pending")
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)
            ssot.click_button_send()
            ssot.check_job_send()
            # Search the specific record with filters
            ssot.page_snow()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)

            # Make sure the Request Number is present
            request_number = ssot.get_snow_request_number()
            assert 'REQ' in request_number, 'Request for SNOW is not present'

            # Get the owner in SNOW request
            request_owner = ssot.get_snow_request_owner(row['OWNER'])

            # Check that the request has the status Ticket sent
            ssot.check_snow_request_row(row['NAME'], 'Sent', 'Update')

            # Delete the circuit and ipv4to reuse in the following tests
            ssot.delete_ip(row['PRIMARY_IP4'])

            # Search the Request number in SNOW
            ssot.page_snow()
            ssot.click_link_text(request_number)
            current_request = ssot.get_current_request_number(request_number)
            service_recipient = ssot.get_current_request_service_recipient()
            primary_contact = ssot.get_current_request_primary_contact()
            assert request_number == current_request
            assert request_owner == service_recipient and request_owner == primary_contact
            # Go back to NIM Portal
            ssot.close_new_tab(request_number)

    # @pytest.mark.skip
    @pytest.mark.parametrize('test_data', ['test_monitoring_validate_csv'], indirect=True)
    def test_monitoring_validate_csv(self, ssot, test_data, setup_server_url, rename_download):
        """This test was deactivated because currently the csv of the tickets is not being reflected in snow"""
        """ Service now  - check the snow csv. """
        for row in test_data['data']:
            # Search the specific record with filters
            ssot.page_snow()
            ssot.select_checkbox(row['NAME'], row['STAGE'], checkbox=True)

            # Make sure the Request Number is present
            request_owner = ssot.get_snow_request_owner(row['OWNER'])
            action = ssot.get_action_snow()
            request_number = ssot.check_req_in_snow()
            assert 'REQ' in request_number, 'Request for SNOW is not present'

            # Save data the device for check in ticket
            rows_name = ['Location', 'Serial Number', 'Primary IPv4']
            elements = ssot.get_values_table_details(rows_name)
            name = ssot.get_name_device()
            ssot.click_edit_button()
            data_hardware = ssot.get_select_values_hardware(
                ['Role', 'Device type', 'Manufacturer'])
            check_values = elements + data_hardware + name + [action] + [row['Physical_Address']] + [row['status']]

            # Search the Request number in SNOW
            ssot.page_snow()
            ssot.click_link_text(request_number)
            current_request = ssot.get_current_request_number(request_number)
            service_recipient = ssot.get_current_request_service_recipient()
            primary_contact = ssot.get_current_request_primary_contact()
            assert request_number == current_request
            assert request_owner == service_recipient and request_owner == primary_contact
            ssot.click_request_item()
            ssot.download_monitoring_file()
            file_name = 'monitoring-request.csv'
            time.sleep(3)
            ssot.close_new_tab(request_number)
            time.sleep(2)
            rename_download(name=file_name)
            file_path = os.path.join(os.getcwd(), file_name)
            assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
            csv_values = ssot.get_csv_values(file_name)
            # os.remove(file_path)
            assert (
                ssot.validate_csv_values(csv_values, check_values, csv="monitoring")), "the data not is the same in the csv"

    @pytest.mark.parametrize('test_data', ['test_delete_device'], indirect=True)
    def test_delete_device(self, ssot, test_data, setup_server_url):
        """ Devices - Delete a device by name. """
        for row in test_data['data']:
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['name']} found."
            ssot.delete_device(row['NAME'])
            assert ssot.check_alert_text(
                self.delete_device), f"The alert text is not {self.delete_device} as we expected."


