import string
import random
import pytest
import os
from tests.fixtures.users import create_login


class Contracts:

    def setup(self):
        self.ADD_OK = "Created Contract"
        self.ADD_URL = "/add/"
        self.UPDATE = "Modified Contract"
        self.DELETE = "Deleted Contract"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestContractsUserBase(Contracts):

    @pytest.mark.parametrize('test_data', ['test_view_title_contracts'], indirect=True)
    def test_view_title_contracts(self, user_base, test_data, user_session, login_page):
        """ Contracts - Test check the title in the menu the tenants """
        title = 'Contracts'
        user_base.log_out()
        login_page(user_session)
        user_base.contracts_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_contracts_ub'], indirect=True)
    def test_add_contracts_ub(self, user_base, test_data, user_session, login_page):
        """ Contracts - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.contracts_page()
            user_base.click_add_button()
            user_base.set_contract_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_contracts_ub'], indirect=True)
    def test_update_element_contracts_ub(self, user_base, test_data, user_session,login_page):
        """ Contracts - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contract = user_base.search_contract(row['contract'])
            assert found_contract, f"No contracts with name {row['contract']} found."
            user_base.edit_contract(row['contract'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_action_delete_contracts_ub'], indirect=True)
    def test_action_delete_contracts_ub(self, user_base, test_data, user_session, login_page):
        """ Contracts - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.contracts_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestContractsFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['search_contracts'], indirect=True)
    def test_search_contracts(self, ssot, test_data):
        """ Contracts - Search a contracts by name. """
        title = 'Contracts'
        ssot.contracts_page()
        assert ssot.is_title_present(title, type='h1')


@pytest.mark.parallel
@pytest.mark.functional
class TestContracts(Contracts):
    """Class for the contracts module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_contracts'], indirect=True)
    def test_add_contracts(self, ssot, test_data):
        """ Contracts - Add a Contract. """
        for row in test_data['data']:
            ssot.add_contract(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."

    @pytest.mark.parametrize('test_data', ['test_add_contracts_missing_fields'], indirect=True)
    def test_add_contracts_missing_fields(self, ssot, test_data):
        """ Contracts - Try to add a item without the required fields.
        """
        for row in test_data['data']:
            ssot.add_contract(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_contracts_details'], indirect=True)
    def test_view_contracts_details(self, ssot, test_data):
        """ View record details """
        ssot.contracts_page()
        contract_name = ssot.view_first_record_of_table()
        assert ssot.is_contract_name_present(contract_name)
        modules = ['Contract']
        ssot.are_record_stats_present(modules)

    @pytest.mark.parametrize('test_data', ['test_update_contracts'], indirect=True)
    def test_update_contracts(self, ssot, test_data):
        """ Contracts - Update a contracts with the required fields by name. """
        for row in test_data['data']:
            ssot.contracts_page()
            ssot.view_first_record_of_table()
            ssot.edit_contract(data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Contracts - test_load_data_edit in Contracts with the required fields by model. """
        ssot.contracts_page()
        rows_name = ["Name", "Contract Type", "Vendor"]
        data = ssot.get_info_table_edit(values=rows_name)
        name = data[0]
        ssot.click_link_text(name)
        ssot.click_edit_button()
        input_values = ssot.get_input_values_form_edit(['Name'])
        select_values = ssot.get_select_values_form_edit(['Contract Type', 'Vendor'])
        assert all(element in data for element in input_values+select_values), "in the edit view "\
                                                              "the required fields were not loaded, " \
                                                              "and the assert fails because it cannot find the value" \
                                                              " in the form"

    @pytest.mark.parametrize('test_data', ['test_delete_contract'], indirect=True)
    def test_delete_contract(self, ssot, test_data):
        """ Contracts - Delete a contracts by name. """
        for row in test_data['data']:
            ssot.contracts_page()
            ssot.view_first_record_of_table()
            ssot.click_delete_button()
            ssot.click_confirm_button()
            assert ssot.check_alert_text(self.DELETE), f"The alert text is not {self.DELETE} as we expected."


@pytest.mark.manual
class TestContractsNT:
    """
    Negative Testing Class for Contracts
    """

    @staticmethod
    def gen_input(length):
        """
        Generate input of a given length
        :param length: Length of the string to be generated
        :returns string: Returns the string generated
        """
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))

    @pytest.mark.parametrize('test_data', ['test_contract_input_length'], indirect=True)
    def test_contract_input_length(self, ssot, test_data):
        """
        Test Contract input length validation
        """
        ssot.contracts_page()
        ssot.click_add_button()
        ssot.set_contract_input(self.gen_input(4500))
        ssot.click_submit_button()
        assert ssot.check_alert_text('too long')

    @pytest.mark.parametrize('test_data', ['test_csv_input_bad_data'], indirect=True)
    def test_csv_input_bad_data(self, ssot, test_data):
        """
        Validate csv input from bad data
        """
        for row in test_data['data']:
            ssot.contracts_page()
            ssot.click_import_button()
            ssot.clear_textarea()
            ssot.set_textarea(row['csv_text'])
            ssot.submit_csv()
            assert ssot.error_alert_is_present(), "The error alert is not present"

    @pytest.mark.parametrize('test_data', ['test_csv_upload_bad_data'], indirect=True)
    def test_csv_upload_bad_data(self, ssot, test_data):
        """
        Upload a CSV file with bada data
        """
        ssot.contracts_page()
        ssot.click_import_button()
        ssot.go_to_tab('CSV File Upload')
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'csv_file.csv')
        ssot.upload_csv_file(select_file)
        ssot.submit_file()
        assert ssot.error_alert_is_present(), "The error alert was not present."
        assert ssot.check_alert_text('Unexpected column header'), "Message expected in alert was not found"

    @pytest.mark.parametrize('test_data', ['test_csv_upload_invalid_extension'], indirect=True)
    def test_csv_upload_invalid_extension(self, ssot, test_data):
        """
        Upload a CSV file with invalid extension
        """
        ssot.contracts_page()
        ssot.click_import_button()
        ssot.go_to_tab('CSV File Upload')
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'site.png')
        ssot.upload_csv_file(select_file)
        ssot.submit_file()
        assert ssot.error_alert_is_present(), "The error alert was not present."
        assert ssot.check_alert_text('Unexpected column header'), "Message expected in alert was not found"

    @pytest.mark.parametrize('test_data', ['test_validate_edit_button'], indirect=True)
    def test_validate_edit_button(self, ssot, test_data):
        """
        Validate that there's an error message when no record is selected
        """
        ssot.contracts_page()
        ssot.click_table_edit_button()
        assert ssot.error_alert_is_present(), "The error alert is not present"

    @pytest.mark.parametrize('test_data', ['test_validate_delete_button'], indirect=True)
    def test_validate_delete_button(self, ssot, test_data):
        """
        Validate that there's an error message when no record is selected
        """
        ssot.contracts_page()
        ssot.click_table_delete_button()
        assert ssot.error_alert_is_present(), "The error alert is not present"

    @pytest.mark.parametrize('test_data', ['test_filter_input_length'], indirect=True)
    def test_filter_input_length(self, ssot, test_data):
        """
        Test filter input length validation
        """
        ssot.contracts_page()
        ssot.go_to_tab('Filters')
        ssot.input_search_filters(self.gen_input(4500))
        ssot.search_button_filters()
        assert ssot.check_alert_text('too long')

    @pytest.mark.parametrize('test_data', ['test_invalid_dates'], indirect=True)
    def test_invalid_dates(self, ssot, test_data):
        """
        Validate contract start and end dates
        """
        ssot.contracts_page()
        ssot.click_add_button()
        ssot.set_invalid_dates()
        ssot.click_submit_button()
        assert ssot.error_alert_is_present(), "The error alert is not present"
        assert ssot.check_alert_text('Invalid dates'), "Message expected in alert was not found"


@pytest.mark.exports
class TestContractsExport:
        @pytest.mark.parametrize('test_data', ['test_export_contracts'], indirect=True)
        def test_export_contracts(self, ssot, test_data, rename_download):
            """ contracts - export csv the current view. """
            ssot.contracts_page()
            ssot.click_export_button()
            ssot.export_current_view()

        @pytest.mark.parametrize('test_data', ['test_check_export_contracts'], indirect=True)
        def test_check_export_contracts(self, ssot, test_data, rename_download):
            """ contracts - chek the csv in local machine"""
            ssot.contracts_page()
            data = ssot.get_data_for_check_export(2)
            file_name = 'contracts_export.csv'
            rename_download(name=file_name)
            file_path = os.path.join(os.getcwd(), file_name)
            assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
            csv = ssot.read_csv(file_name)
            assert ssot.check_csv_and_data(data, csv)
            os.remove(file_path)
