"""
Test Folder for the SSOT: Inventory UI testing
"""
