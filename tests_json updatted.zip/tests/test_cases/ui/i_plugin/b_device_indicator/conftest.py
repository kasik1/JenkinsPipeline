"""
This files includes configuration and methods for pytest to execute them as hooks
"""
from tests.commons.functions import fill_test_case_detail_values
from tests.commons.csv import Csv
from tests.pom.device_indicators import DeviceIndicators
import pytest
import os
from faker import Faker
import json


@pytest.fixture(scope='session')
def spreadsheet():
    """
    :return: It returns a Object Class with methods to manipulate a CSV file
    """
    path = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(path, 'test_data.csv')
    return Csv(file_path)


@pytest.fixture(scope='session')
def setup_server_url(spreadsheet, testing_environment):
    """
    :param spreadsheet: Object Class to manipulate a CSV file
    :param testing_environment: Fixture that determines where the testing is going to be executed
    :return: The exact server which the testing is going to be executed
    """
    return testing_environment(spreadsheet)


@pytest.fixture
def test_data(request, spreadsheet):
    """
    :param request: Pytest object with execution variables
    :param spreadsheet: Object Class to manipulate a CSV file
    :return: A dict with the Test Data
    """
    fixture_name = request.param
    data = {
        'test_case': {
            'test_case_id': '',
            'build': '',
            'tester': '',
            'notes': '',
            'c_environment': ''},
        'data': []
    }

    # If fixture 'user_session' is being used
    if 'user_session' in request.keywords.node.funcargs:
        cookie = getattr(request.keywords.node.funcargs['user_session'], 'cookies', False)
        user_group = {'user_group': cookie['user_group']}
    else:
        user_group = {'user_group': []}
    data['test_case'].update(user_group)

    for row in (row for row in spreadsheet.rows() if row['TEST_TYPE'] == fixture_name):
        data = fill_test_case_detail_values(data, row)
        data['data'].append(row)
    return data

@pytest.fixture()
def user_base(user_base_driver):
    """Create the driver to run the tests"""
    driver = user_base_driver
    user_base = DeviceIndicators(driver)
    return user_base

@pytest.fixture()
def ssot(global_driver, setup_server_url):
    """create the driver to run the tests"""
    driver = global_driver
    ssot = DeviceIndicators(driver)
    return ssot

@pytest.fixture
def fake_device_indicator_data(tmp_path):
    fake = Faker()
    data = {
        "icmp_enabled": fake.boolean(),
        "icmp_working": fake.boolean(),
        "snmp_enabled": fake.boolean(),
        "snmp_working": fake.boolean(),
        "device_name": fake.hostname()
    }
    # Save to a temp JSON file
    json_path = tmp_path / "fake_device_indicator.json"
    with open(json_path, "w") as f:
        json.dump(data, f, indent=2)
    yield data, str(json_path)



