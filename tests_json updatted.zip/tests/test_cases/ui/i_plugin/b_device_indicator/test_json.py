[
    {
        "location_name": "HQ",
        "status__name": "Active",
        "role__name": "Access Point",
        "cf_servicenow_assignment_group": "GNS Remote Connectivity Support",
        "filter_value": "Device123"
    }
]