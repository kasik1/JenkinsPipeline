import os
from tests.fixtures.users import create_login
import pytest


class Tenants:

    def setup(self):
        self.ADD_OK = "Created tenant"
        self.UPDATE = "Modified tenant"
        self.DELETE = "Deleted tenant"
        self.ADD_URL = "/tenants/add"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestTenantGroupUserBase(Tenants):

    @pytest.mark.parametrize('test_data', ['test_view_title_tenants'], indirect=True)
    def test_view_title_tenants(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Test check the title in the menu the tenants """
        title = 'Tenants'
        user_base.log_out()
        login_page(user_session)
        user_base.tenant_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_tenants'], indirect=True)
    def test_add_tenants(self, user_base, test_data, user_session, login_page):
        """ Tenants- Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.tenant_page()
            user_base.click_add_button()
            user_base.set_tenant_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_tenants'], indirect=True)
    def test_update_element_tenants(self, user_base, test_data, user_session,login_page):
        """ Tenants- Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_tenant = user_base.search_Tenant(row['TENANTS'])
            assert found_tenant, f"No contact with name {row['TENANTS']} found."
            user_base.edit_tenant(row['TENANTS'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_tenants'], indirect=True)
    def test_action_delete_tenants(self, user_base, test_data, user_session, login_page):
        """ Tenant- Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.tenant_page()
        user_base.view_first_tenant()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestTenantFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_search_tenant'], indirect=True)
    def test_search_tenant_module(self, ssot, test_data):
        """ Tenant - Search a Tenant module and check the title """
        title = 'Tenant'
        ssot.tenant_page()
        assert ssot.is_title_present(title, type='h1')


@pytest.mark.parallel
@pytest.mark.functional
class TestTenant(Tenants):
    """Class for the tenants module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_tenant'], indirect=True)
    def test_add_tenant(self, ssot, test_data):
        """ Tenant - Add a Tenant. """
        for row in test_data['data']:
            ssot.add_tenant(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."

    @pytest.mark.parametrize('test_data', ['test_add_tenant_missing'], indirect=True)
    def test_add_tenant_missing(self, ssot, test_data):
        """ Tenant - Try to add a Tenant without the required fields. """
        for row in test_data['data']:
            ssot.add_tenant(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_tenant_details'], indirect=True)
    def test_view_tenant_details(self, ssot, test_data):
        """ Tenant - View tenant details """
        ssot.tenant_page()
        name = ssot.view_first_tenant()
        assert ssot.is_tenant_description_present(name)
        ssot.are_tenant_stats_present()

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        ssot.tenant_page()
        ssot.view_first_tenant()
        ssot.go_to_tab('Change Log')
        assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_update_tenant'], indirect=True)
    def test_update_tenant(self, ssot, test_data):
        """ Tenant - Update a Tenant with the required fields by model. """
        for row in test_data['data']:
            ssot.search_tenant(row['TENANTS'])
            ssot.edit_tenant(row['TENANTS'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"Expected alert '{self.UPDATE}' is not present"

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ tenants - test_load_data_edit in tenants with the required fields by model. """
        ssot.tenant_page()
        data1 = ssot.get_info_table_edit(values=["Name"])
        ssot.click_link_text(data1[0])
        ssot.click_edit_button()
        input_values = ssot.get_input_values_form_edit(['Name'])
        assert all(element in data1 for element in input_values),"in the edit view the required" \
                                                                                     " fields were not loaded, and the " \
                                                                                     "assert fails because it cannot " \
                                                                                     "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_delete_tenant'], indirect=True)
    def test_delete_tenant(self, ssot, test_data):
        """ Tenant - Delete a Tenant by model. """
        for row in test_data['data']:
            ssot.search_tenant(row['TENANTS'])
            ssot.delete_tenant(row['TENANTS'])
            assert ssot.check_alert_text(self.DELETE), f"The alert text is not {self.DELETE} as we expected."

@pytest.mark.exports
class TestTenantsExport:
        @pytest.mark.parametrize('test_data', ['test_export_tenants'], indirect=True)
        def test_export_tenants(self, ssot, test_data, rename_download):
            """ tenants - export csv the current view. """
            ssot.tenant_page()
            ssot.click_export_button()
            ssot.export_current_view()

        @pytest.mark.parametrize('test_data', ['test_check_export_tenants'], indirect=True)
        def test_check_export_tenants(self, ssot, test_data, rename_download):
            """ tenants - chek the csv in local machine"""
            ssot.tenant_page()
            data = ssot.get_data_for_check_export(2)
            file_name = 'tenats_export.csv'
            rename_download(name=file_name)
            file_path = os.path.join(os.getcwd(), file_name)
            assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
            csv = ssot.read_csv(file_name)
            assert ssot.check_csv_and_data(data, csv)
            os.remove(file_path)