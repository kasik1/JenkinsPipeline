import os
import time
from tests.fixtures.users import create_login
import pytest


class Devices:

    def setup(self):
        self.ADD_OK = "Created device"
        self.UPDATE = "Modified device"
        self.ADD_URL = "/devices/add"
        self.ADD_INVENTORY = "Added 1 inventory"
        self.delete_device = "Deleted device"
        self.UPLOAD_FILE = "Created image attachment"
        self.DELETE_FILE = "Deleted image attachment"
        self.UPDATE_FILE = "Modified image attachment"
        self.ADD_INTERFACES = "Added 1 interface templates"
        self.DELETE_INTERFACE = "Deleted interface template"
        self.UPDATE_INTERFACE = "Modified interface template"
        self.ADD_URL_FRONT = "/front-port-templates/add"
        self.ADD_REAR = "Added 1 rear port templates"
        self.ADD_FRONT = "Added 1 front port templates"
        self.delete_dev_type = "Deleted device type"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestDevicesUserBase(Devices):

    @pytest.mark.parametrize('test_data', ['test_view_title_platforms'], indirect=True)
    def test_view_title_devices(self, user_base, test_data, user_session, login_page):
        """ device - Test check the title in the menu the tenants """
        title = 'Devices'
        user_base.log_out()
        login_page(user_session)
        user_base.devices_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_devices'], indirect=True)
    def test_add_devices(self, user_base, test_data, user_session, login_page):
        """ device - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.devices_page()
            user_base.click_add_button()
            user_base.set_device_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_devices'], indirect=True)
    def test_update_element_devices(self, user_base, test_data,login_page, user_session):
        """ device - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contact = user_base.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            user_base.edit_device(row['NAME'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_devices'], indirect=True)
    def test_action_delete_devices(self, user_base, test_data, user_session, login_page):
        """ device - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.devices_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.functional
class TestComponents(Devices):
    """Class for the devices module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_component'], indirect=True)
    def test_add_component(self, ssot, test_data):
        """ Devices - Add a device. """
        device_types = [row['DEVICE_TYPE'] for row in test_data['data']]
        interface = [row['NAME_INTERFACE'] for row in test_data['data']]
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
        ssot.link_device_type(device_types[0])
        ssot.component_device(tag="Interfaces")
        ssot.add_component("Interfaces")
        ssot.set_templete(interface[0])
        assert ssot.check_alert_text(self.ADD_INTERFACES), f"The alert text is not {self.ADD_INTERFACES} as we expected."
        for row in test_data['data']:
            assert ssot.get_components_table(name_device=row['DEVICE_TYPE'], tab="Rear Ports ", name_component=interface[0]), \
                "components are not found on the related device"

    @pytest.mark.parametrize('test_data', ['test_edit_interface'], indirect=True)
    def test_edit_interface(self, ssot, test_data):
        """ Devices - Add a device. """
        device_types = [row['DEVICE_TYPE'] for row in test_data['data']]
        interface = [row['NAME_INTERFACE'] for row in test_data['data']]
        data_update = [row['UPDATE_INTERFACE'] for row in test_data['data']]
        ssot.link_device_type(device_types[0])
        ssot.component_device(tag="Interfaces")
        ssot.buttons_component_item(interface[0], "Edit")
        ssot.update_templete(data_update[0])
        assert ssot.check_alert_text(self.UPDATE_INTERFACE), f"The alert text is not {self.UPDATE_INTERFACE} as we expected."
        for row in test_data['data']:
            assert ssot.get_components_table(name_device=row['DEVICE_TYPE'], tab="Interfaces ", name_component=data_update[0]),\
                "components are not found on the related device"

    @pytest.mark.parametrize('test_data', ['test_delete_interface'], indirect=True)
    def test_delete_interface(self, ssot, test_data):
        """ Devices - Add a device. """
        device_types = [row['DEVICE_TYPE'] for row in test_data['data']]
        interface = [row['NAME_INTERFACE'] for row in test_data['data']]
        ssot.link_device_type(device_types[0])
        ssot.component_device(tag="Interfaces")
        ssot.buttons_component_item(interface[0], "Delete")
        ssot.click_confirm_button()
        assert ssot.check_alert_text(self.DELETE_INTERFACE), f"The alert text is not {self.DELETE_INTERFACE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_front_port_component_messing'], indirect=True)
    def test_front_port_component_messing(self, ssot, test_data):
        """ Devices - Add a device. """
        device_types = [row['DEVICE_TYPE'] for row in test_data['data']]
        front = [row['NAM_FRONT'] for row in test_data['data']]
        ssot.link_device_type(device_types[0])
        ssot.component_device(tag="Front Ports")
        ssot.add_component("Front Ports")
        ssot.set_templete(front[0])
        assert ssot.check_url(self.ADD_URL_FRONT), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_rear_port_component'], indirect=True)
    def test_rear_port_component(self, ssot, test_data):
        """ Devices - Add a device. """
        device_types = [row['DEVICE_TYPE'] for row in test_data['data']]
        rear = [row['NAME_REAR'] for row in test_data['data']]
        ssot.link_device_type(device_types[0])
        ssot.component_device(tag="Rear Ports")
        ssot.add_component("Rear Ports")
        ssot.set_templete(rear[0])
        assert ssot.check_alert_text(self.ADD_REAR), "The add alert is present."

        for row in test_data['data']:
            assert ssot.get_components_table(name_device=row['DEVICE_TYPE'], tab="Rear Ports ", name_component=rear[0]), \
                "components are not found on the related device"

    @pytest.mark.parametrize('test_data', ['test_front_port_component'], indirect=True)
    def test_front_port_component(self, ssot, test_data):
        """ Devices - Add a device. """
        device_types = [row['DEVICE_TYPE'] for row in test_data['data']]
        front = [row['NAM_FRONT'] for row in test_data['data']]
        rear = [row['NAME_REAR'] for row in test_data['data']]
        ssot.link_device_type(device_types[0])
        ssot.component_device(tag="Front Ports ")
        ssot.add_component("Front Ports")
        ssot.set_templete(front[0], option_front=True)
        assert ssot.check_alert_text(self.ADD_FRONT), "The add alert is present."
        assert ssot.get_components_table(name_device=device_types[0], tab="Front Ports ", name_component=front[0]), \
            "components are not found on the related device"
        assert ssot.get_components_table(name_device=device_types[0], tab="Rear Ports", name_component=rear[0]), \
            "components are not found on the related device"
        for row in test_data['data']:
            ssot.devices_page()
            ssot.input_search_filters(row['NAME'])
            ssot.search_button_filters()
            ssot.delete_device(row['NAME'])

    @pytest.mark.parametrize('test_data', ['test_delete_device_type'], indirect=True)
    def test_delete_device_type(self, ssot, test_data):
        """ Device Types - Delete a device type by model. """
        for row in test_data['data']:
            found_contact = ssot.search_device_type(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.delete_device(row['NAME'])
            assert ssot.check_alert_text(
                self.delete_dev_type), f"The alert text is not {self.delete_dev_type} as we expected."


@pytest.mark.quicktest
class TestDevicesQuickTest(Devices):
    @pytest.mark.parametrize('test_data', ['test_view_device_details'], indirect=True)
    def test_view_device_details(self, ssot, test_data):
        """ Device - View site details """
        ssot.devices_page()
        ssot.view_first_device()
        ssot.are_device_stats_present()

    @pytest.mark.parametrize('test_data', ['test_add_device'], indirect=True)
    def test_add_device(self, ssot, test_data):
        """ Devices - Add a device. """
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
            assert ssot.check_alert_text(self.ADD_OK), f"The alert text is not {self.ADD_OK} as we expected."
            ssot.check_title_after_add(row['NAME'])

    @pytest.mark.parametrize('test_data', ['test_update_device'], indirect=True)
    def test_update_device(self, ssot, test_data):
        """ Devices - Update a device with the required fields by name. """
        for row in test_data['data']:
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.edit_device(row['NAME'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."


@pytest.mark.smoke
class TestDevicesFormSmokeTesting:

    @pytest.mark.parametrize('test_data', ['test_search_device'], indirect=True)
    def test_search_device(self, ssot, test_data):
        """ Devices - Search a device by name. """
        ssot.devices_page()
        data1 = ssot.get_info_table_edit(values=["Name"])
        found_contact = ssot.search_device(data1[0])
        assert found_contact, f"No contact with name {['Name']} found."

    @pytest.mark.parametrize('test_data', ['test_specific_search_in_device'], indirect=True)
    def test_specific_search_in_device(self, ssot, test_data):
        for row in test_data['data']:
            col = ["name", "status", "location"]
            ssot.devices_page()
            data = ssot.get_row_values(col, row_n=row['ROW'])
            ssot.specific_search_dev(data)
            ssot.check_specific_search(data)


@pytest.mark.functional
class TestDevices(Devices):
    """Class for the devices module in ssot"""

    def route_file(self):
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'site.png')
        return select_file

    @pytest.mark.parametrize('test_data', ['test_add_device_missing_fields'], indirect=True)
    def test_add_device_missing_fields(self, ssot, test_data):
        """ Devices - Add item without the required fields. """
        for row in test_data['data']:
            ssot.add_device(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ view the change log """
        for row in test_data['data']:
            ssot.devices_page()
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.click_link_text(row['NAME'])
            ssot.go_to_tab("Change Log")
            assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Devices - test_load_data_edit in device."""
        ssot.devices_page()
        data1 = ssot.get_info_table_edit(values=["Name"])
        ssot.click_link_text(data1[0])
        rows_name = ['Location', 'Role', 'Status']
        elements = ssot.get_values_table_details(rows_name) + [data1[0]]
        ssot.click_edit_button()
        select_values = ssot.get_select_values_form_edit(['Role', 'Status'])
        input_values = ssot.get_input_values_form_edit(['Name'])
        assert all(element in elements for element in select_values + input_values), "in the edit view the required" \
                                                                                     " fields were not loaded, and the " \
                                                                                     "assert fails because it cannot " \
                                                                                     "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_region_site_valid_edit'], indirect=True)
    def test_region_site_valid_edit(self, ssot, test_data):
        """ Devices - test_load_data_edit in device."""
        ssot.devices_page()
        data1 = ssot.get_info_table_edit(values=["Name"])
        site = ssot.get_info_table_edit(values=["Location"])
        ssot.click_link_text(data1[0])
        ssot.click_edit_button()
        assert ssot.get_validate_site_region(site[0])

    @pytest.mark.parametrize('test_data', ['test_delete_device'], indirect=True)
    def test_delete_device(self, ssot, test_data, setup_server_url):
        """ Devices - Delete a device by name. """
        for row in test_data['data']:
            found_contact = ssot.search_device(row['NAME'])
            assert found_contact, f"No contact with name {row['NAME']} found."
            ssot.delete_device(row['NAME'])
            assert ssot.check_alert_text(
                self.delete_device), f"The alert text is not {self.delete_device} as we expected."


@pytest.mark.manual
class TestDecomDocumentationNT:
    """
    Test class for Devices negative testing
    """

    @pytest.mark.parametrize('test_data', ['test_csv_upload_invalid_extension'], indirect=True)
    def test_csv_upload_invalid_extension(self, ssot, test_data):
        """
        Upload a CSV file with invalid extension
        """
        ssot.devices_page()
        ssot.view_first_record_of_table()
        ssot.add_file()
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'site.png')
        ssot.set_file_name('Test')
        ssot.set_file_input(select_file)
        ssot.submit_file()
        assert ssot.error_alert_is_present(), "The error alert was not present."
        assert ssot.check_alert_text('valid file extensions'), "Message expected in alert was not found"

    @pytest.mark.parametrize('test_data', ['test_help_button'], indirect=True)
    def test_help_button(self, ssot, test_data):
        """
        Validate Help button works
        """
        ssot.devices_page()
        ssot.view_first_record_of_table()
        ssot.add_file()
        ssot.click_help_button()
        assert ssot.is_title_present('Help for uploading a file', type='h1'), 'Help page was not present'


@pytest.mark.exports
class TestDevicesExports:
    @pytest.mark.parametrize('test_data', ['test_export_devices'], indirect=True)
    def test_export_devices(self, ssot, test_data, rename_download):
        """ device - export csv the current view. """
        ssot.devices_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_devices'], indirect=True)
    def test_check_export_devices(self, ssot, test_data, rename_download):
        """ device - chek the csv in local machine"""
        ssot.devices_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'device_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data,csv)
        os.remove(file_path)