import pytest
from tests.commons.driver_config import Driver
from tests.pom.login import Login  #Uncomment this line when ui testing is started
from tests.commons.django_api_config import get_project_credentials

pytest_plugins = [
    'tests.fixtures.api_rest',
    'tests.fixtures.global_fixtures',
    'tests.plugins.reporting',
    'tests.hooks.test_reporting',
]


@pytest.fixture(scope='session')
def global_driver(setup_server_url, browser, test_mode, ui_mode):
    driver = Driver.create_driver(test_mode, browser, ui_mode=ui_mode)
    driver.get(setup_server_url)
    login = Login(driver)
    login.get_url_env(*get_project_credentials())
    login.log_in(*get_project_credentials())
    yield driver
    driver.close()
    driver.quit()


@pytest.fixture(scope='session')
def user_base_driver(setup_server_url, browser, test_mode, ui_mode):
    driver = Driver.create_driver(test_mode, browser, ui_mode=ui_mode)
    driver.get(setup_server_url)
    yield driver
    driver.close()
    driver.quit()
