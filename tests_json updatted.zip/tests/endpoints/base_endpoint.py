import requests
import urllib3

urllib3.disable_warnings(category=urllib3.exceptions.InsecureRequestWarning)


class BaseEndPoint:

    def __init__(self, session, server_url, endpoint=''):
        """
        :param session: Fixture that will authenticate user's credentials
        :param server_url: Server on which the tests will execute
        :param get_url: URL for the GET method that will be used
        :param post_url: URL for the POST method that will be used
        :param put_url: URL for the PUT method that will be used
        :param delete_url: URL for the DELETE method that will be used
        """
        self.session = session
        self.server = server_url
        self.endpoint = endpoint
        self.headers = {}
        self.body_request = None
        self.query_parameters = None
        self.path_parameters = None
        self.attachment_file_path = None
        self.attachment_file_name = None

    def get(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        if kwargs != {}:
            request_url = self.set_query_parameters(request_url, kwargs)
        """
            If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            return requests.get(request_url, headers=self.headers, verify=False)
        else:
            return self.session.get(request_url, headers=self.headers)

    def post(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        headers = {'Content-type': 'application/json'}
        headers.update(self.headers)
        if self.attachment_file_path is not None and self.attachment_file_name is not None:
            files = {self.attachment_file_name: open(self.attachment_file_path, 'rb')}
            data = self.body_request
            return self.session.post(request_url, files=files, data=data)

        """
            If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            return requests.post(request_url, json=self.body_request, headers=headers, verify=False)
        else:
            return self.session.post(request_url, json=self.body_request, headers=headers)

    def put(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        headers = {'Content-type': 'application/json'}
        headers.update(self.headers)
        """
                    If there's an API Token, self.session will not be used because it will create an authentication problem
                """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            return requests.put(request_url, json=self.body_request, headers=headers, verify=False)
        else:
            return self.session.put(request_url, json=self.body_request, headers=headers)

    def patch(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        headers = {'Content-type': 'application/json'}
        headers.update(self.headers)
        """
            If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            return requests.patch(request_url, json=self.body_request, headers=headers, verify=False)
        else:
            return self.session.patch(request_url, json=self.body_request, headers=headers)

    def delete(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        """
            If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            return requests.delete(request_url, json=self.body_request, headers=self.headers, verify=False)
        else:
            return self.session.delete(request_url, json=self.body_request, headers=self.headers)

    def set_headers(self, headers):
        """
        :param headers: {index: value, index_b: value_b}
        """
        self.headers = headers

    def format_url(self, end_point):
        return self.server + end_point

    def set_body(self, body_payload):
        self.body_request = body_payload

    @staticmethod
    def set_query_parameters(request_url, query_parameters):
        request_url += '?'
        for query_parameter in query_parameters:
            request_url += '{}={}&'.format(query_parameter, query_parameters[query_parameter])
        return request_url

    def set_path_parameters(self, path_parameters):
        self.path_parameters = path_parameters

    def set_attachment(self, file_name, file_path):
        self.attachment_file_name = file_name
        self.attachment_file_path = file_path

    def set_attachment_multi(self, file_name, file_path, argument):
        self.attachment_file_name = file_name
        self.attachment_file_path = file_path
        self.body_request = argument
