from ..endpoints.base_endpoint import BaseEndPoint


class Virtualization(BaseEndPoint):
    def __init__(self, session, server_url, **kwargs):
        super(Virtualization, self).__init__(session, server_url, **kwargs)