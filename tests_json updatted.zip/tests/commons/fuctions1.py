def fill_test_case_detail_values_from_json(test_case_dict, json_row):
    """
    Fills test case details from a JSON row (dict).
    :param test_case_dict: The current dict to fill (should have a 'test_case' key)
    :param json_row: A dict from a JSON array
    :return: The updated dict with its values
    """
    if test_case_dict['test_case'].get('test_case_id', '') == '' and json_row.get('TEST_CASE_ID', '') != '':
        test_case_dict['test_case']['test_case_id'] = json_row['TEST_CASE_ID']

    if test_case_dict['test_case'].get('build', '') == '' and json_row.get('BUILD', '') != '':
        test_case_dict['test_case']['build'] = json_row['BUILD']

    if test_case_dict['test_case'].get('tester', '') == '' and json_row.get('TESTER', '') != '':
        test_case_dict['test_case']['tester'] = json_row['TESTER']

    if test_case_dict['test_case'].get('notes', '') == '' and json_row.get('NOTES', '') not in ('', 'None'):
        test_case_dict['test_case']['notes'] = json_row['NOTES']

    if test_case_dict['test_case'].get('c_environment', '') == '' and json_row.get('C_ENVIRONMENT', '') != '':
        test_case_dict['test_case']['c_environment'] = json_row['C_ENVIRONMENT']
    return test_case_dict