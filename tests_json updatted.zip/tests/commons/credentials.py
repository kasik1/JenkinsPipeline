# from ndosecrets import get_secret,get_local_secret
#
# DEBUG = False
# SEND_TC_RESULTS = True
#
# NAUTOBOT_ENVIRONMENT = get_local_secret("environment")
# VAULT_SETTINGS = get_secret(f"ssot/environment/{NAUTOBOT_ENVIRONMENT}")
# api_key = VAULT_SETTINGS.get('testing_api_key')
# DEVELOPMENT = "http://cvlappxd33547.silver.com:8080"
# STAGING = "http://cvlappxd35871.silver.com:8080"
#
# def get_project_credentials(project_name='DJANGO'):
#     """work around until the secrets library is fully integrated"""
#     try:
#         username = VAULT_SETTINGS.get("testing_username")
#         password = VAULT_SETTINGS.get("testing_password")
#
#         return username, password
#     except:
#         raise Exception("Error on Credentials retrieval")
#from ndosecrets import get_secret,get_local_secret
#from ndosecrets import get_secret,get_local_secret

DEBUG = False
SEND_TC_RESULTS = False

#NAUTOBOT_ENVIRONMENT = get_local_secret("environment")
# VAULT_SETTINGS = get_secret(f"ssot/environment/{NAUTOBOT_ENVIRONMENT}")
# api_key = VAULT_SETTINGS.get('testing_api_key')IRONMENT}")
DEVELOPMENT = "http://cvlappxd39566.silver.com:8080"
STAGING = "http://cvlappxd35871.silver.com:8080"

nim_username = "administrator"
nim_password = "secret"
api_key = "token		a92faed5c1be503f69c1b4d1ed0708941b292b94"
