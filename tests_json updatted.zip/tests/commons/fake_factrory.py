from faker import Faker

class FakerFactory:
    def __init__(self):
        self.faker = Faker()

    def fake_device_type(self):
        return {
            "MODEL": self.faker.unique.word() + str(self.faker.random_int(100, 999)),
            "PART_NUMBER": self.faker.unique.bothify(text='??#####'),
            "HEIGHT_U": self.faker.random_int(1, 10)
        }