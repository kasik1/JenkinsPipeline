import json

class JsonReader:
    def __init__(self, file_name):
        self._file_name = file_name

    def rows(self, key=None):
        """
        :param key: Optional key to extract a list from a nested JSON object
        :return: List of dicts (test data)
        """
        with open(self._file_name, 'r') as json_file:
            data = json.load(json_file)
            if key:
                return data[key]
            return data